# rsvx7-ai — Premium AI Chat Platform

## Vision
DeepSeek-inspired premium burgundy chat assistant with original branding `rsvx7-ai`.


## Recent Changes (Feb 2026)

- **Second Security Pass — SEC-A, B, D, E + IP-ban abuse protection (Feb 18, 2026)**:
  - **SEC-010 (NEW) — IP-based abuse protection.** Creating >3 accounts from
    the same real client IP now:
      * Bans the IP (recorded in `banned_ips` collection).
      * Auto-suspends every account tied to that IP (both `registration_ip`
        and `last_ip`) with `suspended_reason = "ip_ban:too_many_accounts_per_ip"`.
      * Blocks all future register/login attempts from that IP with
        Arabic body `{"code":"ip_banned","message":"تم حظرك من قِبَل المسؤول..."}`.
      * Admins/owner remain able to log in from a banned IP (recovery path).
    New admin routes:
      * `GET /api/admin/banned-ips` — list bans.
      * `POST /api/admin/banned-ips` — manual ban.
      * `DELETE /api/admin/banned-ips/{ip}` — unban + auto-reactivate every
        account suspended by that ban (keeps other suspensions intact).
    Frontend `AuthContext.readError` renders the Arabic banner as-is.
    Configurable via `MAX_ACCOUNTS_PER_IP` env (default 3).
    Verified E2E: 3 successful signups from same IP, 4th → 403 ip_banned + all 3
    prior accounts flipped to `suspended`; unban reactivates all 3.
  - **SEC-A (P1 HIGH) — Function-level authorization gaps closed.**
    Every user-lifecycle, settings, and telegram admin endpoint now requires
    the correct fine-grained permission (previously any staff role passed):
      * users: `admin_set_status`, `admin_delete`, `admin_reset_pw`,
        `admin_reset_recovery`, `admin_reset_usage`, `admin_ban_ip`,
        `admin_unban_ip` → `require_permission("users")`
      * settings: `get_settings`, `set_settings`,
        `admin_toggle_verification` → `require_permission("settings")`
      * telegram: `tg_test`, `tg_broadcast`, `admin_tg_force_verify`,
        `admin_tg_force_unlink`, all `/admin/telegram-groups` routes →
        `require_permission("telegram")`
    Verified: a moderator holding only "dashboard" perm gets 403 on every
    one of these routes.
  - **SEC-B (P2) — XFF header spoofing defeated.** `_client_meta` and
    `_rate_key` now derive the client IP from Cloudflare's
    `CF-Connecting-IP` (which CF strips from inbound requests, so it can't
    be spoofed) → `True-Client-IP` → rightmost token of `X-Forwarded-For`
    (added by our own ingress). Attackers rotating `X-Forwarded-For` per
    request no longer bypass rate limits or the SEC-010 IP cap. Verified:
    10 rapid logins with 10 different spoofed XFFs still count against the
    single real IP and trigger 429 on the 11th.
  - **SEC-D (P2) — workspace file-download JWT hardened.** `download_file`
[بيانات البيئة السابقة محذوفة من نسخة النشر]
[بيانات البيئة السابقة محذوفة من نسخة النشر]
    empty-key forgery vector.
[بيانات البيئة السابقة محذوفة من نسخة النشر]
[بيانات البيئة السابقة محذوفة من نسخة النشر]
    (needed by the operator on first boot) but the boot log no longer
[بيانات البيئة السابقة محذوفة من نسخة النشر]
[بيانات البيئة السابقة محذوفة من نسخة النشر]
    from `backend/.env`, fixed `tg_verify._get_bot_token` reading from the
    wrong settings doc (`_id:"app"` vs `_id:"global"`).

- **Security Hardening Pass (Feb 18, 2026)** — full remediation of the internal audit:
[بيانات البيئة السابقة محذوفة من نسخة النشر]
    `auth.py::seed_admin()` now generates a fresh cryptographically strong
[بيانات البيئة السابقة محذوفة من نسخة النشر]
[بيانات البيئة السابقة محذوفة من نسخة النشر]
[بيانات البيئة السابقة محذوفة من نسخة النشر]
    hashes are NEVER overwritten on subsequent boots. Owner username still
[بيانات البيئة السابقة محذوفة من نسخة النشر]
    `[بيانات حساسة محذوفة]` no longer works; only the freshly-seeded one does.
  - **SEC-002 (P2) — Staff-role token abuse locked down.**
    All wallet-write and coupon-write endpoints now require the correct
    fine-grained RBAC permission instead of the coarse `require_admin`:
      * `/admin/tokens/add|set|reset|deduct|freeze|unfreeze` → `payments`
      * `/admin/users/{uid}/subscription` (top-up) → `payments`
      * `/admin/users/{uid}/grant` → `payments`
      * `/admin/coupons` (POST/PATCH/DELETE) → `coupons`
    Low-trust roles (moderator/support) without those perms now get 403
    with a clear "Missing permission: X" body. Verified via curl.
  - **SEC-003 (P2) — Coupon-redemption race condition closed.**
    `coupons.py::redeem_coupon` is now fully race-safe:
      1. Each redemption row carries a `dedup_key` — `user_id:code` for
         single-use-per-user, `user_id:code:<nonce>` for repeat-allowed.
      2. `ensure_indexes()` creates a **unique** index on `dedup_key`,
         backfilling legacy rows and dropping the old non-unique index.
      3. Redemption row is inserted FIRST; a concurrent duplicate raises
         `DuplicateKeyError` → HTTP 400 "already redeemed".
      4. `used_count` is bumped via atomic `find_one_and_update` with a
         `used_count < max_uses` filter; overshoot rolls back the row.
    Verified concurrently: parallel double-redeems → exactly one success,
    parallel 3-users-for-2-slots → exactly 2 successes, no overshoot.
  - **SEC-004 (P3) — Cookie flags hardened.** `set_cookie` now emits
    `Secure; HttpOnly; SameSite=Lax`; the `Secure` flag is opt-out only
    via `COOKIE_SECURE=false` for local http dev.
  - **SEC-005 (P3) — CORS whitelist enforced.** `.env` `CORS_ORIGINS`
    switched from `*` to the explicit frontend origin. Backend refuses
    to fall back to `*` when the env is empty. Disallowed origins get
    400 "Disallowed CORS origin" from Starlette.
  - **SEC-006 (P3) — Rate limiting added.** Per-IP token-bucket
    middleware throttles the abusable endpoints:
      * `/api/auth/login` 10/min, `/api/auth/register` 5/min,
[بيانات البيئة السابقة محذوفة من نسخة النشر]
        `/api/coupons/redeem` 15/min, `/api/telegram/verify` 20/min.
    Returns 429 with `Retry-After` header. Verified: 8 rapid login
    attempts pass, subsequent ones return 429.
  - **SEC-007 (P3) — Regex injection in admin search fixed.**
    `/admin/users?q=` and `/admin/website-admins?q=` now run
    `re.escape(q)` before injecting into `$regex`, preventing arbitrary
    Mongo regex operators and ReDoS payloads.

- **Full migration to Wallet / Credit System (Feb 15, 2026)** — subscriptions & expiry ELIMINATED:
  - **Removed concepts**: subscriptionExpiresAt, plan-ends-in, trial_expires_at, subscription_status, active/expired/frozen states, frozen_token_balance, daily msg/img/file quotas, per-plan Bar meters, "Renew Subscription" copy, "Assign subscription" dialog with day-picker.
  - **Kept concepts**: token_balance, total_used_tokens, total_input_tokens, total_output_tokens, cached_tokens (internal, hidden from users).
  - **New wallet mechanics**:
    * New user → 5,000 welcome tokens (no expiry, no trial timer).
    * Credit packs: 1M/$5 (basic), 5M/$10 (pro), 15M/$20 (unlimited).
    * `POST /api/admin/users/{uid}/subscription {plan}` now ADDS pack tokens on TOP of existing balance (never replaces). Legacy `days` field ignored.
    * `GET /api/billing/packs` (public) lists the three packs.
    * `check_can_afford()` blocks any AI call when balance ≤ 0 → returns 402 `insufficient_tokens` with Arabic message "نفد رصيد التوكنات. يرجى شحن الرصيد للمتابعة." + CTA "شحن الرصيد".
    * `charge_user()` still applies the 1.5× multiplier on billable_input+completion; cached tokens subtracted from prompt_tokens first (DeepSeek-style discount).
  - **UI overhaul**:
    * `Dashboard.jsx` completely rewritten — hero Token Balance card, 3 usage stats (Used/Input/Output), Top-up section listing the 3 packs with "Contact admin" CTAs, Account info. No plan card, no bonuses, no expiry, no frozen.
[بيانات البيئة السابقة محذوفة من نسخة النشر]
    * `SubscriptionContext` still exists (kept for zero-diff import surface) — `isExpired` is a permanent `false`, `openRenewalModal` now opens a top-up dialog. `SubscriptionRequiredDialog` renamed conceptually to "Top up required" with Coins icon + Arabic copy.
    * `GateMessage.jsx`: `kind="topup"` renders the wallet card (Coins icon, "شحن الرصيد" button). Old `kind="subscription"` no longer emitted anywhere.
    * `ChatContext.jsx` maps 402 responses (both `insufficient_tokens` and legacy `subscription_required`) to `gate.kind = "topup"`.
  - **Backend simplifications**:
    * `auth.py::current_plan()` returns `"admin"` or `"wallet"` — no more expiry checks.
    * `auth.py::require_active_subscription()` is a no-op stub kept for import compat.
    * `auth.py::consume()` is a no-op counter (daily quotas gone).
    * `auth.py::/me` payload trimmed to: `plan`, `token_balance`, `total_used_tokens`, `total_input_tokens`, `total_output_tokens`, `telegram`. Legacy `subscription: null` remains as an inert field on old records.
    * `tokens.py::maybe_freeze_expired()` is a no-op stub (wallet model has nothing to freeze).
    * `tokens.py::admin_freeze_balance`/`admin_unfreeze_balance` endpoints kept as no-op stubs.
    * `server.py::chat_stream` and `files_process` removed the `require_active_subscription` gate — only Telegram membership + balance guard remain.
  - **Verified E2E** (curl + browser screenshots):
    A) Register → balance 5,000 · plan "wallet" · zero legacy fields
    B) Top-up 1M pack via admin → balance 1,005,000 (stacked)
    C) Chat streams smoothly (rAF-batched), balance drops
    D) Admin set-balance to 0
    E) Chat blocked → HTTP 402 `insufficient_tokens` Arabic message
    F) Re-topup 5M → chat resumes immediately
    G) /me contains ZERO banned fields (subscription_status, frozen_token_balance, trial_expires_at, plan_config, usage_today, effective_limits, active_bonuses, remaining_days)

- **True Real-Time Token Streaming (Feb 15, 2026)** — sub-second TTFT restored:
  - **Root cause**: `deepseek-v4-pro` enables internal reasoning by default (`reasoning_effort`≈high). The reasoning traces are streamed via `delta.reasoning_content` — a field our code never read — so the visible `delta.content` was delayed 2-16s and often arrived as a single bulk chunk. Backend logs previously showed `chunks=1 usage=5711+899` (899 output tokens in ONE SSE frame).
  - **Fix**: `chat_stream` now passes `extra_body={"thinking": {"type": "disabled"}}` by default, and a new `deep_think` request flag re-enables reasoning when the DeepThink toggle is on. Result: TTFT dropped from 2-16s → **~940ms in-browser / ~1.1s over the network**; a 60-word essay now emits 84 SSE chunks and 25 distinct UI commits (was 1).
  - **Logging**: `chat_stream done` now includes `ttft=<ms>` and `deep=<bool>` for observability.
  - **Frontend**: `streamChat()` accepts `deepThink`, `ChatContext` forwards `prefs.deepThink` on every stream — everything else (rAF-coalesced commits, Markdown streaming plain-text mode, memoized Message component) was already correct.
  - Verified via curl (localhost + external) and Playwright browser test: text appears progressively with ~5-13 new chars every 150ms.

- **Trial Tightening + Global 1.5× Billing Multiplier + Hidden Message Stats (Feb 15, 2026)**:
  - New user registration: trial duration reduced from **3 days → 24 hours** (`timedelta(hours=24)`), initial token pool reduced from **200,000 → 5,000** tokens. Applied in `backend/auth.py::register` and `PLAN_TOKENS['trial']` in `backend/tokens.py`.
  - **1.5× billing multiplier on ALL plans** (Basic / Pro / Unlimited / Trial). Applied inside `charge_user()` in `backend/tokens.py`: `billable_total = round((prompt-cached + completion) * 1.5)`. The pre-flight `check_can_afford()` intentionally uses the RAW estimate (not multiplied) so trial users can still make their first request. History rows keep raw `billable_input` / `billable_output` for auditing while `billable_tokens` reflects the multiplied deduction.
  - **Message-level usage stats hidden**: `Message.jsx` no longer imports or renders `MessageUsageStats`. Copy / regenerate / thumbs-up/down buttons still render. Sidebar `TokenBalanceChip` (aggregate balance) is unaffected.
  - Verified end-to-end via `testing_agent_v3_fork` iteration_7 — all backend/frontend assertions passed; charge_user(100, 200) now deducts 450 tokens (1.5×) as designed.

- **Token System v2 — Billable Cache Discount + Freeze/Unfreeze (Feb 15, 2026)**:
  - **Display fix**: Chat stats now show only the user's OWN input tokens (typed content), not the full padded prompt (which includes system + memory + dark-mode primer + history). Example: "hi" → Input: 2, Output: 281, Total: 283 (was previously Input: 6164 which was confusing).
  - **Cache-aware billing** (per DeepSeek pricing): `billable_input = prompt_tokens - cached_tokens`, `billable_output = completion_tokens`, `billable_total = billable_input + billable_output`. The user is charged `billable_total`. Cache hits are FREE — DeepSeek returns them in `prompt_cache_hit_tokens` and we subtract them from the charge.
  - **Cached is hidden from users**: SSE payload emits `{input, output, total, remaining}` only. The `cached_tokens`, `full_prompt_tokens`, `billable_tokens` are kept in `token_usage_history` for admin analytics.
  - **Freeze / Unfreeze**: When a plan expires (subscription or trial), any unused balance is moved to `frozen_token_balance` and `subscription_status` becomes `"frozen"`. Users cannot spend frozen tokens; admins see them clearly. On renewal (`admin_assign_sub`), frozen balance is restored + the new plan's allowance stacks on top. Example: user had 1.2M frozen → renews Basic → new balance is 1.2M + 1M = 2.2M.
  - **New admin endpoints**: `/api/admin/tokens/freeze`, `/api/admin/tokens/unfreeze`, `/api/admin/tokens/deduct` (in addition to existing add/set/reset). `admin_remove_sub` now freezes rather than zeros so nothing is ever lost by mistake.
  - **Dashboard rework**: Removed the three "Messages / Image analyses / File analyses remaining" cards. Replaced with a single **🪙 Token Balance** card showing Remaining · Used · Input · Output · Status + a "❄️ Frozen: N — restored on renewal" chip when applicable.
  - **History schema**: `user_input_tokens`, `assistant_output_tokens`, `full_prompt_tokens`, `cached_tokens`, `billable_input`, `billable_output`, `billable_tokens` — all in every row.
  - **Auto-freeze on session**: `check_can_afford` runs `maybe_freeze_expired(user)` before every spend, so if a plan expires mid-session the balance is atomically moved to frozen before any 402 is thrown.

- **Token-Based Billing System (Feb 15, 2026)** — DeepSeek/OpenRouter style:
  - New `backend/tokens.py` module. Uses `tiktoken` (cl100k_base) ONLY for pre-flight budget estimation. Actual charging always uses the real `usage` block DeepSeek returns via `stream_options: {include_usage: true}` at the end of every SSE stream.
  - New collection `token_usage_history`: `{user_id, conversation_id, model, input_tokens, output_tokens, cached_tokens, total_tokens, created_at}`. Also captures DeepSeek's `prompt_cache_hit_tokens` for analytics.
  - User document new fields: `token_balance`, `total_used_tokens`, `total_input_tokens`, `total_output_tokens`.
  - Plans re-configured: `basic` → 1M tokens / $5 / 20d, `pro` → 5M / $10 / 30d, `unlimited` → 15M / $20 / 30d. New users get 200k trial tokens on signup. Legacy `plan1/2/3` alias to Basic/Pro/Unlimited.
  - Idempotent startup migration (`migrate_legacy_users`) backfills `token_balance` for pre-existing subscribers based on their current plan. Chats/projects/files/memory untouched.
  - New endpoints:
    * `GET /api/billing/balance` — live balance for chip.
    * `GET /api/billing/usage` — history rows for the current user.
    * `POST /api/admin/tokens/{add,set,reset}` — admin controls (add adds, set replaces, reset zeroes).
  - `chat_stream` pre-flight guard: rejects with 402 `insufficient_tokens` (structured Arabic message + `Upgrade Plan` CTA) before any DeepSeek call when balance < estimated cost. After successful stream, deducts real `usage` and emits a final SSE `usage` event with `{input, output, cached, total, remaining}` so the client updates instantly.
  - `files/process` also charges based on extracted text length (real, not fixed).
  - Frontend: new `TokensContext` + `TokenBalanceChip` in sidebar (DeepSeek-style 🪙 4,218,442 Tokens, red when empty, yellow when low). Per-message stats block below every completed assistant response showing Input / Output / Total / Cached / Remaining. The `insufficient_tokens` 402 renders as the same inline gate card used for subscription expiry.
  - Admin exempt: `role in (super_admin, admin, moderator, support)` → unlimited (balance shows ∞).

- **Silent Gates: No-Modal-on-Login + Inline Chat Cards + Telegram Membership (Feb 15, 2026)**:
  - Removed the auto-popup on login for expired accounts — users can now browse their workspace freely.
  - Blocking happens ONLY when the user tries an AI action. The server returns a structured 402; the frontend renders an inline "gate" assistant message inside the chat (never a modal).
  - Two gate kinds are supported:
    * `subscription`: Arabic "انتهى اشتراكك…" card with **اشترك الآن** button → navigates to `#dashboard`.
    * `membership`: Arabic "يجب الانضمام…" card with one button per required group + **✅ تحقّق** button that calls `/api/telegram/membership-check` and refreshes the card in-place. On success it converts to a green confirmation.
  - New backend module `backend/tg_verify.py`:
    * Collection `tg_required_groups` (username, name, invite_link, order) + admin CRUD + reorder.
    * Setting `telegram_verification_enabled` (bool) togglable from the admin panel.
    * `require_membership()` guard called BEFORE `consume()` (subscription/quota) — order is: **membership → subscription → quota**, exactly as requested. Admins are exempt.
    * `/api/telegram/membership-check` uses Bot API `getChatMember` to verify the current user against every configured group and returns the full list with per-group joined status.
  - `DELETE /api/admin/users/:uid/subscription` (surfaced as **Remove Subscription** in the users tab) now wipes both `subscription` AND `trial_expires_at`, and clears usage counters — the user drops straight to `plan=expired` with nothing to exploit. Chats/projects/files/memory are untouched. Owner accounts are protected.
  - New admin tab **Telegram** with add/edit/delete/reorder + master toggle. Bot must be a member (ideally admin) of each configured group so `getChatMember` succeeds.

- **Strict Subscription Gate (Feb 15, 2026)**:
  - Removed the "free 20 msgs/day" fallback: users with expired trial AND no active paid plan now resolve to plan `"expired"` with all-zero quotas.
  - Added `require_active_subscription()` guard + `SubscriptionRequiredError` (HTTP 402) with a stable machine-readable body `{code:"subscription_required", feature, message, cta}` — Arabic-first message.
  - Guard is called from `consume()` (which runs before `chat_stream` and `files/process`) AND directly from `workspace.upload_file`. No AI compute is spent for an expired user under any endpoint.
  - Client: new `SubscriptionContext` wraps the workspace, auto-opens `SubscriptionRequiredDialog` when `plan==="expired"` or when any request returns 402 subscription_required. Clicking "Renew Subscription" navigates to the Dashboard subscriptions section.
  - `ChatInput` disables send + attach for expired users (server enforces the same). `ProjectSettingsDialog` upload path routes 402 to the modal.
  - Read-only endpoints (`/api/auth/me`, workspace listing) remain accessible so the user still sees their data behind the paywall.

- **Silent Auto Dark Mode + DeepSeek v4-pro (Feb 15, 2026)**:
  - Dark Mode became a per-conversation server-side flag (`conversations.dark_mode`) that defaults to `true` for every newly created conversation.
  - Silent grounding: when the client sends `dark_mode: true` with `/api/chat/stream`, the backend injects a hardcoded (user, assistant) primer turn between the system prompt and the user's first real message. NO round-trip, NO visible message bubble, NO client UI event.
  - The Dark Mode button in `ChatInput` is now an instant flip (client toggles state + PATCH `dark_mode` on server). The old confirmation "Dark Mode Activated." bubble and the large Chinese prompt block were removed from the client.
  - Legacy `hidden_context` chats still render correctly (backwards-compat).
  - DeepSeek model updated to `deepseek-v4-pro` in backend `.env` + server.py fallback + all three personalities in `ModelPicker.jsx` (label "V4").

- **Workspace Phase 1 — Projects, Conversations, Cross-device Sync (Feb 15, 2026)**:
  - New backend module `backend/workspace.py` with three MongoDB collections (`projects`, `conversations`, `messages`) and indexed queries.
  - Endpoints: bootstrap (auto-create "General" project), full CRUD for projects & conversations, `POST /conversations/:cid/turn` (idempotent-by-message-id atomic save of a user+assistant pair), `POST /migrate` (imports legacy localStorage chats).
  - Frontend: new `WorkspaceContext` (owns projects state, boots default project, refreshes on window focus), new `workspaceClient` fetch layer, new `ProjectSwitcher` dialog with icon & color pickers + favorite/archive/edit/delete.
  - `ChatContext` now loads conversations from the server per project, lazy-loads messages, saves every completed turn to the server, and persists dark-mode `hidden_context` server-side — while preserving the rAF-coalesced streaming engine untouched.
  - Migration: on first login per browser, any legacy `rsvx7-chats-v1` conversations are imported into the user's "General" project (idempotent — safe to retry).
  - Sidebar shows a "Project" pill at the top that opens the Workspace dialog; loading skeleton renders while conversations sync.
  - Data is per-user isolated (verified with 2 users); user B gets 404 on user A's ids.
  - Verified: 13/13 backend pytest + full Playwright frontend flow. Chat streaming unaffected.

- **Rebuilt Admin Auth + Owner Recovery (Feb 15, 2026)**:
  - New Owner: `admin-rsvx7` / `[بيانات حساسة محذوفة]` (super_admin, is_owner=true, full 12 permissions).
  - `seed_admin()` in `backend/auth.py` idempotently creates the Owner on every startup, repairs missing fields, demotes any accidental duplicate owners, and backfills legacy admin records missing `permissions`.
  - Fixed 4 narrow `role === "admin"` bugs across `App.js`, `TelegramGate.jsx`, `ChatLayout.jsx`, `Admin.jsx` that were rejecting super_admin/moderator/support and causing the /admin redirect loop.
  - New `frontend/src/lib/roles.js` helper (`isAdmin`, `isSuperAdmin`, `isOwner`, `roleLabel`) is the single source of truth for role checks.
  - Admins (any of the 4 admin roles) now bypass the Telegram gate entirely — no Telegram linking required for administrators.
  - Owner is fully protected server-side: `admin_delete`, `admin_set_status`, `admin_website_admins/patch|delete` all return 403 for `is_owner=true` targets.
  - Legacy `admin` account still logs in as `super_admin` (demoted from Owner) — full admin access preserved.
  - Verified end-to-end: 17/17 backend tests pass, full Playwright frontend flow passes for both Owner and legacy admin.

- **Rolled back Telegram Group Membership Access Control (Feb 15, 2026)**:
  - Deleted: `backend/tg_membership.py`, `frontend/src/components/MembershipGate.jsx`, `frontend/src/pages/AdminGroups.jsx`
  - Removed all related backend APIs (`/api/telegram/membership-status`, `/api/telegram/refresh-membership`, `/api/admin/tg-groups`, `/api/admin/bot-admins`)
  - Removed `enforce_membership_for_user` guards from `/api/chat/stream` and `/api/files/process`
  - Removed membership block from Telegram bot polling loop in `auth.py`
  - Dropped MongoDB collections: `tg_groups`, `tg_bot_admins`
  - Removed permissions `telegram_groups` and `bot_admins` from `ALL_PERMISSIONS`
  - Removed Groups tab from Admin panel; removed `<MembershipGate>` wrapper from `App.js`
  - **Preserved**: Telegram Account Linking, Admin RBAC, Coupons, streaming engine, personalities

## Already Implemented (Feb 2026)
- Chat UI with streaming, markdown, syntax-highlighted code blocks, copy/download/wrap/collapse
- Sidebar: pin/rename/search/delete/export/import; localStorage persistence
- Real DeepSeek integration (`/api/chat/stream`) with `deepseek-chat` / `deepseek-reasoner` selector in Settings
- Auto language detection (Arabic/English) with RTL bubble alignment
- File processing endpoint `/api/files/process`: PDF (pypdf), DOCX, image OCR (tesseract ara+eng), text/code (20+ ext). Scanned-PDF detection w/ helpful note.
- Drag-and-drop, file chips with processing status, mobile drawer, settings dialog
- Sonner toasts, framer-motion animations, Outfit/Inter/JetBrains Mono

## ⏭ Backlog — User-Approved Scope (start NEXT session with full token budget)

### Phase A — Auth + Vision (start here)
[بيانات البيئة السابقة محذوفة من نسخة النشر]
[بيانات البيئة السابقة محذوفة من نسخة النشر]
[بيانات البيئة السابقة محذوفة من نسخة النشر]
  - Logout
  - Remember Me (long-lived JWT)
[بيانات البيئة السابقة محذوفة من نسخة النشر]
  - **No external email reset** — admin resets via Phase C
  - Protected `/api/chat/stream` + `/api/files/process` (require JWT)
  - Frontend `/login`, `/register`, `/app` routes with route guards
  - **MUST call `integration_playbook_expert_v2` before auth code** (per system rules)
- [ ] **Fix image analysis (Vision)**: use OpenAI Vision (gpt-5.4) via EMERGENT_LLM_KEY for `.png/.jpg/.webp/.gif` files. Keep OCR fallback. Send image bytes (base64) when message attaches an image.
- [ ] Remove anonymous chat: redirect to /login when unauthenticated

### Phase B — Trial + Subscriptions + User Dashboard
- [ ] **Free trial**: 3 days from registration; daily limits 10 msgs / 2 images / 2 files. Auto-expire → chat locked.
- [ ] **3 plans**:
  - Plan 1: 50 msgs / 10 images / 10 files per day
  - Plan 2: 200 / 50 / 50 per day
  - Plan 3: Unlimited
- [ ] Daily reset at UTC midnight (or user TZ)
- [ ] **User dashboard** `/dashboard`:
  - Current subscription + expiration
  - Remaining today (msgs / images / files) with animated progress bars
  - Trial countdown
  - Usage history table
[بيانات البيئة السابقة محذوفة من نسخة النشر]
- [ ] Enforcement middleware on `/api/chat/stream` and `/api/files/process` (block when limit reached, decrement counters)

### Phase C — Admin Panel + Telegram + Security Hardening
- [ ] **Hidden admin panel** at `/admin` (separate login form, single admin)
[بيانات البيئة السابقة محذوفة من نسخة النشر]
[بيانات البيئة السابقة محذوفة من نسخة النشر]
- [ ] **User management table**:
  - username, registered_at, last_login, trial_expires_at, current_plan, remaining today (msgs/images/files), status (active/suspended)
[بيانات البيئة السابقة محذوفة من نسخة النشر]
- [ ] **Subscription management**:
  - Assign / remove / extend / set expiration / upgrade / downgrade / create custom plans
  - Per-plan editable msg/image/file caps (live update affects users on that plan)
- [ ] **Dashboard stats** (Recharts):
  - Total users / active / trial / premium counts
  - Total AI requests / images / files (all-time + monthly)
  - New registrations chart (last 30 days)
  - Daily / monthly usage charts
- [ ] **Telegram notifications**:
  - Bot token stored in admin-managed settings doc in MongoDB (NOT in .env so admin can edit)
  - Admin chat_id also editable
  - Send notification on: **new user signup** (username + timestamp), **plan activated/upgraded** (username + plan name)
  - Templates editable from admin panel (e.g., `"🆕 مستخدم جديد: {username} في {date}"`, `"✨ تم تفعيل {plan} للمستخدم {username}"`)
  - **Test button** in admin panel to send a test message using current token/chat_id/template
- [ ] **Security hardening**:
[بيانات البيئة السابقة محذوفة من نسخة النشر]
  - JWT with `HS256` + 7-day expiry, `Remember Me` = 30-day
  - HttpOnly secure cookies for refresh token
  - Rate limiting on `/api/auth/*` (slowapi)
  - Input validation (pydantic)
[بيانات البيئة السابقة محذوفة من نسخة النشر]
  - XSS: React escapes by default; sanitize markdown HTML
  - No SQL (using Mongo) — protect against NoSQL injection by strict pydantic schemas

## Database Collections
[بيانات البيئة السابقة محذوفة من نسخة النشر]
- `subscriptions` { id, user_id, plan_id, started_at, expires_at, active }
- `plans` { id, name, daily_msgs, daily_images, daily_files, unlimited:bool, custom:bool }
- `usage_counters` { id, user_id, date(YYYY-MM-DD), msgs, images, files }
- `usage_log` { id, user_id, type, created_at }
- `settings` { id, telegram_bot_token, telegram_chat_id, tpl_signup, tpl_subscription }
[بيانات البيئة السابقة محذوفة من نسخة النشر]

## ⚠️ Security Rules I Will NOT Break
[بيانات البيئة السابقة محذوفة من نسخة النشر]
[بيانات البيئة السابقة محذوفة من نسخة النشر]
- All `/api` endpoints except `/api/auth/login`, `/api/auth/register`, `/api/auth/admin-login` require valid JWT.

## Open Items User Confirmed
[بيانات البيئة السابقة محذوفة من نسخة النشر]
[بيانات البيئة السابقة محذوفة من نسخة النشر]
- ✅ Telegram bot: token + chat_id + message templates editable from admin panel, with test button
- ⛔ "Made with Emergent" badge removal → user must contact support@emergent.sh (platform-controlled)

## Next Action for User
Send "كمّل" (or "continue") in a new message and I will execute **Phase A** end-to-end in that turn with a fresh full-context budget, then Phase B in the message after, then Phase C.
