# ربط GitHub والتحديث بضغطة

بعد هذا الإعداد مرة واحدة: ارفع التعديلات إلى الفرع المحدد، ثم افتح **الإدارة ← الخوادم ← تحديث المنصة** بحساب المالك. لا تحتاج رفع ZIP وفكّه لكل تحديث. الزر يسحب إصدار المستودع؛ لا يستطيع استلام تعديلات بقيت في المحادثة ولم تُرفع إلى GitHub.

## 1. إنشاء المستودع ورفع المشروع الحالي

افتح https://github.com/new وأنشئ مستودعًا **Private** باسم `rsvx7-ai`، واتركه فارغًا دون إنشاء README. استبدل `YOUR_USERNAME` أدناه باسم حسابك.

على السيرفر، ارفع الحزمة المحدثة هذه المرة، وفكها داخل `/root/Ai` كالمعتاد. ثم:

```bash
apt update && apt install -y git
cd /root/Ai/RSVX7-AI
git init -b main
git config user.name "RSVX7"
git config user.email "YOUR_USERNAME@users.noreply.github.com"
git add .
git add -f frontend/build builder/dist
git status --short
git commit -m "RSVX7 platform with GitHub updater"
git remote add origin https://github.com/YOUR_USERNAME/rsvx7-ai.git
git -c credential.helper= push -u origin main
```

راجع قائمة الملفات قبل commit. `.env.selfhost` وملفات `.env` الخاصة و`private` وnode_modules وZIP والسجلات مستبعدة. لا تضف مفتاح AI أو كلمات مرور إلى المصدر. أوامر init/remote أعلاه لمستودع جديد فقط، فلا تكررها عند وجود ربط قائم.

عند طلب Username أدخل اسم GitHub. عند طلب Password أدخل **Personal Access Token** وليس كلمة مرور حساب GitHub. لإنشاء مفتاح الرفع: https://github.com/settings/personal-access-tokens/new ، اختر مستودع `rsvx7-ai` وحده، وصلاحية **Contents: Read and write**، وحدد انتهاء الصلاحية. أدخله في مطالبة كلمة المرور فقط، دون وضعه في عنوان remote أو سطر الأوامر. لا ترسله في المحادثة. يمكن استخدام GitHub Desktop على الكمبيوتر بدل أوامر الرفع هذه.

## 2. ربط خدمة التحديث على السيرفر

أنشئ مفتاحًا آخر من الصفحة نفسها خاصًا بالتحديث: اختر المستودع وحده و**Contents: Read-only**. هذا المفتاح لا يحتاج صلاحية الكتابة أو الإدارة. ثم نفذ من مجلد المشروع:

```bash
cd /root/Ai/RSVX7-AI
python3 scripts/platform_updater.py install --repository YOUR_USERNAME/rsvx7-ai --branch main
sh deploy/install-selfhost.sh
systemctl status rsvx7-updater --no-pager
```

البرنامج سيطلب مفتاح القراءة إدخالًا مخفيًا. يُحفظ في `/opt/rsvx7-updater/token` بصلاحية root فقط، خارج Git والموقع والحاوية. يشغّل المثبّت خدمة systemd مستقلة، ويُعاد بناء الموقع مرة واحدة لإظهار الزر وربط قناة الطلب. لا يغيّر إعداد الموقع أو كلمات مرور المالك أو قاعدة البيانات. رابط الموقع الحالي يبقى كما هو؛ هذه الميزة لا تضبط HTTPS تلقائيًا.

أعد فتح الموقع، ثم ادخل **الإدارة ← الخوادم**. سيظهر مستودعك وفرع `main` وزر **تحديث المنصة**. قد يحتاج ظهور جاهزية الخدمة بضع ثوانٍ. لا تُدخل بيانات VPS أو كلمة root في صفحة الخوادم لتفعيل هذا الزر؛ فهو يدير السيرفر الحالي عبر الخدمة المثبتة عليه.

## 3. التحديثات التالية

على نسخة التطوير المرتبطة بالمستودع، بعد تعديل المصدر وبناء الواجهة ومحرك Builder:

```bash
cd frontend
pnpm install --frozen-lockfile
pnpm build
cd ..
git add .
git add -f frontend/build builder/dist
git commit -m "Update platform"
git push origin main
```

يجب رفع ملفات الإنتاج أيضًا؛ الحزمة الحالية تتضمنها جاهزة. لا تشغّل أوامر بناء pnpm على VPS الصغير إن كنت تبني على جهاز التطوير. عند استلام ملفات مصدر معدلة منا مستقبلًا، يجب أولًا وضعها في مستودعك ورفعها، أو ربط أداة التطوير به. وجود زر التحديث لا ينشئ اتصالًا تلقائيًا بهذه المحادثة.

بعد نجاح push اضغط **تحديث المنصة**. يعرض: جلب الإصدار، فحص الملفات، البناء، التشغيل، فحص الجاهزية. لا ينفذ بناءً جديدًا إذا كان commit نفسه قد نجح سابقًا. يستمر العمل إن أغلقت الصفحة؛ قد ينقطع اتصال الموقع أثناء إعادة التشغيل، افتحه بعد قليل لمعرفة النتيجة.

بديل الزر بأمر واحد على السيرفر، يعمل حتى لو واجهة الموقع لا تفتح:

```bash
python3 /opt/rsvx7-updater/platform_updater.py request
```

## الحفظ والفشل

ملف الإعداد الأصلي يبقى في مكانه، وتبقى قاعدة البيانات والملفات في volumes التابعة لمشروع Compose الثابت `rsvx7`. لا تحذف المجلد الأصلي الذي يحتوي `.env.selfhost`، ولا تستخدم `down -v`. يُحفظ المصدر المسحوب في `/opt/rsvx7-updater/releases`؛ لا يحذف البرنامج الإصدارات القديمة تلقائيًا. راقب مساحة القرص.

عند فشل الجلب أو فحص الملفات أو البناء، يبقى الإصدار الجاري. عند فشل تشغيل الإصدار الجديد يحاول إعادة بناء وتشغيل المصدر السابق والتحقق منه. النتيجة تعرض هل استُعيد السابق أو تعذرت استعادته. هذه استعادة للتطبيق، وليست استعادة لقاعدة البيانات؛ تحديثات تغير مخطط البيانات تحتاج نسخة احتياطية وخطة ترحيل قبل تطبيقها. التحديث يعيد تشغيل التطبيق ويمكن أن يقطع توليد المشاريع الجاري؛ نفّذه عند توقف المهام.

الخدمة تعمل كـroot لتشغيل Docker، ولذلك المستودع والفرع المختاران مصدر موثوق تنفذ شيفرته على السيرفر. لا تضف مطورين غير موثوقين إلى صلاحية الكتابة. الواجهة لا تقبل رابط مستودع أو فرعًا أو أوامر shell من المستخدم، ولا يصل Docker socket أو مفتاح GitHub إلى التطبيق. إذا أردت تغيير المستودع، عدّل `/opt/rsvx7-updater/config.json` كـroot ثم أعد تشغيل الخدمة.

عند انتهاء المفتاح أو إلغائه، بدّله بإدخال مخفي:

```bash
python3 - <<'PY'
import getpass
from pathlib import Path
p = Path('/opt/rsvx7-updater/token')
value = getpass.getpass('New GitHub read-only token: ').strip()
if not value or any(c.isspace() for c in value):
    raise SystemExit('Invalid token')
p.write_text(value)
p.chmod(0o600)
PY
```

للتشخيص من السيرفر فقط: `systemctl status rsvx7-updater --no-pager` ثم `tail -n 60 /opt/rsvx7-updater/update.log`. لا تُرسل سجلًا يحتوي معلومات خاصة دون مراجعته. واجهة المستخدم تعرض مراحل ثابتة فقط.

الاختبارات المحلية تغطي صلاحيات المالك، حجب المفتاح، الطلب الثابت ومنع التكرار، أرشيف Git حقيقي مع رفض الروابط الرمزية، فشل البناء واستعادة المصدر السابق بمحاكاة Docker، وزر الواجهة. لم يُختبر ربط مستودع خاص حي أو systemd/Docker على VPS فعلي من هذه البيئة.

مرجع GitHub الرسمي للمفاتيح والصلاحيات والمصادقة: https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens

خدمة التحديث المنسوخة إلى `/opt/rsvx7-updater/platform_updater.py` مستقلة عن مصدر التطبيق؛ تعديل آليتها نفسها مستقبلًا يحتاج تحديث ملف الخدمة من root وإعادة تشغيلها، ولا يُستبدل العامل الجاري تلقائيًا أثناء تحديث الموقع.
