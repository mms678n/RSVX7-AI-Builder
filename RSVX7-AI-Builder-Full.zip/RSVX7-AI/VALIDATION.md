# التحقق من دمج RSVX7 Builder

التاريخ: 16 أكتوبر 2026. النتائج تخص المصدر المدمج في هذه الحزمة، باستخدام بيانات وردود نموذج اصطناعية دون تعديل موقع حي أو خصم رصيد حقيقي.

| التحقق | النتيجة |
| --- | --- |
| اختبارات React الأصلية والجديدة | 158 اختبارًا ناجحًا في 43 مجموعة |
| Python: VPS + Builder + اتصال وإعدادات AI + الجلسات + SSE + التخزين + تشفير الملفات + Manus Storage + الأصول | 118 اختبارًا ناجحًا، مع 7 تحذيرات تقادم للاعتماديات |
| محرك Node الحقيقي مع ردود نموذج fixture | 17 فحصًا ناجحًا؛ التخطيط يسأل قبل إنشاء الملفات، الأدوار الأربعة تتعاقب، ملفات كاملة ومراجعة ثم إشارة اكتمال |
| تنفيذ مشروع fixture الناتج | اختبارات HTTP والحفظ الفعلية نجحت بواسطة Node test runner، وليس فحص نصوص فقط |
| بناء React للإنتاج | نجح في CI الصارم دون تحذيرات ESLint؛ مع توليد المحرك والأدوات ثم ضغط الأصول |
| قفل pnpm | تثبيت offline بـ`--frozen-lockfile` نجح |
| اعتمادية SSH والتشفير | `pip check` ناجح؛ asyncssh 2.24.0 وcryptography 50.0.2؛ فحص صياغة مشغّلات shell ناجح |
| حزمة الإصدار | فحص وجود أصول asset-manifest والملفات المطلوبة، وتطابق gzip مع الأصل، ثم CRC وتطابق كل ملف ZIP مع المصدر |

## تحديث VPS والتشغيل المستقل

- اتصال SSH حقيقي بخادم loopback مؤقت؛ قراءة البصمة دون كلمة مرور، ثم دخول صحيح، ورفض بصمة مخالفة قبل إرسال كلمة المرور.
- اختبارات مالك/مسؤول/زائر، بيانات مشفّرة لا تعود عبر GET، تعارض الإصدارات، وعدم نقل بيانات الدخول المحفوظة إلى خادم آخر تلقائيًا.
- رفض عناوين metadata والشبكات الخاصة افتراضيًا، ورفض حقن shell في المضيف والمستخدم والمسار والرابط.
- النشر يحتاج فحص اتصال حديثًا، ويمنع مهمتين متزامنتين. اختبارات SSH adapter تحاكي رفع الحزمة والفشل والنجاح، ولا تعلن نجاحًا عند فشل الرابط العام، ولا تعرض مخرجات التيرمنال أو تضع مفتاح المزوّد في سطر الأمر.
- إنشاء إعداد خادمي بصلاحية 0600، وحفظ ملف الإعداد القائم كما هو، واستبعاد الأسرار والمجلدات الخاصة من أرشيف الرفع.
- اختبارات واجهة الخوادم: اعتماد البصمة قبل الحفظ، تصفير الحقول السرية، قفل النشر قبل فحص ناجح، حفظ مسودة التعديل أثناء polling، وإظهار فشل SSH دون تعطيل الأزرار دائمًا.
- التسجيل وبوابة الدخول في الوضع المستقل يتجاوزان ربط Telegram، مع بقاء رمز الاسترداد والجلسة الأصلية. السلوك القديم محفوظ عندما لا يُفعّل الوضع المستقل.
- مشغّل الكمبيوتر مختبر بأوامر Docker وهمية: تفعيل profile المحلي وتنزيل النموذج وفحص الجاهزية وحفظ الإعدادات في إعادة التشغيل. هذا لا يثبت تشغيل حاويات حقيقية.
- إعادة فحص خلفية تحتفظ بمعرّف الإصدار الأصلي، ولا تنفذ build/up/restart. نجاحها يستعيد رابط الإصدار دون إعادة بناء. تقرير الفحص يقبل معرّفات وأكوادًا محددة فقط، ولا يعيد raw output.
- اختبار HTTP حقيقي على loopback يتحقق من JSON الجاهزية وHTML؛ يرفض رقم إصدار قديم ولو كانت الخدمة تستجيب 200. أوامر Docker في هذا الاختبار وهمية.
- حفظ خادم أو مسار أو رابط جديد يمسح نتيجة النشر السابقة. سباق بدء النشر أثناء حفظ الإعدادات يرفض الحفظ دون تغيير الخادم.

## إعداد المفتاح من لوحة الإدارة

- اختبارات مالك/مدير/مستخدم: المالك وحده يحفظ المفتاح أو يفحصه، بينما يبقى اختيار النموذج بصلاحية `ai_models` الأصلية.
- تخزين المفتاح مشفّرًا في سجل إعداد AI الأصلي، وعدم عودته أو ciphertext في ردود الإعدادات أو فحص الاتصال.
- فشل مصادقة المفتاح أو تعارض revision لا يغيّر المفتاح المحفوظ. تغيّر سر التشفير يطلب إعادة إدخال المفتاح ولا يسقط بصمت إلى مفتاح البيئة.
- اختبار طلبين متزامنين يثبت احتفاظ كل منهما بمفتاحه أثناء التدوير. واختبار بث الدردشة يستعمل المفتاح المحفوظ والنموذج الإداري عندما يكون عميل بيئة الخادم غير مهيّأ.
- محاكاة HTTPX تتحقق من GET فقط إلى metadata والكتالوج، وعدم إرسال completion أو عودة label الخاص أو نص الخطأ الخام. تُغطى حالة الحد المجاني والاتصال المحلي دون مفتاح خارجي.
- واجهة المالك تحفظ المفتاح وتصفّر الحقل بعد الحفظ؛ المدير غير المالك لا يرى محرره، والفحص لا يحفظ المسودة، والاتصال المحلي لا يعرض حقل مفتاح.

## ما تغطيه الاختبارات الجديدة

- المصادقة وعزل ملكية المشروع؛ JWT تسجيل الدخول العادي لا يُقبل في نموذج المحرك الخاص.
- اختيار النموذج إداريًا، لا من طلب المستخدم؛ دالة الخصم الأصلية مع cache و1.5×، وسجل واحد لطلب الخصم المكرر.
- بوابة العضوية والرصيد قبل بدء الطلب، وإلغاء scope بعد الإيقاف.
- اعتماد تصور صحيح، request idempotency، ملفات ومسارات مسموحة وCAS عند تعديل نسخة قديمة.
- الرد المتأخر أو غير المكتمل لا يستبدل الملفات السابقة؛ التثبيت بعد الإشارة النهائية فقط.
- انقطاع اتصال المحرك يلغي بث المزوّد ويحرر lease؛ أخطاء حدود المزوّد تظهر برسالة الموقع الأصلية دون الجسم الخاص.
- الفحوص السبعة مرتبطة بنسخة المصدر، لا نتائج محفوظة لنسخة أقدم.
- الدخول إلى Builder من مسار التطبيق يمر ببوابة العضو نفسها.
- خانة الكتابة الأصلية تحتفظ بزر التعليمات والإضافة التلقائية، ولا تمسح طلبًا رفضه الخادم.
- بدء العمل لا يغيّر تبويب المعاينة، وإزالة الواجهة لا تستدعي إلغاء طلب الخادم.
- إيقاف WebContainer أثناء boot يمنع كتابة متأخرة؛ المتصفح غير المعزول يظهر المتطلب ويحفظ المصدر.
- خطأ المعاينة بعد العرض الأول يصل إلى مسار الإصلاح؛ تُرفض رسائل origins أو نوافذ أو أرقام تشغيل أخرى، وإخفاء التبويب لا يسبب إصلاحًا وهميًا لصفحة فارغة.
- الملفات التي فشلت إعادة كتابتها تبقى متعقبة، ثم تُزال عند استبدالها في الإصلاح التالي بدل بقائها كمصدر قديم في الحاوية.

## حدود الدليل

لم يُنفذ Docker build/run أو نشر على VPS حقيقي، ولم تتصل الاختبارات بقاعدة Mongo/MySQL حقيقية أو Manus Storage حقيقي أو مزوّد AI حي أو Ollama حي أو Telegram. SSH وحده جرى اختباره باتصال حقيقي محلي مؤقت. لم يتوفر تحكم متصفح للفحص البصري أو WebContainer حقيقي، لذلك لا تدّعي هذه النتائج نجاح معاينة حية لكل جهاز. اختبارات الواجهة تستخدم DOM اختباريًا؛ اختبارات runtime تستخدم SDK adapter وهميًا. اختبار المشروع الناتج الحقيقي نُفذ في مجلد مؤقت مستقل مع ردود نموذج fixture.

يحتاج التشغيل الإنتاجي إعدادات الموقع الأصلية وHTTPS ومتصفحًا متوافقًا وحفظ COOP/COEP. التوليد على الخادم يستمر بعد إغلاق الصفحة، لكن تشغيل الفحوص والمعاينة في هذا الإصدار يحتاج المتصفح. لا يوجد عامل sandbox خادمي أو queue موزعة لاستئناف المهمة بعد restart. مخطط التخزين الأصلي لم يُغيّر؛ اختبارات JSON document operations تغطي عمليات Builder دون إثبات اتصال قاعدة إنتاج.

`VALIDATION_PRE_BUILDER.md` والتقارير الأقدم سجل للمشروع المرفق. لا تمثل اختبارًا حيًا أو نشرًا لهذه الحزمة. لم تُنشر النسخة المدمجة تلقائيًا.

## إعادة الفحوص

```bash
# بعد تثبيت requirements.lock واعتماديات frontend:
python -m pytest -c /dev/null tests/test_ai_connection.py tests/test_vps.py tests/test_builder.py tests/test_ai_settings_regressions.py tests/test_session_config.py tests/test_sse_transport.py tests/test_persistence_config.py tests/test_file_crypto.py tests/test_manus_storage.py tests/test_asset_serving.py -q
cd frontend
CI=true pnpm test --watchAll=false --runInBand
pnpm test:builder
CI=true GENERATE_SOURCEMAP=false pnpm build
cd ..
python scripts/package_release.py
```

اختبارات قواعد البيانات/المزوّد القديمة التي تطلب خدمات حية لم تدخل في هذه المجموعة. استخدم بيئة اختبار معزولة لتشغيلها، لا قاعدة الموقع الفعلية.

## إصلاح HTTP لإنشاء طلب Builder

استبدال الاستدعاء المباشر لـ crypto.randomUUID بمولّد معرّفات يدعم getRandomValues عند غياب randomUUID على HTTP، مع مسار توافق قديم لمعرّفات الطلب فقط وليس رموز الدخول. نجحت 5 اختبارات موجهة (3 جديدة و2 اختبارات Workspace سابقة). الأعداد السابقة أعلاه تخص الفحص الكامل السابق؛ لم يُعد تشغيله لهذا التغيير. يظل HTTPS مطلوبًا لمعاينة WebContainers.

## تحديث GitHub على السيرفر

تاريخ التحديث: 16 أكتوبر 2026. إعادة الفحص الكامل المحدد أعلاه: 158 اختبار React في 43 مجموعة و118 اختبار Python، وبناء إنتاج ناجح. أضيفت 9 اختبارات Python و2 للواجهة لمسار التحديث، مع بقاء فحوص HTTP السابقة.

- API للمالك فقط، لا يعيد أسرار GitHub، ولا يأخذ مستودعًا أو أوامر من المتصفح. الطلب ثابت بإنشاء حصري لمنع التكرار؛ لا يقبل مهام عند غياب نبض خدمة المضيف.
- خدمة systemd على المضيف، ملفات المفتاح root-only، قناة طلب منفصلة؛ Docker socket غير موجود داخل التطبيق.
- اختبار فعلي محلي لـ git archive ورفض symlink؛ بيانات المفتاح لا تتحرر لمضيف أو مستودع مختلف في credential helper.
- فشل بناء يحتفظ بالمصدر السابق، وفشل تشغيل يحاول استعادة المصدر السابق، ونجاح يحفظ commit ويمنع إعادة البناء للنسخة نفسها. أوامر Docker لهذه السيناريوهات محاكاة.
- لوحة التحديث تقفل الزر عند عدم الإعداد أو انتظار التنفيذ، وتعرض المستودع والمراحل دون التيرمنال.
- لم يُنفذ ربط GitHub حي أو تثبيت systemd أو تشغيل Docker/VPS حقيقي لهذه الميزة من البيئة الحالية. التحقق التشغيلي النهائي يتم بعد تركيبها على السيرفر. الاستعادة تخص شيفرة التطبيق؛ ليست نسخًا احتياطية أو استعادة لبيانات تغير مخططها.

## إصلاح توافق ردود التخطيط

17 أكتوبر 2026: نجحت 17 حالة في محرك Node الحقيقي مع ردود مزوّد اصطناعية، منها JSON داخل نص أو Markdown وفواصل زائدة، وتصحيح pages من نوع غير صحيح مع إرسال الرد السابق وأخطاء الحقول للنموذج. تستمر بوابة المخطط في رفض الحقول المطلوبة المفقودة والرد المبتور والرد متعدد التصورات؛ لا يخرج أي ملف من مرحلة التخطيط. التصحيح محدود بطلب إضافي واحد، وهو استدعاء نموذج عادي يخضع لمحفظة المنصة. لا نملك الرد الخام للنموذج من VPS المستخدم ولم يُختبر Hermes حيًا هنا؛ هذا اختبار لمسار التعامل مع الصيغ وليس ضمانًا لاستجابات كل مزوّد.

## Integrated streaming audit — 2026-10-17

This release audits native chat transport/state, Builder job persistence and polling,
provider cleanup, preview adapter boundaries, administrator model configuration,
source ownership/revisions, and update integration. It is not an assertion that
all possible production failures have been eliminated.

### Corrections

- Chat no longer erases an already streamed answer/reasoning when a late wallet
  error arrives. Partial output is committed through the existing durable turn
  outbox as an interrupted response. Gates still work before output begins.
- Late text callbacks after a terminal error cannot change that committed answer.
- Malformed/non-object SSE data now fails explicitly instead of silently dropping
  text and subsequently reporting success. The existing backend single-line JSON
  SSE contract, heartbeat comments and split UTF-8 decoding are preserved.
- Structured HTTP 429 explanations survive client error handling, so a specific
  provider quota explanation is not replaced by a generic limit message.
- Both chat and Builder bound provider stream cleanup to five seconds before
  releasing their generation lease, including cancellation and close errors.
- Builder rejects superseded polling responses and suspends background polls
  while submitting. An older snapshot cannot revert a newly accepted job.

### Verification

- Full frontend suite: 165 tests across 43 suites passed.
- Selected isolated backend suites: 121 tests passed, 7 deprecation warnings.
  Covers Builder ownership/approval/cancellation, model configuration, session
  settings, SSE heartbeat/backpressure/cleanup, VPS configuration, updater,
  persistence configuration, file encryption/storage and asset serving.
- Private engine: 17 fixture-driven checks passed, including structured proposal
  correction, bounded retry, specialist ordering, explicit completion and generated
  fixture HTTP/persistence tests.
- Added regression cases cover corrupt SSE, individual UTF-8 byte chunks, late
  wallet failure, stale terminal callbacks, old Builder polls and hung cleanup.

### Remaining deployment validation

No production provider calls, paid requests, SSH changes, Docker deployment,
real Mongo/MySQL integration suites, or live WebContainer browser checks were
performed during this audit. The actual VPS is not updated by downloading this
archive. Preserve its existing environment and database volumes when installing.
Browser execution still requires HTTPS/cross-origin isolation and a compatible
browser. Builder generation survives leaving the page while the backend stays
running; host restart recovery is marked failed with prior files retained, not a
durable resume queue. Provider quota/capacity errors cannot be fixed by client code.
Successful provider calls use the existing wallet accounting; partial failed or
cancelled requests retain its existing charging policy (no new billing policy was
introduced). A successful fixture build does not prove every generated project
works; each generated project must pass its own checks and preview validation.

## Smooth chat streaming — 2026-10-17

The existing React external stream store now paces the display channel separately
from the received text. Network bursts reveal progressively, with adaptive speed
and catch-up on the first animation frame after a 300ms smoothing window. This is
an independent implementation inspired by modern chat UX, not Claude's code or
an exact reproduction of its timing. Provider speed and network latency remain
outside the UI's control.

- Received text remains immediately readable for persistence and cancellation.
- Terminal/error/visibility flushes reveal all buffered text without animation delay.
- Intl.Segmenter protects grapheme boundaries (Arabic marks and joined emoji);
  older browsers use a code-point fallback with combining-mark/ZWJ handling.
- Reduced-motion preferences bypass pacing and disable the new subtle dot pulse.
- Generation guards prevent old animation callbacks from disturbing a new stream.
- Existing incremental Markdown, code blocks and native model/wallet integration
  remain in use; no additional external service or package is required.

Full frontend suite passed: 170 tests in 43 suites. New cases verify bounded burst
catch-up, immediate lossless persistence, Unicode boundaries, terminal flushes,
reduced motion and cross-message isolation. A targeted final stream-store rerun
follows the last generation-guard edit. Live mobile/browser visual acceptance and
production provider/VPS verification were not performed in this change.

## Builder questionnaire and recovery — 2026-10-17

The question chips previously sent an independent model request on every click.
They now form one editable questionnaire: a single choice for exclusive questions,
multiple choices for feature questions, optional custom answers, and one explicit
submit button after all questions are answered. Legacy cards without a selection
mode accept multiple choices. Drafts are scoped to account/project/question card
in session storage. Accepted answers are also stored with the conversation.
Historical question cards cannot submit against a newer proposal.

The server validates the current card ID, every question, and every selected option.
Incomplete, duplicate, unknown, or stale answers cannot start work. A conversation
CAS prevents a second tab from overwriting newer planning state at the same source
revision. Retrying a failed/cancelled request preserves its original action and
history without appending another user message; a source edit invalidates that retry.
An ambiguous transport retry reuses the original request ID in the mounted UI.
Retries of code repairs preserve the repair path, and resumed agent state is applied
after runtime initialization. An accepted job is not treated as rejected merely
because its follow-up refresh failed. Completion clears the earlier request error.

Planning retains the complete structured questions and options in model history.
The Builder output protocol explicitly takes precedence over generic chat formatting
instructions. Planning requests JSON output only when the administrator's selected
model advertises response_format support. A failed format gets one bounded correction
with field feedback; duplicate options, truncated JSON and multiple plan objects
(including separate studioPlan wrappers) still fail closed. No source execution is
authorized by answering questions. Explicit approval remains required.

Verification for this update:

- Full frontend: **176 tests in 43 suites passed**, including batched answers,
  selection changes, saved drafts, locked historical cards, idempotent transport
  retry, failed-job retry, repair preservation, and previous streaming regressions.
- Isolated backend: **131 tests passed**. This includes full-answer validation,
  retry/history preservation, cross-tab CAS, stale-source retry rejection, supported
  and unsupported JSON mode, plus previous auth, wallet, stream, deployment and
  persistence contracts.
- Private engine: **24 fixture-driven checks passed**, including complete question
  history, selection modes, proposal approval boundary, format correction, ambiguous
  wrappers and actual HTTP/persistence tests of the generated fixture project.
- Production frontend/engine build passed under CI, followed by gzip/Brotli asset
  generation. Existing test-mock React warnings and dependency deprecation warnings
  remain; no test failures or production compilation errors occurred.

The reported VPS response itself was not available as a raw provider log. These
changes fix observed local control-flow/format problems and verify them with fixtures;
they do not prove that every live model response will be valid. HTTPS/browser preview,
provider quotas and real database/deployment limits described above still apply.

For an existing VPS install, replace application files while retaining the original
`.env.selfhost`, Docker volumes and account data, then run `sh deploy/install-selfhost.sh`
from the project directory. The archive includes the compiled frontend and engine.
Do not regenerate database credentials or remove volumes to install this update.

## Independent platform model assignments — 2026-10-17

Administration now assigns provider model IDs separately to KaliGPT, DeepDark and
rsvx7, with a shared default for empty assignments. The existing ai_models permission
is required; provider credential changes remain owner-only. Distinct assignments
are checked against the provider catalog before one atomic settings update. Invalid
assignments and stale/concurrent edits preserve previous settings and credentials.
Legacy default-only updates retain explicit profile overrides. No database migration
or new credential is required.

Native chat selects the server assignment by platform profile, ignoring an arbitrary
provider model supplied by the browser. Public capability metadata is per profile,
so reasoning controls and model labels follow the selected provider. Saving settings
refreshes capabilities without being suppressed by the focus refresh cooldown.
The model picker no longer claims every profile runs Hermes. Builder also exposes
the picker and pins a credential-free model/capability snapshot for all agents in
each accepted job. A retry preserves the prior request/history but can use the user's
new profile selection and the current administrative assignment.

The original wallet policy, cached-token calculation, permission gates and encrypted
provider key store are unchanged. Tests verify the actual provider model passed to
chat and Builder fixtures and recorded by wallet charging, not only displayed labels.

Final combined checks: **180 React tests (43 suites), 145 isolated backend tests,
and 24 private-engine fixture checks passed**. This includes per-profile mapping,
inheritance/reset, all-or-nothing validation, settings CAS, unauthorized access,
reasoning controls, fresh capability discovery, job pinning, switching the model on
retry, and all earlier questionnaire/stream/runtime regression suites. Model replies,
databases and Docker adapters remain fixtures; live provider completions, production
database integration and VPS/browser acceptance were not performed.

The final production build also passed with engine/runtime regeneration and 38
precompressed assets. The full archive is checked for required assets, compressed
asset freshness, credential exclusion, CRC integrity and exact source-byte matches.
