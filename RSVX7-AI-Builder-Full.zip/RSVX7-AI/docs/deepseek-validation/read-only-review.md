# تقرير مراجعة مطابقة DeepSeek — قراءة فقط

**المشروع:** `/home/ubuntu/rsvx7ai`  
**المرجع المطلوب:** `docs/deepseek-reference/REFERENCE.md` وصور `chat-thinking.png` و`composer.webp` و`sign-in.webp`، مع `plan.md` و`TODO.md`.  
**النطاق:** فحص ساكن للواجهة ومساراتها فقط. لم أقرأ `backend/.env` أو `private/` أو قاعدة البيانات أو مفاتيح، ولم أعدّل كود المشروع أو أشغّل browser/build/test أو أوقف خدمة.  
**الحالة:** لا يوجد ادعاء pixel-perfect؛ المرجع العام لا يغطي الصفحات الخاصة/الإدارة، واللقطات ليست من إصدار واحد.  

## الخلاصة التنفيذية

- **الاتجاه العام صحيح:** الطبقة الحالية تطبق لغة DeepSeek البسيطة مع إبقاء لوحة RSVX7 الداكنة والبورغندية، لا لوحة DeepSeek الزرقاء. شريط الدردشة على اليسار بعرض **260px** في سطح المكتب، والمحرر rounded 24، وأزرار DeepThink/Search وإرسال دائري، ورسائل المساعد بلا بطاقة/صورة مستخدم.
- **الألوان الأساسية لم تتغير عن `fd812ff`:** قارنت متغيرات الجذر في `frontend/src/index.css`؛ القيم الحالية هي نفسها `#101318`, `#181c24`, `#222833`, `#30353f`, `#9d3e59`, `#e69bb0`. التغيير في الملف الجذري هو إضافة قواعد هندسية DeepSeek في الأسطر `173–206` فقط (34 سطر إضافة، بلا حذف)، وليس تبديل المتغيرات.
- **Hermes لم يُستبدل من طبقة الواجهة:** `aiClient.js:1` يصرح بأن النموذج الفعلي يختاره الخادم، و`ModelPicker.jsx:13–19` يعرض الشخصيات فقط و`backendModelFor` لا يفرض نموذج DeepSeek. لا يمكنني إعادة إثبات معرّف Hermes من الخادم لأن ذلك خارج النطاق المقصود.
- **التفكير الحقيقي مضبوط جيدًا:** `ChatContext.jsx:566–567,600–605` لا يرسل طلب native reasoning إلا عندما تعلن capability ذلك، ويقبل reasoning من callback المزوّد فقط. `Message.jsx:20–29,95–113` يعرض اللوحة عند وجود نص فعلي فقط؛ الانتظار بلا reasoning يعرض «جارٍ التوليد…» ولا يخترع نصًا. Search معطل وموسوم بأنه غير مهيأ.
- **الميزات الحرجة لم تُسقط في القراءة الساكنة:** التاريخ/البحث/المشاريع/إعادة التسمية/التثبيت/التصدير/الاستيراد/الحذف، المرفقات، Enter وShift+Enter وIME، الحفظ وإعادة المحاولة، الإيقاف، النسخ، التعديل، إعادة التوليد، الحساب والإعدادات، Telegram، لوحة الحساب، وتبويبات الإدارة ما زالت ظاهرة في الشجرة.
- توجد **ثلاث نقاط أولوية** تستحق معالجة/تحقق لاحق قبل ادعاء اكتمال المطابقة: empty state ليس له wrapper واحد يجمع التحية والمحرر، overlay الجوال موضوع تحت parent `pointer-events:none` بلا reset صريح، ومسار Admin يملك fallback إلى تبويب users حتى عند غياب كل الصلاحيات. كما توجد طبقات CSS مكررة تجعل النتيجة معتمدة على ترتيب الاستيراد.

## ما تم تأكيده

### 1) المرجع والقيود

`REFERENCE.md:5–15` و`plan.md:67–86` متسقان مع القرار «إبقاء Hermes ومطابقة الواجهة فقط»: تثبيت الألوان والهوية والبيانات والصلاحيات، لا OAuth وهمي، لا Search عامل دون خادم، ولا reasoning معد مسبقًا. الصور فُحصت بصريًا؛ `chat-thinking.png` يؤكد رأس التفكير القابل للطي والمؤقت والخط الجانبي، و`composer.webp` يؤكد المحرر المركزي والأزرار pill، و`sign-in.webp` يؤكد نموذج الدخول الواحد. لا تتوفر لقطة موثوقة للصفحات الخاصة، لذلك لا يمكن إثبات مطابقة تلك الصفحات حرفيًا.

### 2) الجذر والألوان والحركة

- `frontend/src/index.css:6–20`: متغيرات `--ds-*` الحالية مطابقة للقيم المرجعية؛ لا يوجد أزرق DeepSeek في متغيرات الجذر.
- `frontend/src/index.css:37–50,169–171,197–205`: الحركة قصيرة، مع `prefers-reduced-motion`، بلا blur/glass على كامل الشاشة.
- **ملاحظة cascade وليست تغيير لون:** `index.css:53–67` ثم `173–181` يعيدان تعريف `.ds-button`, `.ds-panel`, `.ds-input`, `.ds-page h1` و`.ds-tabs`؛ و`107–124` يبقي layout المصادقة القديم بينما `184–205` يضيف override `seek-auth`. النتيجة الحالية مفهومة، لكن الاعتماد على قواعد لاحقة يجعل صيانة الهوية أصعب.

### 3) الشريط والدردشة والمحرر

- `frontend/src/components/chat/chat-ui.css:22–24,56–57`: `direction:ltr` للشريط/المحتوى، والشريط أول عنصر وبعرض `260px` على سطح المكتب؛ المحتوى RTL.
- `chat-ui.css:149–164`: درج جوال كامل بعرض `min(88vw,320px)`، مع إخفاء/فتح وحواف مناسبة.
- `ChatLayout.jsx:120–159`: رأس صغير بعنوان مركزي، سجل رسائل، زر عودة لآخر الرسائل، ومحرر ينتقل منطقيًا من `data-position="center"` إلى `bottom` بعد وجود الرسائل.
- `Sidebar.jsx:104–164`: التاريخ، بحث التاريخ، المشاريع، البحث العام، استيراد/تصدير، rename/pin/delete، الرصيد، الحساب، الإعدادات، Dashboard، Admin، logout وTelegram كلها ما زالت مربوطة.
- `ChatInput.jsx:75–88,111–142`: Enter يرسل وShift+Enter يترك سطرًا، وIME محمي، والمرفقات/المعالجة/الحفظ وإعادة المحاولة والإيقاف/الإرسال محفوظة. `113–138` ينقل ModelPicker وDark Mode إلى «أدوات إضافية» كما طلب المرجع.
- `deepseek-composer.css:7–19,66–143`: شكل editor قريب من المرجع، دون shadow ثقيل أو لون أزرق. `web-search-btn` في `ChatInput.jsx:118–120` معطل عندما `webSearchSupported` ليس true، وtooltip يذكر صراحة أن البحث غير مهيأ؛ هذا صحيح وليس فقدانًا للميزة.

### 4) التفكير والبث

- `frontend/src/context/streamStore.js:80–113,115–185`: `pushReasoning` و`getReasoningSnapshot` منفصلان عن المحتوى، والتحديث frame-paced، مع flush/stop يمنع بقاء stream قديم.
- `ChatContext.jsx:509–605`: مراحل `connecting/thinking/streaming/finalizing`، reasoning منفصل، والحفظ النهائي يتضمن `reasoning`, `reasoning_duration_ms`, `reasoning_started_at`, `finish_reason`.
- `ChatContext.jsx:779–801`: `setDeepThink` مقيد بالقدرة الحقيقية، `webSearchSupported:false` و`setWebSearch` لا يبدآن بحثًا وهميًا، وعقد `useChat` يتضمن `reasoningSupported`, `reasoningMandatory`, `aiModel`, `webSearchSupported` والتوابع المطلوبة.
- `Message.jsx:20–29,45–60,69–79,99–113`: اشتراك reasoning منفصل للرسالة النشطة، مدة فعلية، collapse مع `aria-expanded`, وعدم إنشاء لوحة أو timer مستمر عندما لا يصل نص reasoning من المزوّد. `aiClient.js:100–107` لا يمرر إلا الحقل `r` القادم من SSE إلى callback.
- **حكم Hermes:** الواجهة لا تطلب native reasoning عندما capability الحالية false، ولا تبدّل اسم النموذج قبل رد المستخدم. إثبات «Hermes الحالي فعليًا» من الخادم غير مشمول عمدًا بهذه المراجعة.

### 5) المصادقة والحساب والإعدادات

- `Primitives.jsx:40–52` يستخدم AuthShell واحدًا؛ `index.css:184–196` و`auth-ui.css:2–30` يثبتان المركز والعرض الأقصى **336px** ويخفيان story.
- `Login.jsx:62–110`, `Register.jsx:171–195`, `Recover.jsx:57–79`: نفس السطح pill للحقول والأزرار، مع الوظائف اللازمة فقط. لا أزرار Google/Apple/OAuth مصطنعة؛ هذا متعمد لأن القوائم غير مهيأة.
- التسجيل لا يفقد رمز الاسترداد أو خطوة Telegram: `Register.jsx:135–165` يعرض الرمز مرة واحدة، النسخ، deep link، حالة bot غير المهيأ وإعادة المحاولة.
- `Sidebar.jsx:143–162` يفتح account/Dashboard/Admin/settings/logout؛ `SettingsDialog.jsx:101–181` يحافظ على model status، حالة DeepThink/Search، suffix، coupon، حذف محادثات المشروع ورسائل الصلاحيات.
- `App.js:15–18,40–56`: مسارات hash هي chat/dashboard/admin، مع منع غير المدير من Admin وبقاء Telegram gate للمسارات اللازمة.
- `Dashboard.jsx:541–587`: تبويبات الرصيد والاستخدام والكوبون والدعوات والحساب/الأمان وتغيير كلمة المرور. `Admin.jsx:23–31,41–45,119–160,165–178`: تبويبات المستخدمين/المؤشرات/القسائم/المديرين/Telegram/الإعدادات/AI model، والتحميل lazy/المخزن والصلاحيات حسب `can()`.

## الإجراءات ذات الأولوية — أسطر دقيقة

| الأولوية | الدليل | finding مؤكد/مخاطرة | الإجراء المقترح، دون حذف feature |
| --- | --- | --- | --- |
| **P1 — مطابقة empty state** | `ChatLayout.jsx:134–159`؛ `chat-ui.css:44–53` | التحية داخل `.chat-scroll`، بينما `ChatInput` داخل `.chat-composer-dock` الشقيق والمطلق؛ كلاهما تحت `.chat-main` لكن ليسا داخل empty-stage واحد. هذا يحقق الشكل العام، لكنه لا يحقق حرفيًا شرط «Welcome + composer نفس DOM/المرحلة ثم سفلي» وقد يفصل المحرر عن التحية عند اختلاف الارتفاع. | اجعل empty state stage واحدًا عند `!hasMessages` يجمع `WelcomeState` و`ChatInput` مع الحفاظ على `data-testid="welcome-state"` و`chat-input-container`، ثم بدّل stage إلى dock سفلي عند أول رسالة. لا تعِد typewriter أو scroll أثناء البث. |
| **P1 — صلاحيات Admin** | `Admin.jsx:43–46,67–68,126–129,165–169` | عند `allowedTabs=[]` يُستخدم `firstAllowedTab="users"`، والـrender يطابق `tab === "users"` حتى إن لم تكن `can("users")`. `loadUsers` يتوقف مبكرًا، لذلك لا يثبت تسريب بيانات، لكنه يترك صفحة/تبويب users ظاهرًا لمسار مدير بلا صلاحية. | اجعل fallback `null` مع حالة «لا توجد صلاحيات»، واحرس كل section بشرط permission (`tab === value && can(permission)`). لا تعتمد على الحماية الخلفية وحدها في عرض الواجهة. |
| **P1 — overlay الجوال (تحقق يدوي مطلوب)** | `ChatLayout.jsx:107–109`؛ `chat-ui.css:42,149–152` | slot الجوال يملك `pointer-events:none`، والشريط فقط يعيد `pointer-events:auto`; backdrop له `onClick` لكن لا يوجد له reset صريح إلى `pointer-events:auto`. هذه مخاطرة CSS ساكنة قد تجعل النقر خارج الدرج لا يغلقه، ولم أجرِ browser لتأكيد computed style. | أضف `pointer-events:auto` إلى `.chat-backdrop` أو انقل reset إلى child overlay، ثم تحقق مرة واحدة عند viewport جوال. لا تغيّر زر الفتح أو drawer width. |
| **P2 — تقليل style overrides** | `index.css:53–67,106–124,173–205`؛ `Dashboard.jsx:30–31`؛ `dashboard-ui.css:1–14,192–198`؛ `deepseek-account.css:14–33,215–220` | نفس selectors/tokens معرفة أكثر من مرة؛ Dashboard يستورد `dashboard-ui.css` ثم `deepseek-account.css`، و`.dashboard-ui .ds-panel { border-radius:4px }` يتنافس مع 16/18px لاحقًا. لا يوجد فقد feature مؤكد، لكن النتيجة تعتمد على ترتيب الاستيراد وقد تعود لوحة غير DeepSeek إذا تغيّر الترتيب. | وحّد tokens/قواعد account في ملف واحد أو ضع override DeepSeek في layer واضح، واحذف التكرار غير الضروري بعد مقارنة computed styles. لا تغيّر قيم `--ds-*`. |

## الميزات الحرجة التي لم يظهر إسقاطها

- **التاريخ والمحادثات:** إنشاء، اختيار، بحث، إعادة تسمية، تثبيت، تصدير، استيراد، حذف (`Sidebar.jsx:81–97,133–162`).
- **المشاريع والبحث العام والإعدادات:** ProjectSwitcher وProjectSettingsDialog وGlobalSearchDialog وSettingsDialog (`Sidebar.jsx:101–129`; `SettingsDialog.jsx:101–181`).
- **المحرر:** النص، Enter/Shift+Enter/IME، 8 مرفقات بحد 25MB، FileChip، Dark Mode، ModelPicker، save retry، إرسال وإيقاف (`ChatInput.jsx:15–18,75–142`).
- **الرسائل:** user edit، copy، assistant markdown، reasoning الحقيقي القابل للطي، regenerate، like/dislike، usage (`Message.jsx:99–126`).
- **الهوية والحساب:** Auth، recovery code، Telegram link/gate، Dashboard tabs، password change (`App.js:47–56`; `Register.jsx:135–165`; `Dashboard.jsx:541–587`).
- **الإدارة والصلاحيات:** users، stats، coupons، website admins، Telegram، settings، AI model، conditional actions وwrite-only bot token (`Admin.jsx:23–31,101–160,165–178`).
- **غير المهيأ عمدًا:** OAuth غير مضاف، Search composer معطل/موضح، وDeepThink غير متاح عند capability false؛ لا ينبغي تحويل أي منها إلى نجاح وهمي.

## هل توجد validation hooks فعلية؟

**الإجابة القصيرة: لا يوجد hook تنفيذي مخصص لـ desktop/mobile/root CSS validation في المستودع الحالي.**

- `frontend/package.json:67–71` يوفر فقط `start`, `build`, `test`؛ لا يوجد Playwright/Puppeteer/Cypress أو script computed-style/screenshot.
- يوجد سجل سابق ساكن في `docs/performance/audit.json:1–16` بأسماء فحوص جوال/إدارة، وقياسات سابقة في `docs/performance/release.json`. هذا **دليل تاريخي** وليس runner يعيد فحص التغييرات الحالية، ولا يثبت المطابقة البصرية لـ DeepSeek أو CSS root الحالي.
- `VALIDATION.md:3,38–43` و`UI_UX_REPORT.md:31–66` يصفان build/React وفحص متصفح معزولًا سابقًا، مع provider محلي محاكى؛ لا ينبغي إعادة نسب نتائجه إلى هذه المراجعة أو استخدامه كـpixel comparison.
- ما تم فعليًا هنا هو static evidence: مقارنة متغيرات root مع `fd812ff`، قراءة JSX/CSS والعقد والاختبارات الموجودة، وفحص الصور المرجعية. لم أشغّل قبولًا شاملًا متكررًا، ولم أفتح browser تنفيذًا، ولم أقرأ backend/private/env/DB.
- عند الحاجة إلى إثبات P1 أعلاه، يلزم queue منفصلة **NoFramework / no Git writes** لفحص viewport واحد desktop وواحد mobile وcomputed styles فقط؛ لا يوجد مسار جاهز داخل المشروع يمكن تسميته validation hook.

## الحكم النهائي

**مطابقة الواجهة الأساسية جيدة ومتماسكة مع القرار المؤكد**: الألوان والهوية وHermes في طبقة الواجهة محفوظة، لا DeepSeek blue، auth مركزي 336 بلا story، sidebar يسار 260، reasoning SDK-only، Search/OAuth غير مهيئين بوضوح، والميزات الأساسية ظاهرة. لا أرى سببًا لإضافة OAuth أو تبديل النموذج أو تصنيع نص تفكير.

قبل إعلان اكتمال المطابقة، عالج/تحقق من نقاط P1 الثلاث، خصوصًا empty-stage والصلاحيات؛ وبعدها وحّد CSS overrides. لا يمكن إعطاء claim حرفي للشاشات الخاصة أو للإدارة لأن المرجع الخاص غير متاح، ولا يمكن تأكيد Hermes الخادم أو صحة computed layout دون فتح job/backend أو إجراء browser منفصل.

**هذا التقرير نفسه هو الأثر الوحيد المكتوب:** `/home/ubuntu/deepseek-review.md`.
