# عقد تخزين RSVX7 على MySQL المُدار

## النطاق

هذه الوحدة هي **تنفيذ MySQL فقط** لوحدة التخزين الجديدة. لا تقرأ `.env`، ولا تتصل بقاعدة Manus المُدارة أثناء البناء أو الاختبار، ولا تنقل بيانات Mongo القديمة. ملفاتها المملوكة هي:

- `backend/mysql_repository.py`: `MySQLDatabase` وواجهات collections والمعاملات.
- `backend/sql_document_ops.py`: دلالات filters وupdates وprojection وترجمة SQL.
- `backend/sql_schema.py`: whitelist الجداول والأعمدة والمهاجرات والفهارس.
- `backend/migrations/001_initial_schema.sql`: migration إضافية قابلة للتكرار.
- `tests/test_mysql_repository.py`: pure semantics وSQL compilation واختبارات MySQL اختيارية.

لا يحدث اتصال أو initialization عند `import`. مسار التشغيل المقصود هو:

```python
from mysql_repository import MySQLDatabase

db = MySQLDatabase(url, allow_local_plaintext=True)  # الخيار محلي للاختبار فقط
await db.initialize()       # migration منفصل قبل تشغيل الخادم
await db.verify_schema()    # الإصدار والجداول والأقفال، لا DDL أثناء readiness
await db.ping()
await db.close()
```

## الجداول الصريحة

لكل جدول `doc_id` يمثل `_id`، و`data JSON` تحفظ كامل المستند للتوسع، مع أعمدة SQL حقيقية للهوية والمالك والترتيب والتواريخ والرصيد. لا يُسمح بإدخال اسم جدول أو عمود من المستخدم؛ أسماء الجداول والأعمدة تأتي من whitelist في `sql_schema.py`، ومسارات JSON تُمرر كـ bind parameters بعد تحقق syntax.

| Collection API | جدول SQL | الغرض والحقول المفهرسة المهمة |
|---|---|---|
| `users` | `rsvx7_users` | username وrole/status وIP التسجيل/الأخير ورصيد `token_balance` وتواريخ الحساب؛ unique username؛ unique Telegram verified جزئي عبر generated key |
| `usage` | `rsvx7_usage` | `user_id` و`date_key`؛ unique `(user_id,date_key)` |
| `settings` | `rsvx7_settings` | إعدادات `ai` و`app` و`global`؛ المفتاح هو `_id` |
| `token_usage_history` | `rsvx7_token_usage_history` | user/conversation/created_at وidempotency؛ unique `(user_id,idempotency_key)` مع السماح بتعدد NULL |
| `coupons` | `rsvx7_coupons` | code/enabled/starts_at/expires_at/created_at؛ فهرس expires_at |
| `redemptions` | `rsvx7_redemptions` | user/code/tokens/dedup/redeemed_at؛ unique dedup وفهارس user+code والتاريخ |
| `referral_codes` | `rsvx7_referral_codes` | code `_id` و`user_id`؛ unique user_id |
| `tg_required_groups` | `rsvx7_tg_required_groups` | ترتيب المجموعة في `item_order` (يعكس حقل Mongo `order`) |
| `tg_seen` | `rsvx7_tg_seen` | Telegram id وبيانات الرؤية |
| `projects` | `rsvx7_projects` | user وarchived/favorite وcreated/updated/last_opened؛ فهارس الملكية والترتيب |
| `conversations` | `rsvx7_conversations` | user/project/pinned وcreated/updated؛ فهارس project وowner |
| `messages` | `rsvx7_messages` | user/conversation/project و`order_index` وcreated؛ فهرس conversation+order |
| `notes` | `rsvx7_notes` | user/project/created |
| `files` | `rsvx7_files` | user/project/deleted/upload_status/created؛ فهارس القوائم غير المحذوفة |
| `ai_request_leases` | `rsvx7_ai_request_leases` | `_id` للمستخدم و`expires_at DATETIME(6)` بدقة UTC |
| `status_checks` | `rsvx7_status_checks` | client_name داخل JSON وtimestamp عمودًا حقيقيًا |
| `banned_ips` | `rsvx7_banned_ips` | `_id` للـ IP وbanned_at |
| قفل داخلي | `rsvx7_collection_locks` | صف ثابت لكل collection؛ `SELECT ... FOR UPDATE`، وليس collection API |

يوجد كذلك `rsvx7_schema_version` لتسجيل الإصدار بعد نجاح migration. لا تُعتبر الجداول غير الفارغة دليلاً على اكتمال التهيئة؛ الإصدار هو المصدر.

## الفهارس والقيود

- **لا يوجد** `DROP`, `TRUNCATE`, حذف فهرس أو إعادة بناء هدمي. كل migration `CREATE TABLE IF NOT EXISTS`، وتُسجّل بعد نجاحها فقط.
- Telegram verified partial unique مطبق بعمود generated: المستخدم غير الموثق ينتج `NULL`، ولذلك يمكن تكراره؛ الرقم الموثق الحقيقي لا يتكرر.
- `usage` يضمن atomic daily uniqueness على `(user_id,date_key)`.
- سجل الشحن يضمن idempotency على `(user_id,idempotency_key)` مع NULL متعدد وفق MySQL.
- redemption يضمن unique `dedup_key`، بما في ذلك retry key للقسائم.
- `create_index` لا ينشئ DDL عشوائياً: يطابق أسماء الفهارس المعلنة فقط ويصبح no-op عند التكرار. `drop_index` مرفوض صراحة.

## المعاملات والأقفال

```python
async with db.transaction(("token_usage_history", "users")):
    # كل CRUD داخل هذا السياق يرى نفس اتصال asyncmy
    ...
```

`initialize()` يحضّر صفوف الأقفال مسبقًا مرةً قبل runtime. `transaction(collections=...)` يرتب أسماء collections معجمياً ثم يقفل صفوفها الموجودة بـ`SELECT ... FOR UPDATE`، ويرفض غيابها. لا INSERT IGNORE على مسار القفل لأنه يسبب deadlock عند ترقية قفل shared تحت التزامن. هذا يمنع دورات الأقفال ويحمي compound unique وupsert متعدد الجداول دون `GET_LOCK`، وهو مناسب لـMySQL/MariaDB/TiDB. CRUD الكتابي المنفرد يملك transaction وقفل collection الخاص به. القراءة داخل transaction تعيد استخدام `ContextVar` نفسه، وكذلك أي nested CRUD.

الـ update لا يقرأ ثم يكتب خارج القفل: يجري `SELECT ... FOR UPDATE`، يطابق filter، يطبق update، ثم يحفظ المستند داخل نفس المعاملة. إذا كان `upsert=True` ووجد `_id` نفسه لكن filter لا يطابق، تُرفع `pymongo.errors.DuplicateKeyError` بدلاً من استبدال مستند آخر.

## عقد filters المدعوم

المطابقة pure في `sql_document_ops.py` ثم يُستخدم SQL WHERE قبل التحقق النهائي من الدلالة. المدعوم فعلياً:

- equality مع `null` وmissing؛ equality scalar داخل array وفق دلالة Mongo.
- `$ne`, `$nin` مع اعتبار missing مطابقاً لهما؛ `$in`.
- `$gt`, `$gte`, `$lt`, `$lte`.
- `$or`, `$and`.
- `$exists`, `$type` (`string`, `number`, `bool`, `array`, `object`, `null`, `date`).
- `$regex` و`$options` للخيار `i` فقط في SQL، أو pattern بلا options؛ SQL يستخدم REGEXP case-sensitive أو LOWER. خيارات m/s/x لا تُنفذ بشكل تقريبي بل تُرفض.

أي operator آخر، مثل `$nor`, `$not`, `$elemMatch`, `$where`، مرفوض بـ`UnsupportedMongoOperator`؛ لا يوجد approximate shim. استعلامات البحث الحالية، filters المالك/الترتيب، شرط lease، شروط الرصيد، وشروط ownership كلها ضمن العقد.

## عقد updates المدعوم

- `$inc` للأرصدة والعدادات.
- `$set`, `$setOnInsert`.
- `$unset`، مع حماية `_id` من الحذف.
- `$addToSet` و`$addToSet: {$each: [...]}`.
- `$pull` للقيم وعناصر arrays.
- `$max`.

Replacement updates و`$push` وغيرها مرفوضة بوضوح لأنها ليست من operations التطبيق الحالية. `$inc` وCAS filter والرصيد لا تُنفذ كقراءة/كتابة منفصلتين.

## projection وsort وaggregate

- projection inclusion/exclusion و`_id: 0` مدعومة؛ المزج بين inclusion وexclusion مرفوض عدا `_id`.
- sort يقبل حقلًا أو قائمة `(field,direction)`، والاتجاه فقط `1/-1`. الحقول المملوكة تستخدم typed SQL columns عند وجودها، والحقول المرنة تستخدم JSON path bind parameter.
- aggregate الموجود في التطبيق فقط: `$match` قبل group يترجم WHERE (مثل تاريخ الاستعمال)، ثم `$group` واحد مع `_id` null أو field reference وaccumulator `$sum` بقيمة `1` أو field، ثم `$match` للنتائج أو `$sort` و`$limit`. stages أخرى أو أكثر من group مرفوضة. هذا يغطي إحصاءات الإدارة والقسائم ومجموع tokens.

## DSN وTLS

`MySQLDatabase(url, ...)` يقبل `mysql://`, `mariadb://` و`mysql+asyncmy://`. لا يُطبع DSN ولا كلمة المرور ولا `DATABASE_URL`. يدعم query `mysqlssl` JSON الشائع في Manus، بما فيه CA inline أو مسار CA. للـ managed endpoint ينشئ `SSLContext` يتحقق من CA وhostname؛ query values مثل `ssl=false`, `sslmode=disable`, `verify=false`, `insecure=true` مرفوضة.

plaintext لا يُقبل إلا على `localhost`, `127.0.0.1` أو `::1` مع `allow_local_plaintext=True` اختياراً صريحاً للاختبار. نفس الخيار لا يفتح plaintext لأي hostname خارجي.

## migration وreadiness

`initialize()`/`migrate()` ينشئ المخطط ويرقي الإصدارات إضافيًا، وبعد نجاح DDL يسجل الإصدار ويحضر lock rows. MySQL/TiDB DDL قد يعمل implicit commit؛ الترحيل قابل للتكرار وليس وعدًا بمعاملة DDL واحدة. اتصالات domain transactions تستخدم READ COMMITTED مع row locks صريحة. `verify_schema()` ينفذ SELECT لإصدار `rsvx7_schema_version` والجداول المطلوبة وlock rows، ولا ينشئ DDL؛ لذلك يجب أن يسبق تشغيل الخادم script migration منفصل. لا توجد data migration من Mongo في هذه الوحدة.

## الجرد الفعلي لعقود Mongo القديمة

الجداول أعلاه تغطي collections التي ظهرت فعلياً في `backend/*.py`: users, usage, settings, token_usage_history, coupons, redemptions, referral_codes, tg_required_groups, tg_seen, projects, conversations, messages, notes, files, ai_request_leases, status_checks, banned_ips. عمليات find/find_one ذات owner/id/date/order، projections السرية وإخفاء message/extracted_text، updates atomic للرصيد/leases/referrals/coupons، وaggregate إحصاءات coupons هي سبب وجود الأعمدة والفهارس والoperators المحددة. هذه الوحدة لا تعدل وحدات auth/server/tokens/coupons/workspace/persistence.py ولا تغيّر responses أو تخزن مفاتيح AI/Telegram في أعمدة خاصة؛ تبقى المرونة داخل JSON.
