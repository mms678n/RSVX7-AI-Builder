# عقد أسماء مفتاح الجلسة في منصة Manus

المصدر المقروء: `/home/ubuntu/skills/webdev/references/service-api.md`، فقرة **Platform-owned compatibility names**، الأسطر21–26، بتاريخ4 أكتوبر2026.

> Published containers also receive JWT_SECRET as a compatibility alias of the platform's MANUS_JWT_SECRET; the managed development environment supplies the canonical name, not this alias. Neither name is an application-owned setting, and the platform does not promise the length or format an application's independently chosen signing library might require. For a separate application session/signing secret, use an application-specific name through protected secret configuration, rather than shadowing either platform name.

المصدر الخاص بتدفق الإدخال: `/home/ubuntu/skills/webdev/references/secrets.md`. قيمproduction مستقلة عنdev؛ تحفظ عبر بطاقة محمية، ولا تُطبع أو تُنسخ إلى المصدر. لا يؤدي حفظها إلى إعادة النشر.

تطبيق العقد: مفتاح جلسة RSVX7 هو `RSVX7_JWT_SECRET`، وليس اسم المنصة. فحصه يبقى صارمًا في وضعproduction. لا يحتوي هذا الملف أية قيمة مفتاح أو بيانات اتصال.
