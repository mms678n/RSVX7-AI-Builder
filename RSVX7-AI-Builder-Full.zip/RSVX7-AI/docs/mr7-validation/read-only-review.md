# مراجعة تكامل MR7 لواجهة RSVX7 — قراءة فقط

**النطاق:** مراجعة مصدرية للمشروع `/home/ubuntu/rsvx7ai` مقابل صور وقياسات MR7 الحقيقية في `/home/ubuntu/rsvx7ai/docs/mr7-reference/`. لم أعدّل أي كود، ولم أقرأ أو أنسخ أي credential/private/DB/.env، ولم أستخدم Browser أو MCP أو Git أو diagnostics/build.

> **قاعدة branding:** التقرير يحافظ على اسم وشعار **RSVX7**؛ لا يقترح استبدالهما بـ MR7، ولا يعتبر اختلاف الشعار عيب pixel-match.

## الخلاصة التنفيذية

- **P1 مؤكد:** بنية composer في Chat ليست البنية المقاسة في المرجع: المصدر يبني textarea ثم toolbar كسطر ثانٍ، بينما المرجع composer واحد بعرض 640px وارتفاع 58px وكل الأزرار والـtextarea في صف واحد.
- **P1 مؤكد:** ترتيب روابط auth الأساسية لا يطابق hierarchy المرجع: `Forgot password` و`Sign up` موضوعان معًا في footer أسفل النموذج، بينما القياس يضع Forgot بجانب Password وSign up أسفل زر الدخول. هذا ليس عطل تسجيل دخول؛ هو mismatch واجهة واضح.
- **P2 مؤكد:** صفحة الـpublic landing لا تعرض ThemeSwitcher، رغم أن مرجع home يثبت زر `Toggle theme` في الـnavbar. هذا يخص تكامل parent-owned route/theme وليس إضافة fake MR7 feature.
- **P2 مؤكد:** navbar landing يستخدم 14px للروابط و13px لزر التسجيل، مقابل 16px للروابط و14px للزر في قياس home؛ كما أن عنوان chat الإنجليزي هو `What can I help with today?` بدل نص المرجع المقاس `What can I hack today?`.
- **P2 مؤكد:** `--chat-brand-soft` يحل إلى `--primary-foreground` (أبيض) عند وجود tokens الحالية، لا إلى الأحمر؛ حالات streaming/pin التي تستخدمه لا ترث اللون الأحمر المقاس.
- **P2 مؤكد:** عنوان Welcome في Chat لون solid primary بلا gradient، بينما القياس يثبت gradient أحمر مع transparent text fill.

لا يوجد في المصدر المقروء دليل مؤكد على خلل في `#home` routing، auth gating، namespace، save/retry contract، أو AR/LTR direction؛ التفاصيل أدناه تفصل المثبت عن غير المثبت.

## P1 — يجب حسمها قبل قبول مطابقة واجهة Chat/Auth

### P1-CHAT-01 — composer ليس single-row ولا 58px measured geometry

**الدليل المرجعي:**

- `docs/mr7-reference/chat-measured.json:500-511`: parent عند `[448,632,640,58]`، `padding: 8px`، `radius: 16px`.
- `chat-measured.json:313-329`: textarea عند `y=641`, `h=40`.
- `chat-measured.json:294-405`: أزرار composer كلها عند `y=641`, `h=40` داخل نفس الصف.

**الدليل في المصدر:**

- `frontend/src/components/chat/ChatInput.jsx:91-103`: `TextareaAutosize` يأتي أولًا، ثم `div.chat-input-toolbar` منفصلًا بعده.
- `frontend/src/components/chat/deepseek-composer.css:2`: `padding: 0 16px` و`border-radius: 8px`.
- `deepseek-composer.css:5`: toolbar له `min-height: 48px`.
- `frontend/src/components/chat/chat-ui.css:114-118`: shell بعرض 640px، لكن panel radius 8px والtoolbar منفصل.

إذًا المصدر لا يمكن أن يطابق parent المرجعي ذي الارتفاع 58px/صف واحد: حتى قبل حساب margins الداخلية، هناك textarea بارتفاع 40px وtoolbar بحد أدنى 48px كسطر آخر. كما أن radius/padding مختلفان. هذا يغيّر موضع Welcome والاقتراحات، لا مجرد لون.

**التصحيح المقترح للمالك:** إعادة ترتيب/تنسيق composer ليحافظ على كل القدرات الحقيقية الموجودة (`attach`, send/stop, file processing, save retry، وdisabled DeepThink/Web Search) في صف واحد بمقاسات القياس. لا تتم إضافة history/world/onion أو أي أداة MR7 غير مهيأة كـfake controls؛ يمكن تمثيل وظيفة RSVX7 الفعلية بنفس الgeometry فقط.

### P1-AUTH-01 — hierarchy روابط auth لا تطابق المرجع

**الدليل المرجعي:**

- `docs/mr7-reference/login-measured.json:111-142`: Password label و`Forgot password?` في نفس منطقة y≈587.
- `login-measured.json:179-210`: زر `Sign in` عند y=679 ثم `Sign up` عند y=759 أسفل الزر.

**الدليل في المصدر:**

- `frontend/src/pages/Login.jsx:71-75`: `نسيت كلمة المرور؟` و`إنشاء حساب جديد` كلاهما داخل `footer` واحد.
- `Login.jsx:80-112`: form لا يحتوي Forgot بجوار Password، ويحتوي بدلًا منه checkbox `تذكّر هذا الجهاز` ثم submit.
- `frontend/src/components/auth-ui.css:343-365`: `auth-ui-link-row` يعرض الرابطين معًا `justify-content: space-between`.
- `auth-ui.css:386-393`: footer واحد أسفل البطاقة.

هذا لا يعني أن `onRecover`, `onSwitch`, `login(username,password,remember)` مكسور؛ العقود الوظيفية محفوظة. العيب هو ترتيب/موضع عناصر السطح المرئي مقارنة بالمرجع. الإصلاح يجب أن يبقي username وغياب Google OAuth/Terms/Privacy fake كما طلبت المواصفة، مع إعادة توزيع روابط الوظائف الحقيقية على hierarchy المرجع.

## P2 — فروق مؤكدة، غير حاجبة للوظائف

### P2-PUBLIC-01 — ThemeSwitcher غائب من public landing

- القياس `docs/mr7-reference/measured-styles.json:349-365` يثبت زر `Toggle theme` في home navbar.
- `frontend/src/pages/Landing.jsx:120-123` يعرض `LanguageSwitcher` وSign-in/Register فقط؛ لا يوجد `ThemeSwitcher` في landing navbar أو mobile menu.
- `frontend/src/components/design/ThemeSwitcher.jsx:38-45` موجود ويعمل عالميًا، و`index.css` يعرّف light/dark channels؛ الفجوة هي عدم تركيب الزر في public surface.

المالك هنا parent/AppRouteLanding/ThemeSwitcher حسب حدود المهمة؛ لا تُحل بإضافة رابط أو feature MR7 وهمية.

### P2-PUBLIC-02 — typography navbar landing أدق من المرجع؟ لا: أصغر من المقاس المقاس

- `measured-styles.json:45-98` يقيس روابط Features/Pricing/Tools بحجم 16px.
- `measured-styles.json:406-440` يقيس Get Started بحجم 14px.
- `frontend/src/pages/mr7-landing.css:68-80` يحدد nav links على 14px.
- `mr7-landing.css:160-161` يفرض زر التسجيل على 13px.

الـhero عند viewport 1280 قريب من المرجع (`mr7-landing.css:456-458` يثبت 72/90)، لذلك الملاحظة محصورة في navbar typography لا في اسم RSVX7 أو محتوى المنتج.

### P2-CHAT-01 — English Welcome copy لا يطابق العنوان المقاس

- المرجع المقاس `docs/mr7-reference/chat-measured.json:218-233` يقول `What can I hack today?`، 36px/700، بلون gradient.
- `frontend/src/i18n/catalogs/chat.js:104` يترجم `كيف أساعدك اليوم؟` إلى `What can I help with today?`.
- `frontend/src/components/chat/WelcomeState.jsx:13` يستخدم المفتاح نفسه.

هذا فرق copy/branding للمرجع، وليس دعوة لاستخدام نصوص MR7 الأخرى أو ادعاء أدوات هجومية؛ يمكن الإبقاء على RSVX7 والوظائف الفعلية مع تقرير قرار واضح للـproduct copy العربي/الإنجليزي.

### P2-CHAT-02 — Welcome title solid لا gradient المرجع

- `chat-measured.json:224-227` يثبت `background-image: linear-gradient(...)` و`color: rgba(0,0,0,0)` للـH1.
- `frontend/src/components/chat/chat-ui.css:39` يطبق فقط `color: var(--chat-brand)` ولا يطبق background-clip/gradient.

الفرق مرئي حتى مع تطابق اللون الأساسي، لكنه لا يكسر التفاعل.

### P2-CHAT-03 — `chat-brand-soft` يحل إلى أبيض بدل الأحمر

- `frontend/src/components/chat/chat-ui.css:7`: `--chat-brand-soft: var(--primary-foreground, var(--ds-brand-soft))`.
- `frontend/src/index.css:19` يعرّف `--primary-foreground: oklch(98% 0 0)`، لذلك fallback الأحمر لا يصل إليه المتصفح.
- المستهلكون الظاهرون: `chat-ui.css:22` لحالة streaming و`:91` للـpin.

إذا كان المقصود من brand-soft هو الأحمر المقاس (`measured-styles.json:15`)، فهذه إحالة token مؤكدة يجب توحيدها مع token contract المملوك للوالد. لا أغيّر `index.css` في هذا review.

## ما تم التحقق منه ولم يظهر كعيب مؤكد

### الألوان والخطوط والثيم

- `frontend/src/index.css:6-29` يعرّف ألوان oklch الداكنة المقاسة، aliases legacy، وsystem font stack المطابق للمرجع؛ لا يوجد Google Font/Manrope/Inter في الملفات المقروءة.
- `index.css:33-44` يملك channels light، و`ThemeSwitcher.jsx:13-19` يحدّث `data-theme`, class `dark`, وmeta theme-color.
- `mr7-landing.css:1-8`, `auth-ui.css:1-12`, و`chat-ui.css:1-10` تستخدم vars/fallbacks لا palette بنفسجية عامة. الاستثناء المقصود الظاهر في tool icons هو green/purple/pink عند `chat-ui.css:74-76`، وهو متسق مع صورة chat المرجعية ومجموعات الأدوات؛ لم أعدّه defect مستقلًا.

### AR/EN وdirection

- `frontend/src/i18n/index.jsx:8-20` يحدد `dir` من اللغة، يضبط `html[lang]` و`--ui-direction`.
- `frontend/src/i18n/language.css:7-9` يربط EN بالـLTR وplaceholder المناسب.
- `chat-ui.css:15` و`:51` يستهلكان `--ui-direction`، لذلك لا يوجد دليل source-level على انعكاس ثابت يمنع EN.
- الاختبارات الموجودة (`components/chat/chat-language.test.jsx:34-51`, `pages/AuthMr7.test.jsx:54-62`, `pages/Landing.test.jsx:74-87`) تثبت تغطية ترجمة واتجاه أساسية.

### Public links وauth gating

- `frontend/src/App.js:18-24` يعرّف public sections والـroutes، و`App.js:51-64` يميز guest/auth ثم يمرر Chat/Dashboard عبر `TelegramGate` لغير admin.
- `App.js:50-58` يربط callbacks من landing إلى `#login/#register/#chat` بدل روابط MR7 خارجية.
- `frontend/src/components/design/Primitives.jsx:44-64` يستخدم `href="#home"` من auth، وهو متسق مع `App.js:20-23`.
- `Landing.jsx:44-73`, `98-116`, `186-199`, `222-260`, `292-295` تستخدم anchors محلية صحيحة (`#features`, `#projects`, `#code`, `#faq`) وcallbacks للوظائف الفعلية؛ لا يوجد رابط `https://` في CTA وفق `Landing.test.jsx:40-54`.
- `Login.jsx:82-111` يستخدم username فعلًا، و`AuthMr7.test.jsx:47-52` يثبت عدم إدخال Google/Terms/Privacy fake؛ هذا مقصود ولا ينبغي اعتباره فشلًا أمام صورة MR7.

### الحفاظ على الميزات العاملة

المصدر الحالي يحافظ على عقود المشاريع/الملفات/البحث داخل المشاريع/مساعد Hermes في `Sidebar.jsx:101-119`, `ChatInput.jsx:38-69`, و`Landing.jsx:181-199,222-260`. كما أن `ChatInput.jsx:94-98` يعطّل DeepThink/Web Search عندما لا يدعمهما الخادم بدل إرسال طلب وهمي. عمليات rename/pin/export/delete/import موجودة في `Sidebar.jsx:23-53,79-89`.

## غير محسوم — لا أدّعيه بلا دليل تشغيل

- لم أُصدر حكمًا runtime على `#home` layout في كل viewport، أو على auth save/poll/private-route timing؛ المصدر يثبت route/gate wiring أعلاه فقط.
- لم أستنتج namespace/helper DOM failure: `useI18n("chat")` وcatalogs و`data-testid` موجودة، والاختبارات المقروءة تغطي أجزاء منها.
- لم أراجع منطق Streaming/TTFT أو CodeFence/partial-abort؛ تلك خارج ملكية هذا review وحسبت عملًا منفصلًا كما طلبت.
- لم أقرأ private/DB/user credentials أو أسرارًا، ولم أستخدم الصور إلا بصريًا/القياسات العامة المطلوبة.

## ملفات parent التي يلزمها وصول/تنسيق

- `/home/ubuntu/rsvx7ai/frontend/src/App.js` — route/public/auth gate wiring.
- `/home/ubuntu/rsvx7ai/frontend/src/index.css` — shared tokens/system font/light-dark channels.
- `/home/ubuntu/rsvx7ai/frontend/tailwind.config.js` — Tailwind token mapping.
- `/home/ubuntu/rsvx7ai/frontend/src/components/design/ThemeSwitcher.jsx` — global theme control؛ زر public landing مفقود من تركيب الصفحة.
- `/home/ubuntu/rsvx7ai/frontend/src/pages/Landing.jsx` — AppRouteLanding الفعلي في هذا checkout؛ لم أعثر على ملف literal باسم `AppRouteLanding`.

**النتيجة:** عالج أولًا single-row composer وauth link hierarchy (P1). ثم اربط ThemeSwitcher العام بالـpublic landing، ووحّد navbar typography وchat title/token mapping (P2). كل ذلك مع إبقاء اسم RSVX7، username auth، Hermes، gating، والمزايا الحالية كما هي.
