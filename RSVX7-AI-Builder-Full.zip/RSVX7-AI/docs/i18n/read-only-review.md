# مراجعة إضافة English — `/home/ubuntu/rsvx7ai`

**النطاق:** مراجعة للقراءة فقط لـ `docs/i18n/IMPLEMENTATION.md`، runtime/provider والكتالوجات، `App`، المكونات والـcontexts والعملاء المتأثرين. لم أعدّل ملفات المشروع، ولم أشغّل build أو server أو `scripts/check_i18n.mjs` (السكريبت يكتب `docs/i18n/source-audit.json`).

## النتيجة المختصرة

- **P1:** لا توجد علة P1 مثبتة في المسارات التي راجعتها.
- **P2:** توجد خمس نقاط ربط محددة أدناه. لا توجد أدلة على أن التبديل يفعّل model/backend secret، يرسل اللغة إلى DeepSeek/Hermes، أو يترجم محتوى الرسائل/المشاريع/الملاحظات في مسار العرض الطبيعي.

## P2 — عيوب مثبتة أو حدود ربط حقيقية

### P2-1 — تسرب نص إنجليزي إلى العربية الافتراضية في رسالتين معروفتين

- `frontend/src/i18n/catalogs/account.js:130`
- `frontend/src/components/chat/SettingsDialog.jsx:88`
- `frontend/src/i18n/catalogs/auth.js:21`
- `frontend/src/pages/Register.jsx:102,166,183`

الكتالوج يسجل المفتاح الإنجليزي `"Chats deleted from this project."` وقيمته الإنجليزية نفسها، بينما تستدعيه `SettingsDialog` عبر `t(...)`. في العربية، `runtime.translate` لا يجد مصدرًا عربيًا لهذا المفتاح؛ ومسار reverse catalog يعيد القيمة الإنجليزية نفسها، لذلك يظهر toast إنجليزي رغم أن العربية هي الافتراضية.

الحالة نفسها قابلة لإعادة الإنتاج من المصدر في تحقق تسجيل الحساب: `Register.jsx:102` ينشئ خطأ `Username may only contain...`، ثم `Register.jsx:166/183` يعرضه عبر `t(error)`، والكتالوج في `auth.js:21` لا يملك ترجمة عربية. النتيجة: رسالة تحقق إنجليزية في واجهة عربية.

**الإصلاح المقترح:** اجعل مصدر `t()` عربيًا مع قيمة English، أو احتفظ برسائل/أخطاء English غير المعروفة خارج `t()`؛ لا تستخدم English كـsource key إذا كانت العربية الافتراضية مطلوبة.

### P2-2 — تحميل كتالوج workspace يعتمد عرضيًا على ترتيب imports

- `frontend/src/components/workspace/GlobalSearchDialog.jsx:11-12,46-48`
- `frontend/src/components/workspace/ProjectSettingsDialog.jsx:14-24,35-38`
- المقابل الصحيح موجود في `frontend/src/components/workspace/ProjectSwitcher.jsx:18-19`

كلا `GlobalSearchDialog` و`ProjectSettingsDialog` يستعمل `useI18n("workspace")` لكن لا يستورد `@/i18n/catalogs/workspace`. مسار التطبيق الحالي يحمّل `Sidebar`، و`Sidebar` يستورد `ProjectSwitcher`، لذلك يسجل الكتالوج بالصدفة قبل الاستخدام. هذا يخفي العيب في المسار الحالي، لكنه يجعل المكوّنين غير آمنين عند lazy/direct import أو اختبار/تجميع مختلف: قد يعمل hook في English مع fallback عربي بدل catalog workspace.

**الإصلاح المقترح:** أضف import side-effect للكتالوج في كل وحدة تستعمل namespace، بدل الاعتماد على sibling import غير مباشر. لم أرفعها إلى P1 لأن مسار `Sidebar` الحالي يسجل الكتالوج فعليًا.

### P2-3 — جذر مساحة الدردشة يثبت `dir="rtl"` رغم تبدل اللغة

- `frontend/src/components/design/ChatWorkspace.jsx:8-12`

العنصر `data-testid="app-root"` يظل `dir="rtl"` دائمًا. `ChatLayout` يضبط اتجاه العناصر الداخلية عبر `PageShell`/`chat-main`، لذلك لم أثبت انكسارًا بصريًا عامًا في كل الشاشة؛ لكن الجذر نفسه لا يتبع عقد `dir`، وأي descendant جديد لا يحدد `dir` صراحة سيرث RTL في English. هذا mismatch حقيقي في DOM ويستحق تصحيحه إلى اتجاه hook/لغة واحد.

**ملاحظة portal:** `frontend/src/components/ui/dialog.jsx:14-17` يأخذ `dir` من `useI18n()` ويضعه مباشرة على Radix `Content` داخل portal؛ لذلك لم أجد عيب portal مستقلًا مثبتًا. المشكلة المثبتة هنا هي root hard-code، لا ادعاء أن كل الحوارات الحالية معطوبة.

### P2-4 — نص modal الرصيد لا يعاد ترجمته إذا تغيّرت اللغة وهو مفتوح

- `frontend/src/context/SubscriptionContext.jsx:25-33`
- `frontend/src/components/SubscriptionRequiredDialog.jsx:8-20`

`openRenewalModal` يحسب `serviceT(...)` وقت الفتح ويخزن `message` و`cta` كنص نهائي (`:29-32`). المكوّن يعرض props كما هي (`:14,19`) ولا يمررها إلى `t`. لذلك إذا حدث تبديل لغة أثناء بقاء dialog مفتوحًا (مثل storage event من تبويب آخر)، يعاد render العنوان العام لكن يبقى نص الرصيد وCTA بلغة الفتح القديمة. هذا لا يغير data أو request؛ هو خلل اتساق locale في modal.

**الإصلاح المقترح:** خزّن source key/variables أو خزّن raw error code ثم نفّذ الترجمة داخل `SubscriptionRequiredDialog` عند كل render، مع إبقاء الرسائل الخارجية غير المعروفة raw.

### P2-5 — placeholder عربي متبقٍ في صفحة الإدارة

- `frontend/src/pages/Admin.jsx:194`
- يؤكده `docs/i18n/source-audit.json` تحت `raw_ui_text`

حقل `settings-tg-chat` يضع placeholder الخام `-1001234567890 أو 123456789`. في English تبقى كلمة `أو` عربية. هذا نص واجهة ثابت وليس user content أو identifier؛ يجب أن يكون key في catalog أو صياغة محايدة لا تعتمد على العربية.

## ما تحققت منه ولم أعتبره عيبًا

- **Hooks/Provider:** `frontend/src/i18n/index.jsx:7-21` يستخدم `useSyncExternalStore`؛ `LanguageProvider` في `App.js:59-62` يلف التطبيق ويحدّث `html.lang/dir`. الكتالوجات الحالية تُسجّل عبر imports side-effect، وراجعت أن معظم وحدات namespaces تستورد كتالوجها مباشرة.
- **عدم bootstrap reset عند اللغة:** `WorkspaceContext` boot effect في `:140-205` لا يعتمد language، و`ChatContext` scope/load effect في `:308-358` لا يعتمد language. تغيير اللغة لا يمسح chats أو project scope ولا يلغي stream بسبب locale. callbacks الأساسية لا تستعمل `useI18n` closure متغيرًا.
- **التخزين وعدم remount الحقول:** `runtime.js:1,6-20` يحفظ `rsvx7_language`، واختبارات اللغة أكدت التبديل الفوري والحفظ. لا يوجد `key` مشتق من اللغة في `ChatInput` أو حقول Settings، والاختبارات أكدت بقاء قيمة input ومحتوى user-owned.
- **محتوى المستخدم:** `Message.jsx:102-115` يعرض `message.content`/Markdown كما هو، وحقول المشروع والملاحظات والملفات تستخدم `dir="auto"` وتعرض القيم الخام. `chat-language.test.jsx` و`workspace-language.test.jsx` أثبتا بقاء رسالة المستخدم واسم المشروع دون ترجمة.
- **DeepSeek/Hermes/model/backend secret:** لم أجد في تغييرات i18n إضافة `lang` إلى payload أو كشف/تفعيل secret. `AdminAISettings.jsx:57-60,87-90` يحذف `key/api_key` من state، ومعرّف النموذج و`base_url` يعرضان LTR دون ترجمة. لم أتعامل مع architecture الحالية لـ model activation كعيب i18n لأن الطلب صراحة لا يطلب تفعيل model أو backend secret.
- **الاختبار المنفذ:** شغّلت فقط اختبارات pure UI/لغة السبعة المطلوبة، دون build أو port: **7 suites، 16 tests، كلها PASS** (`language`, `chat-language`, `workspace-language`, `services-language`, `Auth-language`, `account-language`, `Admin-language`). نجاحها لا يغطي نقاط P2 أعلاه (خصوصًا Arabic-source leaks وmodal أثناء تبديل اللغة)، لذلك لا أعدّه قبولًا كاملًا.
