import React from "react";
import { ArrowRight, LoaderCircle, AlertCircle, CheckCircle2, Info, Sparkles } from "lucide-react";
import Logo from "@/components/chat/Logo";
import { useI18n, LanguageSwitcher } from "@/i18n";
export function ActionButton({ children, tone = "primary", loading = false, className = "", disabled, ...props }) {
  return <button type="button" {...props} disabled={disabled || loading} className={`ds-button ds-button-${tone} ${className}`}>
    {loading && <LoaderCircle size={16} className="ds-spin" aria-hidden="true" />}{children}
  </button>;
}
export function StatusNote({ children, tone = "info", onRetry, retryLabel = "إعادة المحاولة", className = "" }) {
  const { t } = useI18n();
  const Icon = tone === "error" ? AlertCircle : tone === "success" ? CheckCircle2 : Info;
  return <div className={`ds-note ds-note-${tone} ${className}`} role={tone === "error" ? "alert" : "status"}>
    <Icon size={17} aria-hidden="true" /><div className="min-w-0 flex-1">{children}</div>
    {onRetry && <ActionButton tone="ghost" onClick={onRetry}>{t(retryLabel)}</ActionButton>}
  </div>;
}
export function Panel({ children, className = "", ...props }) { return <section className={`ds-panel ${className}`} {...props}>{children}</section>; }
export function PageHeader({ title, eyebrow, description, actions, onBack }) {
  const { t, dir } = useI18n();
  return <header className="ds-page-header"><div className="ds-page-heading">
    {onBack && <ActionButton tone="ghost" onClick={onBack} aria-label={t("العودة إلى المحادثة")} className="ds-back"><ArrowRight size={18} className={dir === "ltr" ? "rotate-180" : ""} /></ActionButton>}
    <div>{eyebrow && <p className="ds-eyebrow">{eyebrow}</p>}<h1>{title}</h1>{description && <p className="ds-description">{description}</p>}</div>
  </div><div className="ds-page-actions">{actions}</div></header>;
}
export function PageShell({ children, className = "", ...props }) {
  const { dir } = useI18n();
  return <main className={`ds-page ${className}`} dir={dir} {...props}>{children}</main>;
}
export function EmptyState({ title = "لا توجد بيانات بعد", description, action, icon: Icon = Sparkles }) {
  const { t } = useI18n();
  return <div className="ds-empty"><div className="ds-empty-icon"><Icon size={25} aria-hidden="true" /></div><h3>{t(title)}</h3>{description && <p>{description}</p>}{action}</div>;
}
export function LoadingState({ label = "جارٍ التحميل…", compact = false }) {
  const { t } = useI18n();
  return <div className={`ds-loading ${compact ? "ds-loading-compact" : ""}`} role="status"><LoaderCircle size={21} className="ds-spin" aria-hidden="true" /><span>{t(label)}</span></div>;
}
export function MetricCard({ label, value, detail, icon: Icon }) {
  return <Panel className="ds-metric"><div className="ds-metric-label">{label}{Icon && <Icon size={17} aria-hidden="true" />}</div><div className="ds-metric-value" dir="auto">{value}</div>{detail && <p className="ds-description">{detail}</p>}</Panel>;
}
export function AuthShell({ title, subtitle, eyebrow, children, footer, className = "" }) {
  const { dir } = useI18n();
  const { t } = useI18n("auth");
  return <main className={`ds-auth seek-auth ${className}`} dir={dir}>
    <section className="ds-auth-story" aria-labelledby="auth-story-heading">
      <nav className="auth-ui-story-nav" aria-label={t("التنقل") }>
        <a href="#home" className="auth-ui-home-link">{t("العودة إلى الصفحة الرئيسية")}</a>
      </nav>
      <a href="#home" className="ds-wordmark seek-auth-wordmark auth-ui-story-brand" aria-label="rsvx7 / AI">
        <Logo size={34} /><span dir="ltr">rsvx7<span className="ds-wordmark-suffix"> / AI</span></span>
      </a>
      <div className="auth-ui-story-copy">
        <h1 className="auth-ui-story-heading" id="auth-story-heading">{t("ذكاء اصطناعي للهاكرز الأخلاقيين والفرق الحمراء")}</h1>
        <p>{t("مساعد ذكاء اصطناعي احترافي لأبحاث الأمن والمشاريع وسير عمل المطورين.")}</p>
        <ul className="auth-ui-story-features" aria-label={t("الميزات")}>
          <li>{t("أبحاث أمنية")}</li><li>{t("مشاريع وسياق محفوظ")}</li><li>{t("مساعد Hermes")}</li><li>{t("تطوير واضح")}</li>
        </ul>
      </div>
      <p className="auth-ui-story-footer">{t("rsvx7 / AI · مساحة عمل آمنة وواضحة")}</p>
    </section>
    <section className="ds-auth-form-area"><div className="ds-auth-form">
      <div className="auth-ui-form-nav"><a href="#home" className="auth-ui-home-link">{t("الصفحة الرئيسية")}</a><LanguageSwitcher className="auth-language-switcher" /></div>
      {eyebrow && <p className="ds-eyebrow">{eyebrow}</p>}{title && <h2>{title}</h2>}{subtitle && <p className="ds-description">{subtitle}</p>}
      <div className="ds-auth-body">{children}</div>{footer && <footer className="ds-auth-footer">{footer}</footer>}
    </div></section>
  </main>;
}
