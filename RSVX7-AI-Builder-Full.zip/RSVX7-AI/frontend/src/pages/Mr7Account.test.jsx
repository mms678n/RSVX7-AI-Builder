import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Dashboard from "./Dashboard";
import { setLanguage } from "@/i18n/runtime";

const mockAuthFetch = jest.fn();
const mockLogout = jest.fn();
const user = {
  _id: "mr7-user",
  username: "mr7-demo",
  plan: "wallet",
  status: "active",
  token_balance: 4200,
  total_used_tokens: 1800,
  total_input_tokens: 1000,
  total_output_tokens: 800,
  telegram: { verified: true },
};

jest.mock("@/context/AuthContext", () => ({
  useAuth: () => ({
    user,
    authFetch: mockAuthFetch,
    logout: mockLogout,
    refresh: jest.fn().mockResolvedValue({}),
    activateSession: jest.fn().mockResolvedValue({}),
  }),
}));
jest.mock("@/components/chat/Logo", () => () => <span aria-hidden="true">logo</span>);
jest.mock("@/lib/clipboard", () => ({ copyToClipboard: jest.fn().mockResolvedValue(undefined) }));
jest.mock("@/components/design/Primitives", () => {
  const React = require("react");
  return {
    ActionButton: ({ children, loading, disabled, ...props }) => <button {...props} disabled={disabled || loading}>{children}</button>,
    EmptyState: ({ title, description }) => <div><h3>{title}</h3><p>{description}</p></div>,
    LoadingState: ({ label }) => <div role="status">{label}</div>,
    MetricCard: ({ label, value, detail }) => <section><span>{label}</span><strong>{value}</strong><small>{detail}</small></section>,
    PageShell: ({ children, ...props }) => <main {...props}>{children}</main>,
    Panel: ({ children, ...props }) => <section {...props}>{children}</section>,
    StatusNote: ({ children, onRetry, ...props }) => <div {...props} role={props.tone === "error" ? "alert" : "status"}>{children}{onRetry && <button onClick={onRetry}>retry</button>}</div>,
  };
});

const reply = (json, ok = true) => ({ ok, status: ok ? 200 : 400, json: async () => json });
let container;
let root;

beforeEach(async () => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  setLanguage("ar");
  mockAuthFetch.mockReset();
  mockLogout.mockReset();
  global.fetch = jest.fn().mockResolvedValue(reply({ packs: [] }));
  mockAuthFetch.mockImplementation((path) => {
    if (path === "/billing/balance") return Promise.resolve(reply({ ...user, unlimited: false }));
    if (path === "/referrals/me") return Promise.resolve(reply({ code: "AB12CD34", invitee_bonus: 2500, referrer_bonus: 10000, referral_count: 2, referral_tokens_earned: 20000, was_referred: false, reward_pending: false }));
    return Promise.resolve(reply({}));
  });
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
  await act(async () => root.render(<Dashboard onExit={() => {}} />));
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
  jest.restoreAllMocks();
});

test("uses the MR7 account surface and keeps the existing account testids", () => {
  expect(container.querySelector(".dashboard-ui")).not.toBeNull();
  expect(container.querySelector(".dashboard-ui").dir).toBe("rtl");
  expect(container.querySelector(".dashboard-wallet")).not.toBeNull();
  expect(container.querySelector('[data-testid="dashboard-tab-coupon"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="theme-switcher"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="dash-logout-btn"]')).not.toBeNull();
  expect(container.querySelector(".blur-in")).toBeNull();
});

test("keeps coupon input controlled during language rerenders", async () => {
  await act(async () => container.querySelector('[data-testid="dashboard-tab-coupon"]').click());
  const input = container.querySelector('[data-testid="coupon-code"]');
  await act(async () => {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    setter.call(input, "mr7-save");
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
  expect(input.value).toBe("MR7-SAVE");
  await act(async () => setLanguage("en"));
  expect(container.querySelector('[data-testid="coupon-code"]').value).toBe("MR7-SAVE");
});

test("switches the account surface to LTR without changing the model or callbacks", async () => {
  await act(async () => setLanguage("en"));
  expect(container.querySelector(".dashboard-ui").dir).toBe("ltr");
  expect(container.querySelector('[data-testid="dash-logout-btn"]')).not.toBeNull();
});
