import React, { useEffect, useState } from "react";
import {
  ArrowRight,
  Brain,
  Check,
  ChevronDown,
  Code2,
  FolderKanban,
  Menu,
  MessageSquare,
  Paperclip,
  Search,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import Logo from "@/components/chat/Logo";
import { LanguageSwitcher, useI18n } from "@/i18n";
import ThemeSwitcher from "@/components/design/ThemeSwitcher";
import "@/i18n/catalogs/home";
import "./mr7-landing.css";

const PERSONAS = [
  { id: "kaligpt", icon: Sparkles, label: "KaliGPT", hint: "سريع · عام", copy: "للمهام اليومية، الصياغة، والعصف الذهني داخل مساحة عملك." },
  { id: "deepdark", icon: Brain, label: "DeepDark", hint: "تحليل دقيق", copy: "للتفكير المتأني وتحليل الأسئلة متعددة الخطوات بوضوح." },
  { id: "rsvx7-ai", icon: Code2, label: "rsvx7", hint: "كود · تصحيح · إعادة هيكلة", copy: "لمراجعة الكود، التصحيح، وإعادة الهيكلة مع سياق مشروعك." },
];

const FAQS = [
  { question: "ما الذي يقدمه rsvx7؟", answer: "rsvx7 مساحة عمل للمحادثات والمشاريع والكتابة. تجمع المحادثات والملفات وسياق المشروع في مكان واحد، مع ثلاث شخصيات مساعدة." },
  { question: "ما النموذج المستخدم؟", answer: "الشخصيات الثلاث في الواجهة تعمل على Hermes كما هو مضبوط في التطبيق. لا نغيّر الحسابات أو النموذج من الصفحة العامة." },
  { question: "هل أستطيع استخدام ملفاتي داخل المحادثة؟", answer: "نعم، يمكن إرفاق الملفات بالمحادثة المتاحة في حسابك، مع إبقاء تنظيم المشروع والمحادثات واضحًا." },
  { question: "ما اللغات المتاحة؟", answer: "الواجهة متاحة بالعربية والإنجليزية فقط، مع اتجاه RTL للعربية وLTR للإنجليزية. يمكنك تبديل اللغة من الشريط العلوي." },
];

function ArrowAction({ children, onClick, className = "", testId }) {
  return (
    <button type="button" className={`landing-button landing-button-primary ${className}`} onClick={onClick} data-testid={testId}>
      <span>{children}</span>
      <ArrowRight size={16} aria-hidden="true" />
    </button>
  );
}

function ToolsMenu({ t, isOpen, setIsOpen, onNavigate }) {
  const tools = [
    { href: "#projects", icon: FolderKanban, title: "المشاريع", copy: "نظّم السياق والمحادثات" },
    { href: "#projects", icon: Search, title: "الذاكرة والبحث", copy: "اعثر على ما حفظته" },
    { href: "#code", icon: Code2, title: "مساعد الكود", copy: "راجع واكتب داخل المحادثة" },
  ];
  return (
    <div className="landing-tools">
      <button
        type="button"
        className="landing-nav-link landing-tools-trigger"
        aria-expanded={isOpen}
        aria-haspopup="true"
        data-testid="landing-tools-trigger"
        onClick={() => setIsOpen((value) => !value)}
      >
        <Code2 size={15} aria-hidden="true" />
        <span>{t("الأدوات")}</span>
        <ChevronDown size={14} className={isOpen ? "is-open" : ""} aria-hidden="true" />
      </button>
      {isOpen && (
        <div className="landing-tools-menu" role="menu" data-testid="landing-tools-menu">
          <p className="landing-menu-label">{t("أدوات rsvx7")}</p>
          {tools.map(({ href, icon: Icon, title, copy }) => (
            <a key={title} href={href} role="menuitem" className="landing-tool-item" onClick={() => { setIsOpen(false); onNavigate?.(); }}>
              <span className="landing-tool-icon"><Icon size={17} aria-hidden="true" /></span>
              <span><strong>{t(title)}</strong><small>{t(copy)}</small></span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Landing({ onSignIn, onRegister, onChat }) {
  const { t, dir, locale } = useI18n("home");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [mobileToolsOpen, setMobileToolsOpen] = useState(false);

  useEffect(() => {
    if (!mobileOpen && !toolsOpen) return undefined;
    const onKeyDown = (event) => {
      if (event.key === "Escape") {
        setMobileOpen(false);
        setToolsOpen(false);
        setMobileToolsOpen(false);
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [mobileOpen, toolsOpen]);

  const closeMobile = () => setMobileOpen(false);
  const navItems = [
    { href: "#features", label: "الميزات" },
    { href: "#projects", label: "المشاريع" },
    { href: "#how-to-use", label: "طريقة الاستخدام" },
    { href: "#faq", label: "الأسئلة الشائعة" },
  ];

  return (
    <main className="rsvx7-landing" dir={dir} data-testid="landing-page" data-locale={locale}>
      <header className="landing-navbar">
        <div className="landing-nav-inner">
          <a className="landing-brand" href="#home" aria-label={t("العودة إلى بداية rsvx7")} onClick={closeMobile}>
            <Logo size={30} className="landing-brand-mark" />
            <span>rsvx7</span>
          </a>

          <nav className="landing-desktop-nav" aria-label={t("التنقل الرئيسي")}>
            {navItems.map(({ href, label }) => <a key={href} href={href} className="landing-nav-link">{t(label)}</a>)}
            <ToolsMenu t={t} isOpen={toolsOpen} setIsOpen={setToolsOpen} onNavigate={closeMobile} />
          </nav>

          <div className="landing-nav-actions">
            <LanguageSwitcher className="landing-language-switcher" />
            <ThemeSwitcher />
            <button type="button" className="landing-signin landing-nav-cta" onClick={onSignIn} data-testid="landing-sign-in">{t("تسجيل الدخول")}</button>
            <ArrowAction onClick={onRegister} testId="landing-register" className="landing-nav-register">{t("ابدأ الآن")}</ArrowAction>
            <button
              type="button"
              className="landing-mobile-toggle"
              aria-label={mobileOpen ? t("إغلاق القائمة") : t("فتح القائمة")}
              aria-expanded={mobileOpen}
              aria-controls="landing-mobile-menu"
              data-testid="landing-mobile-menu-button"
              onClick={() => setMobileOpen((value) => !value)}
            >
              {mobileOpen ? <X size={20} aria-hidden="true" /> : <Menu size={20} aria-hidden="true" />}
            </button>
          </div>
        </div>
        {mobileOpen && (
          <nav id="landing-mobile-menu" className="landing-mobile-menu" aria-label={t("التنقل في الهاتف")} data-testid="landing-mobile-menu">
            {navItems.map(({ href, label }) => <a key={href} href={href} onClick={closeMobile}>{t(label)}</a>)}
            <button type="button" aria-expanded={mobileToolsOpen} aria-controls="landing-mobile-tools" onClick={() => setMobileToolsOpen((value) => !value)}>{t("الأدوات")} <ChevronDown size={16} className={mobileToolsOpen ? "is-open" : ""} aria-hidden="true" /></button>
            {mobileToolsOpen && <div id="landing-mobile-tools" className="landing-mobile-tools" role="menu" data-testid="landing-mobile-tools">
              <a href="#projects" role="menuitem" onClick={closeMobile}><FolderKanban size={16} aria-hidden="true" />{t("المشاريع")}</a>
              <a href="#projects" role="menuitem" onClick={closeMobile}><Search size={16} aria-hidden="true" />{t("الذاكرة والبحث")}</a>
              <a href="#code" role="menuitem" onClick={closeMobile}><Code2 size={16} aria-hidden="true" />{t("مساعد الكود")}</a>
            </div>}
            <button type="button" className="landing-mobile-signin" onClick={() => { closeMobile(); onSignIn?.(); }}>{t("تسجيل الدخول")}</button>
            <button type="button" className="landing-mobile-register" onClick={() => { closeMobile(); onRegister?.(); }}>{t("ابدأ الآن")}</button>
          </nav>
        )}
      </header>

      <section id="home" className="landing-hero" aria-labelledby="landing-hero-title">
        <div className="landing-hero-glow" aria-hidden="true" />
        <div className="landing-hero-content">
          <p className="landing-eyebrow"><ShieldCheck size={15} aria-hidden="true" /> {t("الأمن السيبراني واختبار الاختراق")}</p>
          <h1 id="landing-hero-title" className="landing-hero-title">
            <span>{t("ذكاء اصطناعي قوي لـ")}</span>
            <span className="landing-accent">{t("خبراء الأمن السيبراني")}</span>
          </h1>
          <p className="landing-hero-copy">{t("اجمع أفكارك ومحادثاتك وملفاتك في مساحة عمل واحدة، واختر الشخصية المناسبة مع الحفاظ على سياق مشروعك.")}</p>
          <div className="landing-hero-actions">
            <ArrowAction onClick={onRegister} testId="landing-hero-register">{t("ابدأ مجانًا")}</ArrowAction>
            <button type="button" className="landing-button landing-button-secondary" onClick={onChat} data-testid="landing-hero-chat">
              <MessageSquare size={16} aria-hidden="true" /> {t("جرّب المحادثة")}
            </button>
          </div>
          <ul className="landing-hero-facts" aria-label={t("مزايا rsvx7")}>
            <li><Check size={15} aria-hidden="true" /> {t("ثلاث شخصيات مساعدة")}</li>
            <li><Check size={15} aria-hidden="true" /> {t("Hermes كما هو")}</li>
            <li><Check size={15} aria-hidden="true" /> {t("العربية والإنجليزية")}</li>
          </ul>
        </div>
      </section>

      <section id="features" className="landing-section landing-features" aria-labelledby="features-title">
        <div className="landing-section-heading">
          <p className="landing-section-kicker">{t("ما الذي يمكنك فعله")}</p>
          <h2 id="features-title">{t("كل ما تحتاجه للمحادثة والعمل، بلا ضوضاء")}</h2>
          <p>{t("محادثات ومشاريع وملفات منظمة، بأدوات واضحة تبقي عملك في سياقه.")}</p>
        </div>
        <div className="landing-feature-grid">
          <article className="landing-feature-card">
            <span className="landing-feature-icon"><FolderKanban size={21} aria-hidden="true" /></span>
            <h3>{t("مشاريع تحفظ السياق")}</h3>
            <p>{t("نظّم المحادثات ضمن مشاريع مستقلة لتبقى الفكرة والملفات والسياق قريبًا منك.")}</p>
            <a href="#projects" className="landing-inline-link">{t("استكشف المشاريع")} <ArrowRight size={14} aria-hidden="true" /></a>
          </article>
          <article className="landing-feature-card">
            <span className="landing-feature-icon"><MessageSquare size={21} aria-hidden="true" /></span>
            <h3>{t("محادثات أوضح")}</h3>
            <p>{t("ابدأ محادثة جديدة، تابع ما حفظته، وبدّل الشخصية عندما تتغير طبيعة المهمة.")}</p>
            <button type="button" className="landing-inline-link landing-inline-button" onClick={onChat}>{t("ابدأ محادثة")} <ArrowRight size={14} aria-hidden="true" /></button>
          </article>
          <article className="landing-feature-card">
            <span className="landing-feature-icon"><Paperclip size={21} aria-hidden="true" /></span>
            <h3>{t("ملفات في مكانها")}</h3>
            <p>{t("أرفق الملفات داخل المحادثة عندما تحتاج إلى قراءة أو مراجعة محتوى محدد.")}</p>
            <a href="#projects" className="landing-inline-link">{t("شاهد طريقة التنظيم")} <ArrowRight size={14} aria-hidden="true" /></a>
          </article>
        </div>
      </section>

      <section id="assistants" className="landing-section landing-assistants" aria-labelledby="assistants-title">
        <div className="landing-section-heading landing-section-heading-wide">
          <p className="landing-section-kicker">{t("الشخصيات")}</p>
          <h2 id="assistants-title">{t("اختر أسلوب المساعدة المناسب")}</h2>
          <p>{t("ثلاث شخصيات فعلية، ونموذج Hermes واحد كما هو مضبوط في حسابك.")}</p>
        </div>
        <div className="landing-persona-grid">
          {PERSONAS.map(({ id, icon: Icon, label, hint, copy }) => (
            <article className={`landing-persona-card landing-persona-${id}`} key={id}>
              <div className="landing-persona-top"><span className="landing-persona-icon"><Icon size={19} aria-hidden="true" /></span><span className="landing-persona-status">{t("متاح")}</span></div>
              <h3>{t(label)}</h3>
              <p className="landing-persona-hint">{t(hint)}</p>
              <p>{t(copy)}</p>
              <span className="landing-persona-model">Hermes</span>
            </article>
          ))}
        </div>
      </section>

      <section id="projects" className="landing-section landing-projects" aria-labelledby="projects-title">
        <div className="landing-projects-copy">
          <p className="landing-section-kicker">{t("مساحتك")}</p>
          <h2 id="projects-title">{t("من الفكرة إلى الملف، كل شيء في سياقه")}</h2>
          <p>{t("المشاريع تجمع ما يخص المهمة الواحدة: محادثاتك، الملفات التي أرفقتها، والبحث داخل ما حفظته. لا تحتاج إلى تذكر أين بدأت.")}</p>
          <ul className="landing-check-list">
            <li><Check size={16} aria-hidden="true" /> {t("محادثات مرتبة داخل المشروع")}</li>
            <li><Check size={16} aria-hidden="true" /> {t("ملفات مرفقة عند الحاجة")}</li>
            <li><Check size={16} aria-hidden="true" /> {t("بحث داخل مشاريعك")}</li>
          </ul>
          <button type="button" className="landing-button landing-button-secondary" onClick={onRegister} data-testid="landing-project-register">{t("أنشئ مساحة عملك")} <ArrowRight size={16} aria-hidden="true" /></button>
        </div>
        <div className="landing-project-window" aria-label={t("معاينة مشروع ومحادثات") }>
          <div className="landing-window-bar"><span /><span /><span /><strong>{t("مساحة العمل")}</strong></div>
          <div className="landing-window-body">
            <aside className="landing-project-sidebar">
              <p>{t("المشاريع")}</p>
              <div className="landing-project-active"><FolderKanban size={15} aria-hidden="true" /><span>{t("مشروعك الأول")}</span></div>
              <div className="landing-project-muted">{t("مشروع جديد")}</div>
            </aside>
            <div className="landing-project-main">
              <div className="landing-project-header"><div><span>{t("المشروع الحالي")}</span><strong>{t("مشروعك الأول")}</strong></div><Search size={17} aria-hidden="true" /></div>
              <div className="landing-conversation"><span className="landing-avatar"><MessageSquare size={14} aria-hidden="true" /></span><div><strong>{t("محادثة محفوظة")}</strong><small>{t("السياق والردود في مكان واحد")}</small></div><ChevronDown size={15} aria-hidden="true" /></div>
              <div className="landing-file-row"><Paperclip size={14} aria-hidden="true" /><span dir="auto">{t("ملف مرفق")}</span><small dir="ltr">.txt</small></div>
            </div>
          </div>
        </div>
      </section>

      <section id="code" className="landing-section landing-code-section" aria-labelledby="code-title">
        <div className="landing-code-card">
          <div className="landing-code-toolbar"><span className="landing-code-dot" /><span className="landing-code-dot" /><span className="landing-code-dot" /><span className="landing-code-name">rsvx7-workspace.js</span></div>
          <pre dir="ltr" aria-label={t("معاينة سياق المشروع")}><code>{`const workspace = {\n  name: "rsvx7",\n  assistant: "rsvx7",\n  model: "Hermes",\n  context: ["conversations", "files"]\n};\n\n// keep the work together\nworkspace.ask("راجع هذا الملف");`}</code></pre>
        </div>
        <div className="landing-code-copy">
          <p className="landing-section-kicker">{t("مساعد الكود")}</p>
          <h2 id="code-title">{t("فكرة واضحة، وكود أسهل للمراجعة")}</h2>
          <p>{t("استخدم شخصية rsvx7 لمراجعة الكود وتصحيحه وإعادة هيكلته، مع بقاء المحادثة والملف ضمن مشروعك.")}</p>
          <button type="button" className="landing-inline-link landing-inline-button" onClick={onChat}>{t("افتح المحادثة")} <ArrowRight size={14} aria-hidden="true" /></button>
        </div>
      </section>

      <section id="how-to-use" className="landing-section landing-howto" aria-labelledby="howto-title">
        <div className="landing-section-heading">
          <p className="landing-section-kicker">{t("ثلاث خطوات بسيطة")}</p>
          <h2 id="howto-title">{t("ابدأ من حيث أنت")}</h2>
          <p>{t("لا تحتاج إلى إعداد طويل. أنشئ حسابًا، اختر الطريقة التي تناسبك، ثم دع المشروع يحتفظ بالسياق.")}</p>
        </div>
        <ol className="landing-step-grid">
          <li><span className="landing-step-number">01</span><h3>{t("أنشئ حسابك")}</h3><p>{t("سجّل باسم مستخدم وكلمة مرور لفتح مساحة العمل.")}</p></li>
          <li><span className="landing-step-number">02</span><h3>{t("ابدأ محادثة")}</h3><p>{t("اختر إحدى الشخصيات الثلاث واطرح سؤالك بلغتك.")}</p></li>
          <li><span className="landing-step-number">03</span><h3>{t("نظّم ما أنجزته")}</h3><p>{t("احفظ المحادثة داخل مشروع وأرفق ملفًا عندما تحتاج إلى ذلك.")}</p></li>
        </ol>
      </section>

      <section id="faq" className="landing-section landing-faq" aria-labelledby="faq-title">
        <div className="landing-section-heading">
          <p className="landing-section-kicker">{t("إجابات مختصرة")}</p>
          <h2 id="faq-title">{t("الأسئلة الشائعة")}</h2>
        </div>
        <div className="landing-faq-list">
          {FAQS.map(({ question, answer }) => <details key={question} className="landing-faq-item"><summary>{t(question)}<ChevronDown size={18} aria-hidden="true" /></summary><p>{t(answer)}</p></details>)}
        </div>
      </section>

      <section className="landing-final-cta" aria-labelledby="final-cta-title">
        <div><p className="landing-section-kicker">{t("مساحتك تبدأ هنا")}</p><h2 id="final-cta-title">{t("جاهز لترتيب أفكارك؟")}</h2><p>{t("ابدأ محادثة في rsvx7، واجعل مشروعك يحتفظ بما يهمك.")}</p></div>
        <div className="landing-final-actions"><ArrowAction onClick={onRegister} testId="landing-final-register">{t("أنشئ حسابًا")}</ArrowAction><button type="button" className="landing-button landing-button-secondary" onClick={onSignIn} data-testid="landing-final-sign-in">{t("لدي حساب")}</button></div>
      </section>

      <footer className="landing-footer">
        <div className="landing-footer-brand"><Logo size={26} className="landing-brand-mark" /><strong>rsvx7</strong><span>{t("مساحة عمل للمحادثات والمشاريع")}</span></div>
        <nav aria-label={t("روابط التذييل")}><a href="#features">{t("الميزات")}</a><a href="#projects">{t("المشاريع")}</a><a href="#faq">{t("الأسئلة الشائعة")}</a></nav>
        <p dir="ltr">© {new Date().getFullYear()} rsvx7</p>
      </footer>
    </main>
  );
}
