jest.mock("@/lib/workspaceClient", () => ({
  wsMigrate: jest.fn(),
  wsListProjects: jest.fn(),
  wsCreateProject: jest.fn(),
  wsUpdateProject: jest.fn(),
  wsDeleteProject: jest.fn(),
  wsBootstrap: jest.fn(),
}));
jest.mock("@/context/AuthContext", () => ({ useAuth: () => ({ user: null }) }));
jest.mock("sonner", () => ({ toast: { error: jest.fn(), success: jest.fn() } }));

import { _migrateLegacyIfNeeded } from "./WorkspaceContext";
import * as workspaceClient from "@/lib/workspaceClient";

const mockWsMigrate = workspaceClient.wsMigrate;

const LEGACY_KEY = "rsvx7-chats-v1";
const CLAIM_KEY = "rsvx7-chats-v1-claimed-by";
const migratedKey = (uid) => `rsvx7_migrated_v1:${encodeURIComponent(uid)}`;
const legacyKey = (uid) => `${LEGACY_KEY}:${encodeURIComponent(uid)}`;

beforeEach(() => {
  localStorage.clear();
  mockWsMigrate.mockReset();
});

test("keeps the UID claim and original raw copy after failure, then retries for the same UID", async () => {
  const raw = JSON.stringify([{ id: "legacy-chat", messages: [{ role: "user", content: "keep" }] }]);
  localStorage.setItem(LEGACY_KEY, raw);
  mockWsMigrate.mockRejectedValueOnce(new Error("temporary network failure"));

  await expect(_migrateLegacyIfNeeded("user-a")).resolves.toBeNull();
  expect(mockWsMigrate).toHaveBeenCalledTimes(1);
  expect(localStorage.getItem(CLAIM_KEY)).toBe("user-a");
  expect(localStorage.getItem(LEGACY_KEY)).toBe(raw);
  expect(localStorage.getItem(migratedKey("user-a"))).toBeNull();

  mockWsMigrate.mockResolvedValueOnce({ conversations_imported: 1 });
  await expect(_migrateLegacyIfNeeded("user-a")).resolves.toEqual({ conversations_imported: 1 });
  expect(mockWsMigrate).toHaveBeenCalledTimes(2);
  expect(mockWsMigrate.mock.calls[1][0]).toEqual(JSON.parse(raw));
  expect(localStorage.getItem(migratedKey("user-a"))).toBe("1");
  expect(localStorage.getItem(LEGACY_KEY)).toBeNull();
  expect(localStorage.getItem(CLAIM_KEY)).toBeNull();
});

test("does not let another UID inherit a claimed global legacy source", async () => {
  const raw = JSON.stringify([{ id: "owned-chat" }]);
  localStorage.setItem(LEGACY_KEY, raw);
  localStorage.setItem(CLAIM_KEY, "user-a");

  await expect(_migrateLegacyIfNeeded("user-b")).resolves.toBeNull();
  expect(mockWsMigrate).not.toHaveBeenCalled();
  expect(localStorage.getItem(LEGACY_KEY)).toBe(raw);
  expect(localStorage.getItem(CLAIM_KEY)).toBe("user-a");
  expect(localStorage.getItem(migratedKey("user-b"))).toBe("1");
});

test("marks malformed legacy content only after proving it is not transferable", async () => {
  localStorage.setItem(legacyKey("user-scoped"), "not-json");

  await expect(_migrateLegacyIfNeeded("user-scoped")).resolves.toBeNull();
  expect(mockWsMigrate).not.toHaveBeenCalled();
  expect(localStorage.getItem(migratedKey("user-scoped"))).toBe("1");
  expect(localStorage.getItem(legacyKey("user-scoped"))).toBe("not-json");
});
