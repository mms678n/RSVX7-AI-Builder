import { streamStore } from "./streamStore";

describe("streamStore frame batching", () => {
  let callbacks;
  let nextHandle;
  let originalRaf;
  let originalCancel;

  beforeEach(() => {
    callbacks = new Map();
    nextHandle = 1;
    originalRaf = global.requestAnimationFrame;
    originalCancel = global.cancelAnimationFrame;
    global.requestAnimationFrame = jest.fn((callback) => {
      const handle = nextHandle++;
      callbacks.set(handle, callback);
      return handle;
    });
    global.cancelAnimationFrame = jest.fn((handle) => callbacks.delete(handle));
    streamStore.stop();
    streamStore.resetMetrics();
  });

  afterEach(() => {
    streamStore.stop();
    global.requestAnimationFrame = originalRaf;
    global.cancelAnimationFrame = originalCancel;
  });

  const paint = () => {
    const pending = [...callbacks.entries()];
    callbacks.clear();
    pending.forEach(([, callback]) => callback(0));
  };

  test("coalesces many pushes into one notification per frame", () => {
    const listener = jest.fn();
    const unsubscribe = streamStore.subscribe(listener);
    streamStore.start("assistant-1");
    listener.mockClear();

    streamStore.push("a");
    streamStore.push("ab");
    streamStore.push("abc");

    expect(listener).not.toHaveBeenCalled();
    expect(streamStore.getSnapshot("assistant-1")).toBe("abc");
    expect(streamStore.getMetrics()).toMatchObject({ pushes: 3, frames: 0, notifications: 1 });

    paint();
    expect(listener).toHaveBeenCalledTimes(1);
    expect(streamStore.getSnapshot("assistant-1")).toBe("abc");
    expect(streamStore.getMetrics()).toMatchObject({ frames: 1, notifications: 2 });
    unsubscribe();
  });

  test("flush publishes terminal text and stop cancels queued work", () => {
    const listener = jest.fn();
    const unsubscribe = streamStore.subscribe(listener);
    streamStore.start("assistant-2");
    listener.mockClear();
    streamStore.push("final");

    expect(streamStore.flush("assistant-2")).toBe(true);
    expect(listener).toHaveBeenCalledTimes(1);
    expect(streamStore.getSnapshot("assistant-2")).toBe("final");

    streamStore.push("stale queued text");
    expect(streamStore.stop("wrong-id")).toBe(false);
    expect(streamStore.getActiveId()).toBe("assistant-2");
    expect(streamStore.stop("assistant-2")).toBe(true);
    expect(global.cancelAnimationFrame).toHaveBeenCalled();
    expect(streamStore.getSnapshot("assistant-2")).toBeNull();
    expect(streamStore.getActiveId()).toBeNull();
    unsubscribe();
  });

  test("records raw chunk workload separately from frame workload", () => {
    streamStore.start("assistant-3");
    streamStore.recordChunk();
    streamStore.recordChunk();
    streamStore.push("one");
    streamStore.push("two");

    expect(streamStore.getMetrics()).toMatchObject({ chunks: 2, pushes: 2, frames: 0 });
    paint();
    expect(streamStore.getMetrics()).toMatchObject({ chunks: 2, frames: 1 });
  });
});

test("reasoning is separate and both channels flush together before stop", () => {
  streamStore.start("thinking-only");
  streamStore.pushReasoning("provider reasoning");
  streamStore.push("visible answer");
  expect(streamStore.getReasoningSnapshot("thinking-only")).toBe("provider reasoning");
  expect(streamStore.getSnapshot("thinking-only")).toBe("visible answer");
  expect(streamStore.getReasoningSnapshot("other-message")).toBeNull();
  expect(streamStore.flush("thinking-only")).toBe(true);
  streamStore.stop("thinking-only");
  expect(streamStore.getReasoningSnapshot("thinking-only")).toBeNull();
});

test("reasoning without content still publishes once and does not leak to next run", () => {
  streamStore.start("old-thought");
  streamStore.pushReasoning("a");
  streamStore.pushReasoning("ab");
  const listener = jest.fn();
  const unsubscribe = streamStore.subscribe(listener);
  streamStore.flush("old-thought");
  expect(listener).toHaveBeenCalledTimes(1);
  streamStore.start("new-answer");
  expect(streamStore.getReasoningSnapshot("new-answer")).toBe("");
  expect(streamStore.stop("old-thought")).toBe(false);
  unsubscribe();
  streamStore.stop("new-answer");
});

test("React snapshots change only on publication while terminal reads stay lossless", () => {
  streamStore.start("frame-only");
  streamStore.push("latest text");
  streamStore.pushReasoning("latest reasoning");
  expect(streamStore.getSnapshot("frame-only")).toBe("latest text");
  expect(streamStore.getPublishedSnapshot("frame-only")).toBe("");
  expect(streamStore.getPublishedReasoningSnapshot("frame-only")).toBe("");
  streamStore.flush("frame-only");
  expect(streamStore.getPublishedSnapshot("frame-only")).toBe("latest text");
  expect(streamStore.getPublishedReasoningSnapshot("frame-only")).toBe("latest reasoning");
  expect(streamStore.getPublishedSnapshot("other")).toBeNull();
  streamStore.stop("frame-only");
  expect(streamStore.getPublishedSnapshot("frame-only")).toBeNull();
  expect(streamStore.getPublishedReasoningSnapshot("frame-only")).toBeNull();
});

describe('adaptive display pacing', () => {
  let frames, time, originalRaf, originalCancel, clock, originalMatch;
  beforeEach(() => {
    streamStore.stop();
    frames = new Map(); time = 0;
    let id = 0;
    originalRaf = global.requestAnimationFrame;
    originalCancel = global.cancelAnimationFrame;
    originalMatch = window.matchMedia;
    window.matchMedia = () => ({ matches: false });
    global.requestAnimationFrame = fn => { frames.set(++id, fn); return id; };
    global.cancelAnimationFrame = id => frames.delete(id);
    clock = jest.spyOn(performance, 'now').mockImplementation(() => time);
  });
  afterEach(() => {
    streamStore.stop(); clock.mockRestore();
    global.requestAnimationFrame = originalRaf;
    global.cancelAnimationFrame = originalCancel;
    window.matchMedia = originalMatch;
  });
  const paint = (ms = 16) => {
    time += ms;
    const callbacks = [...frames.values()]; frames.clear(); callbacks.forEach(fn => fn(time));
  };
  test('network bursts are paced without delaying persistence, then fully catch up', () => {
    streamStore.start('paced');
    const text = 'A detailed response '.repeat(100);
    streamStore.push(text); paint();
    const first = streamStore.getPublishedSnapshot('paced');
    expect(first.length).toBeGreaterThan(0);
    expect(first.length).toBeLessThan(text.length);
    expect(streamStore.getSnapshot('paced')).toBe(text);
    let previous = first;
    for (let i = 0; i < 20; i++) {
      paint();
      const next = streamStore.getPublishedSnapshot('paced');
      expect(next.startsWith(previous)).toBe(true); previous = next;
    }
    expect(previous).toBe(text);
    expect(frames.size).toBe(0);
  });
  test('Arabic diacritics and joined emoji appear as complete graphemes', () => {
    streamStore.start('unicode');
    const text = 'مُرْحَبًا 👩🏽‍💻 👨‍👩‍👧‍👦 '.repeat(30);
    const boundaries = new Set([0]); let length = 0;
    for (const item of new Intl.Segmenter(undefined, {granularity:'grapheme'}).segment(text)) { length += item.segment.length; boundaries.add(length); }
    streamStore.push(text);
    for (let i = 0; i < 20; i++) { paint(); expect(boundaries.has(streamStore.getPublishedSnapshot('unicode').length)).toBe(true); }
    expect(streamStore.getPublishedSnapshot('unicode')).toBe(text);
  });
  test('terminal flush exposes all buffered text immediately and clears animation', () => {
    streamStore.start('terminal'); streamStore.push('answer '.repeat(300)); paint();
    streamStore.flush('terminal');
    expect(streamStore.getPublishedSnapshot('terminal')).toBe(streamStore.getSnapshot('terminal'));
    expect(frames.size).toBe(0);
  });
  test('reduced motion bypasses pacing and replacements do not splice stale text', () => {
    window.matchMedia = () => ({matches:true});
    streamStore.start('accessible'); streamStore.push('long '.repeat(300)); paint();
    expect(streamStore.getPublishedSnapshot('accessible')).toBe(streamStore.getSnapshot('accessible'));
    streamStore.push('replacement'); paint();
    expect(streamStore.getPublishedSnapshot('accessible')).toBe('replacement');
  });
  test('queued frames cannot leak content into the next message', () => {
    streamStore.start('old'); streamStore.push('old '.repeat(200)); paint();
    const stale = [...frames.values()];
    streamStore.start('new'); streamStore.push('new');
    stale.forEach(fn => fn(time)); paint();
    expect(streamStore.getPublishedSnapshot('new')).toBe('new');
    expect(streamStore.getSnapshot('old')).toBeNull();
  });
});
