import {createRuntime} from './runtime';
const mockBoot=jest.fn(), mockPause=jest.fn(), mockVerify=jest.fn(), mockWrite=jest.fn(), mockTeardown=jest.fn();
jest.mock('@webcontainer/api',()=>({WebContainer:{boot:(...args)=>mockBoot(...args)}}));
jest.mock('./generated-runtime',()=>({readPreviewHealth:()=>null,ProjectRuntime:class {
  constructor(){this.state={listen:()=>()=>{},get:()=>({})};this.repairRequest={listen:()=>()=>{}};this.pause=mockPause;this.verify=mockVerify;}
  beginTask(){} stop(){} beginFileChanges(){} fileWritten(){}
}}));
const source={'/home/project/index.html':{content:'<h1>Saved</h1>',isBinary:false}};
beforeEach(()=>{jest.clearAllMocks();Object.defineProperty(window,'crossOriginIsolated',{configurable:true,value:true});mockBoot.mockResolvedValue({teardown:mockTeardown,fs:{mkdir:jest.fn(),writeFile:mockWrite,rm:jest.fn()}});});
test('stopping during container boot prevents later writes or checks',async()=>{
  let resolve;mockBoot.mockReturnValue(new Promise(r=>resolve=r));
  const session=createRuntime(()=>{},()=>{}), pending=session.apply(source);
  for(let i=0;i<10&&!mockBoot.mock.calls.length;i++)await Promise.resolve();
  session.stop();resolve({teardown:mockTeardown,fs:{writeFile:mockWrite}});
  await pending;expect(mockWrite).not.toHaveBeenCalled();expect(mockVerify).not.toHaveBeenCalled();session.dispose();await Promise.resolve();
});
test('an unsupported preview reports its requirement and preserves source without executing it',async()=>{
  Object.defineProperty(window,'crossOriginIsolated',{configurable:true,value:false});
  const session=createRuntime(()=>{},()=>{});await session.apply(source);
  expect(mockBoot).not.toHaveBeenCalled();expect(mockPause).toHaveBeenCalledWith(expect.stringContaining('HTTPS'));expect(source['/home/project/index.html'].content).toContain('Saved');session.dispose();
});
test('a supported preview mounts source and calls actual verification adapter',async()=>{
  const session=createRuntime(()=>{},()=>{});await session.apply(source);
  expect(mockWrite).toHaveBeenCalledWith('index.html','<h1>Saved</h1>');expect(mockVerify).toHaveBeenCalled();session.dispose();
});

test('a failed file replacement remains tracked and is removed on the next repair',async()=>{
  const files=new Map();let failWrite=false;
  mockBoot.mockResolvedValue({teardown:mockTeardown,fs:{mkdir:jest.fn(),rm:async name=>files.delete(name),writeFile:async(name,content)=>{if(failWrite)throw Error('fixture disk write failed');files.set(name,content);}}});
  const session=createRuntime(()=>{},()=>{});
  await session.apply({...source,'/home/project/old.js':{content:'old',isBinary:false}});
  failWrite=true;await session.apply(source);
  expect(mockPause).toHaveBeenCalledWith('fixture disk write failed');
  failWrite=false;await session.apply({'/home/project/new.html':{content:'new',isBinary:false}});
  expect([...files.keys()]).toEqual(['new.html']);
  session.dispose();
});
