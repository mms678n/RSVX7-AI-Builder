import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const require=createRequire(path.join(ROOT,'frontend/package.json'));
const parser=require('@babel/parser');
const base=path.join(ROOT,'frontend/src');
const arabic=/[\u0600-\u06ff]/;
const catalogs=new Map();
const walk=(node,visit)=>{if(!node||typeof node!=='object')return;visit(node);for(const [key,value] of Object.entries(node)){if(['loc','start','end','extra','comments','leadingComments','trailingComments'].includes(key))continue;if(Array.isArray(value))value.forEach(n=>walk(n,visit));else if(value&&typeof value==='object')walk(value,visit);}};
const parse=(file)=>parser.parse(fs.readFileSync(file,'utf8'),{sourceType:'module',plugins:['jsx']});
for(const name of fs.readdirSync(path.join(base,'i18n/catalogs')).filter(n=>n.endsWith('.js'))){
 walk(parse(path.join(base,'i18n/catalogs',name)),n=>{if(n.type!=='CallExpression'||n.callee?.name!=='registerTranslations')return;const ns=n.arguments[0]?.value;const entries=n.arguments[1];if(!ns||entries?.type!=='ObjectExpression')return;const pairs=new Map();for(const p of entries.properties){if(p.type!=='ObjectProperty'||p.value.type!=='StringLiteral')continue;const key=p.key.value??p.key.name;pairs.set(key,p.value.value);}catalogs.set(ns,pairs);});
}
const files=[];function collect(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,item.name);if(item.isDirectory()){if(!['i18n','constants'].includes(item.name))collect(p);}else if(/\.(jsx|js)$/.test(p)&&!/\.test\./.test(p))files.push(p);}}collect(base);
const missing=[],raw=[];
const has=(key)=>[...catalogs.values()].some(c=>c.has(key));
for(const file of files){const relative=path.relative(ROOT,file);walk(parse(file),n=>{
 if(n.type==='CallExpression'&&n.callee?.name==='t'&&n.arguments[0]?.type==='StringLiteral'){const key=n.arguments[0].value;if(arabic.test(key)&&!has(key))missing.push({file:relative,line:n.loc.start.line,key});}
 if(n.type==='JSXText'&&arabic.test(n.value)&&n.value.trim()){const value=n.value.trim().replace(/\s+/g,' ');if(value!=='العربية')raw.push({file:relative,line:n.loc.start.line,value});}
 if(n.type==='JSXAttribute'&&['placeholder','title','aria-label','alt'].includes(n.name?.name)&&n.value?.type==='StringLiteral'&&arabic.test(n.value.value)){raw.push({file:relative,line:n.loc.start.line,attribute:n.name.name,value:n.value.value});}
});}
const report={catalogs:Object.fromEntries([...catalogs].map(([k,v])=>[k,v.size])),total_entries:[...catalogs.values()].reduce((s,c)=>s+c.size,0),missing_keys:missing,raw_ui_text:raw};
const target=path.join(ROOT,'docs/i18n/source-audit.json');fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
if(missing.length||raw.length)process.exitCode=1;
