"""One-origin RSVX7 app plus private, loopback-only Builder engine."""
import os
import sys
import hmac
import hashlib
import signal
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'backend'))
from dotenv import load_dotenv
load_dotenv(ROOT / 'backend/.env')
load_dotenv(ROOT / '.env')
from session_config import session_signing_secret
key = session_signing_secret(require_configured=True)
env = dict(os.environ)
env['BUILDER_ENGINE_SECRET'] = hmac.new(key.encode(), b'rsvx7-builder-engine-v1', hashlib.sha256).hexdigest()
env['BUILDER_API_ORIGIN'] = 'http://127.0.0.1:' + os.getenv('PORT', '3000')
engine = ROOT / 'builder/dist/service.mjs'
if not engine.is_file():
    raise SystemExit('Build frontend first; the private Builder engine is missing.')
children = [subprocess.Popen(['node', str(engine)], cwd=ROOT, env=env)]
children.append(subprocess.Popen([sys.executable, '-m', 'uvicorn', 'deployment:app', '--host', '0.0.0.0', '--port', os.getenv('PORT', '3000'), '--workers', '1'], cwd=ROOT/'backend', env=env))
def stop(*_):
    for child in children:
        if child.poll() is None: child.terminate()
for sig in (signal.SIGTERM, signal.SIGINT): signal.signal(sig, stop)
try:
    while all(c.poll() is None for c in children):
        try: children[0].wait(timeout=1)
        except subprocess.TimeoutExpired: pass
finally:
    stop()
    for child in children:
        try: child.wait(timeout=10)
        except subprocess.TimeoutExpired: child.kill()
sys.exit(next((c.returncode for c in children if c.returncode), 0))
