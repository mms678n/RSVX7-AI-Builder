@echo off
cd /d "%~dp0"
python scripts\start_local.py %*
pause
