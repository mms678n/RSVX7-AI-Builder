"""Referral rewards for rsvx7-ai.

Flow
────
1. Every user gets a permanent 8-char `referral_code` on registration.
2. New signups may include a `ref` field in the register body → we look it up
   and store `referred_by = <referrer_id>` plus `referral_pending = true` on
   the new account. NO tokens are handed out yet — abuse would be trivial.
3. When the new user finally verifies their Telegram, `finalize_referral()`
   is called. It:
     • Adds 2,500 bonus tokens to the newcomer.
     • Adds 10,000 bonus tokens to the referrer.
     • Flips `referral_pending → false` so nobody can double-claim.
     • Increments the referrer's `referral_count` for their dashboard.

Everything is idempotent — `finalize_referral()` can be called any number of
times, only the first call that finds `referral_pending: true` succeeds.
"""

import secrets, string, logging
from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pymongo.errors import DuplicateKeyError

from auth import db, current_user
from persistence import database_transaction

logger = logging.getLogger("referrals")

REFERRAL_ALPHABET = string.ascii_uppercase + string.digits  # no lowercase, no ambiguous chars
REFERRAL_CODE_LEN = 8

INVITEE_BONUS  = 2_500    # tokens added to the NEW signup after they link TG
REFERRER_BONUS = 10_000   # tokens added to the PERSON who owns the invite link


def _make_code() -> str:
    """8 upper-case alnum chars. ~1.4e12 possibilities → collision chance
    negligible until millions of users, we handle collisions defensively below."""
    return "".join(secrets.choice(REFERRAL_ALPHABET) for _ in range(REFERRAL_CODE_LEN))


async def ensure_referral_code(uid: str) -> str:
    async with database_transaction(db, collections=("referral_codes", "users")):
        return await _ensure_referral_code(uid)


async def _ensure_referral_code(uid: str) -> str:
    """Return the user's referral code, generating and persisting one if the
    account was created before this feature existed. Retries on collision."""
    u = await db.users.find_one({"_id": uid}, {"referral_code": 1})
    if not u: raise HTTPException(404, "User not found")
    if u.get("referral_code"):
        # Repair the lookup document if this is a pre-feature account. The
        # user value remains authoritative and is never replaced by a racer.
        try:
            await db.referral_codes.insert_one({"_id": u["referral_code"], "user_id": uid})
        except DuplicateKeyError:
            pass
        return u["referral_code"]
    mapped = await db.referral_codes.find_one({"user_id": uid}, {"_id": 1})
    if mapped:
        code = mapped["_id"]
        claimed = await db.users.update_one(
            {"_id": uid, "$or": [
                {"referral_code": {"$exists": False}},
                {"referral_code": None}, {"referral_code": ""},
            ]},
            {"$set": {"referral_code": code}},
        )
        if claimed.matched_count:
            return code
        current = await db.users.find_one({"_id": uid}, {"referral_code": 1})
        if current and current.get("referral_code"):
            return current["referral_code"]
    for _ in range(6):
        code = _make_code()
        try:
            await db.referral_codes.insert_one({"_id": code, "user_id": uid})
        except DuplicateKeyError:
            continue  # duplicate — retry
        claimed = await db.users.update_one(
            {"_id": uid, "$or": [
                {"referral_code": {"$exists": False}},
                {"referral_code": None}, {"referral_code": ""},
            ]},
            {"$set": {"referral_code": code}},
        )
        if claimed.matched_count:
            return code
        # Another concurrent call won the user's single code. Remove only
        # this loser's mapping; never delete the winner's mapping.
        await db.referral_codes.delete_one({"_id": code, "user_id": uid})
        current = await db.users.find_one({"_id": uid}, {"referral_code": 1})
        if current and current.get("referral_code"):
            return current["referral_code"]
        if not current:
            raise HTTPException(404, "User not found")
    raise HTTPException(500, "Could not allocate referral code")


async def resolve_referrer(code: Optional[str]) -> Optional[str]:
    """Look up a referral code → referrer user_id. Returns None if invalid,
    empty, or self-referral (checked upstream)."""
    if not code: return None
    code = code.strip().upper()
    if len(code) != REFERRAL_CODE_LEN: return None
    doc = await db.referral_codes.find_one({"_id": code})
    return doc.get("user_id") if doc else None


async def finalize_referral(uid: str) -> dict:
    async with database_transaction(db, collections=("users",)):
        result = await _finalize_referral(uid)
        # A SQL partial reward must roll back instead of committing one party
        # when a missing referrer or failed write prevents the other credit.
        if result.get("pending"):
            from persistence import uses_mysql
            if uses_mysql(db):
                raise HTTPException(503, "Referral reward is pending; retry later")
    if result.get("claimed"):
        await _notify_referral_reward(uid)
    return result


async def _finalize_referral(uid: str) -> dict:
    """Called RIGHT AFTER a user successfully verifies Telegram. If they have
    a pending referral, both sides are rewarded atomically and idempotently.
    Safe to call unconditionally — no-op when nothing is pending."""
    # Do not close pending before both credits exist. Two callers may enter
    # concurrently; the per-user marker updates below make each side safe.
    user = await db.users.find_one(
        {"_id": uid, "referral_pending": True,
         "referred_by": {"$exists": True, "$ne": None}},
    )
    if not user:
        return {"claimed": False}
    referrer_id = user.get("referred_by")
    if not referrer_id or referrer_id == uid:
        return {"claimed": False}

    marker = f"referral:{uid}"

    async def credit_party(target_id: str, amount: int, is_referrer: bool) -> bool:
        inc = {"token_balance": amount}
        if is_referrer:
            inc.update({"referral_count": 1, "referral_tokens_earned": amount})
        try:
            r = await db.users.update_one(
                {"_id": target_id, "referral_reward_markers": {"$ne": marker}},
                {"$inc": inc, "$addToSet": {"referral_reward_markers": marker}},
            )
            if r.matched_count:
                return True
        except Exception:
            logger.exception("referral credit failed target=%s marker=%s", target_id, marker)
        # A write can have succeeded even when the client saw an exception, and
        # a concurrent caller may already have applied the marker. Verify it;
        # otherwise keep the referral pending for a later retry.
        current = await db.users.find_one({"_id": target_id}, {"referral_reward_markers": 1})
        return bool(current and marker in (current.get("referral_reward_markers") or []))

    invitee_ok = await credit_party(uid, INVITEE_BONUS, False)
    if not invitee_ok:
        return {"claimed": False, "pending": True, "retryable": True}
    referrer_ok = await credit_party(referrer_id, REFERRER_BONUS, True)
    if not referrer_ok:
        logger.warning("referral remains pending uid=%s referrer=%s", uid, referrer_id)
        return {"claimed": False, "pending": True, "retryable": True}

    closed = await db.users.update_one(
        {"_id": uid, "referral_pending": True},
        {"$set": {
            "referral_pending": False,
            "referral_reward_state": "completed",
            "referral_rewarded_at": datetime.now(timezone.utc).isoformat(),
        }},
    )
    logger.info("referral.rewarded invitee=%s referrer=%s closed=%s",
                uid, referrer_id, bool(closed.matched_count))

    return {"claimed": bool(closed.matched_count), "completed": True,
            "invitee_bonus": INVITEE_BONUS, "referrer_bonus": REFERRER_BONUS}


async def _notify_referral_reward(uid: str):
    # Notify both parties via Telegram if the bot is configured.
    try:
        user = await db.users.find_one({"_id": uid}) or {}
        referrer_id = user.get("referred_by")
        from auth import _bot_send  # local import to avoid circular
        s = await db.settings.find_one({"_id": "global"}) or {}
        bot = s.get("telegram_bot_token")
        if bot:
            invitee_tg = (user.get("telegram") or {}).get("telegram_id")
            if invitee_tg:
                await _bot_send(bot, invitee_tg,
                    f"🎁 <b>+{INVITEE_BONUS:,} bonus tokens</b>\n\n"
                    f"شكراً لتسجيلك عبر رابط دعوة! تم إضافة <b>{INVITEE_BONUS:,}</b> "
                    f"توكن إضافي إلى رصيدك.")
            referrer_doc = await db.users.find_one({"_id": referrer_id}, {"telegram": 1})
            if referrer_doc:
                r_tg = (referrer_doc.get("telegram") or {}).get("telegram_id")
                if r_tg:
                    await _bot_send(bot, r_tg,
                        f"🎉 <b>Referral rewarded</b>\n\n"
                        f"صديق جديد سجّل عبر رابطك وربط تيليجرام.\n"
                        f"تمت إضافة <b>+{REFERRER_BONUS:,}</b> توكن إلى حسابك.")
    except Exception as e:
        logger.debug("referral tg notify skipped: %s", e)


# ─────────────────────────── API ───────────────────────────

router = APIRouter(prefix="/api/referrals")


@router.get("/me")
async def my_referral(u: dict = Depends(current_user)):
    """Everything the dashboard needs — code, share URL, stats, whether the
    user is a referred one and their reward status."""
    code = await ensure_referral_code(u["_id"])
    doc = await db.users.find_one(
        {"_id": u["_id"]},
        {"referral_count": 1, "referral_tokens_earned": 1,
         "referred_by": 1, "referral_pending": 1, "referral_rewarded_at": 1},
    ) or {}
    return {
        "code": code,
        "invitee_bonus": INVITEE_BONUS,
        "referrer_bonus": REFERRER_BONUS,
        "referral_count": int(doc.get("referral_count") or 0),
        "referral_tokens_earned": int(doc.get("referral_tokens_earned") or 0),
        # Only relevant to a user who signed up via someone else's link:
        "was_referred": bool(doc.get("referred_by")),
        "reward_pending": bool(doc.get("referral_pending")),
        "rewarded_at": doc.get("referral_rewarded_at"),
    }


@router.get("/lookup/{code}")
async def public_lookup(code: str):
    """Public: given a referral code, return the referrer's username so the
    registration page can show 'You were invited by <name>'."""
    uid = await resolve_referrer(code)
    if not uid:
        raise HTTPException(404, "Invalid referral code")
    ref = await db.users.find_one({"_id": uid}, {"username": 1})
    if not ref:
        raise HTTPException(404, "Invalid referral code")
    return {"code": code.upper(), "referrer_username": ref.get("username", "")}
