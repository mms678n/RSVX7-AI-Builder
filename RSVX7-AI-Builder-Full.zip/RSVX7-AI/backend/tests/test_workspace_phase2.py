"""Workspace Phase 2 backend tests: notes, files, memory injection, global search,
isolation, chat streaming with deepseek-v4-pro."""
import os, uuid, io, json
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')
OWNER_USER = "admin-rsvx7"
OWNER_PASS = os.environ.get("TEST_OWNER_PASS", "")


def _login(username, password):
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/auth/login",
               json={"username": username, "password": password, "remember_me": False})
    assert r.status_code == 200, f"login failed: {r.text}"
    tok = r.json().get("token")
    s.headers.update({"Authorization": f"Bearer {tok}"})
    s._token = tok
    return s


@pytest.fixture(scope="module")
def owner():
    return _login(OWNER_USER, OWNER_PASS)


@pytest.fixture(scope="module")
def user_b():
    uname = f"testp2{uuid.uuid4().hex[:8]}"
    pwd = "TestPass123!"
    r = requests.post(f"{BASE_URL}/api/auth/register", json={"username": uname, "password": pwd})
    assert r.status_code == 200, r.text
    s = _login(uname, pwd)
    s._username = uname
    return s


@pytest.fixture(scope="module")
def owner_project(owner):
    """Create a dedicated TEST project for Phase 2 tests."""
    r = owner.post(f"{BASE_URL}/api/workspace/projects",
                   json={"name": f"TEST_P2_{uuid.uuid4().hex[:6]}", "description": "phase2"})
    assert r.status_code == 200
    pid = r.json()["_id"]
    yield pid
    # cleanup
    try:
        owner.delete(f"{BASE_URL}/api/workspace/projects/{pid}")
    except Exception:
        pass


# ==================== Chat streaming with deepseek-v4-pro ====================
def test_chat_stream_deepseek_v4_pro(owner):
    with owner.post(f"{BASE_URL}/api/chat/stream",
                    json={"messages": [{"role": "user", "content": "Say the word OK and nothing else."}],
                          "personality": "rsvx7-ai"},
                    stream=True, timeout=60) as r:
        assert r.status_code == 200
        chunks_content = []
        got_error_line = False
        for raw in r.iter_lines(decode_unicode=True):
            if not raw:
                continue
            if raw.startswith("data: "):
                payload = raw[6:]
                if payload.strip() == "[DONE]":
                    break
                try:
                    obj = json.loads(payload)
                    if "t" in obj:
                        chunks_content.append(obj["t"])
                    if "error" in obj:
                        got_error_line = True
                        print("STREAM ERROR:", obj)
                except Exception:
                    pass
        assert not got_error_line, "SSE contained an error event"
        assert chunks_content, "No content chunks streamed"
        full = "".join(chunks_content)
        assert len(full) > 0


# ==================== Project instructions (memory) ====================
def test_project_instructions_persist(owner, owner_project):
    pid = owner_project
    instr = "Whenever the user says WOMBAT, reply with the exact phrase KANGAROO-ROO in caps."
    r = owner.patch(f"{BASE_URL}/api/workspace/projects/{pid}", json={"instructions": instr})
    assert r.status_code == 200
    assert r.json().get("instructions") == instr
    g = owner.get(f"{BASE_URL}/api/workspace/projects/{pid}").json()
    assert g.get("instructions") == instr


def test_project_memory_injection_in_stream(owner, owner_project):
    pid = owner_project
    # instructions already set by previous test in module order; ensure again idempotent
    instr = "Whenever the user says WOMBAT, reply with the exact phrase KANGAROO-ROO in caps."
    owner.patch(f"{BASE_URL}/api/workspace/projects/{pid}", json={"instructions": instr})

    def _stream(project_id):
        payload = {"messages": [{"role": "user", "content": "WOMBAT"}], "personality": "rsvx7-ai"}
        if project_id:
            payload["project_id"] = project_id
        chunks = []
        with owner.post(f"{BASE_URL}/api/chat/stream", json=payload, stream=True, timeout=90) as r:
            assert r.status_code == 200
            for raw in r.iter_lines(decode_unicode=True):
                if not raw or not raw.startswith("data: "):
                    continue
                p = raw[6:]
                if p.strip() == "[DONE]":
                    break
                try:
                    o = json.loads(p)
                    if "t" in o:
                        chunks.append(o["t"])
                except Exception:
                    pass
        return "".join(chunks)

    with_ctx = _stream(pid)
    print("WITH_CTX:", with_ctx[:400])
    assert "KANGAROO-ROO" in with_ctx.upper(), f"Expected KANGAROO-ROO with project_id; got: {with_ctx[:300]}"


# ==================== Notes CRUD ====================
class TestNotes:
    def test_create_list_update_delete(self, owner, owner_project):
        pid = owner_project
        # create
        r = owner.post(f"{BASE_URL}/api/workspace/projects/{pid}/notes",
                       json={"content": "TEST_note_original"})
        assert r.status_code == 200, r.text
        note = r.json()
        assert note["_id"].startswith("n_")
        assert note["content"] == "TEST_note_original"
        nid = note["_id"]

        # list
        lst = owner.get(f"{BASE_URL}/api/workspace/projects/{pid}/notes").json()
        assert any(n["_id"] == nid for n in lst)

        # update
        r = owner.patch(f"{BASE_URL}/api/workspace/notes/{nid}",
                        json={"content": "TEST_note_updated"})
        assert r.status_code == 200
        assert r.json()["content"] == "TEST_note_updated"

        # 404 on unknown
        r = owner.patch(f"{BASE_URL}/api/workspace/notes/n_nope", json={"content": "x"})
        assert r.status_code == 404

        # delete
        r = owner.delete(f"{BASE_URL}/api/workspace/notes/{nid}")
        assert r.status_code == 200
        r = owner.delete(f"{BASE_URL}/api/workspace/notes/{nid}")
        assert r.status_code == 404


# ==================== Files ====================
@pytest.fixture(scope="module")
def uploaded_file(owner, owner_project):
    """Attempt to upload a text file. If storage is unreachable (502/503) yields None."""
    pid = owner_project
    content = b"UNIQFILECONTENTMARKER_alpha bravo charlie delta echo\nsecond line\n"
    files = {"file": (f"TEST_UNIQFN_{uuid.uuid4().hex[:6]}.txt", content, "text/plain")}
    r = owner.post(f"{BASE_URL}/api/workspace/projects/{pid}/files", files=files, timeout=60)
    return {"resp": r, "content": content, "pid": pid}


def test_file_upload(owner, uploaded_file):
    r = uploaded_file["resp"]
    if r.status_code in (502, 503):
        pytest.skip(f"Object storage unreachable ({r.status_code}) — infra issue, not code bug")
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["_id"].startswith("f_")
    assert d["kind"] == "text"
    assert d["extracted_len"] > 0
    assert d["in_context"] is True
    pytest.p2_file_id = d["_id"]
    pytest.p2_file_name = d["name"]


def test_file_list(owner, owner_project, uploaded_file):
    if uploaded_file["resp"].status_code in (502, 503):
        pytest.skip("Storage unreachable")
    lst = owner.get(f"{BASE_URL}/api/workspace/projects/{owner_project}/files").json()
    assert any(f["_id"] == pytest.p2_file_id for f in lst)


def test_file_download(owner, uploaded_file):
    if uploaded_file["resp"].status_code in (502, 503):
        pytest.skip("Storage unreachable")
    fid = pytest.p2_file_id
    tok = owner._token
    r = requests.get(f"{BASE_URL}/api/workspace/files/{fid}/download?auth={tok}", timeout=60)
    if r.status_code in (502, 503):
        pytest.skip("Storage unreachable on GET")
    assert r.status_code == 200
    assert r.content == uploaded_file["content"]


def test_file_patch(owner, uploaded_file):
    if uploaded_file["resp"].status_code in (502, 503):
        pytest.skip("Storage unreachable")
    fid = pytest.p2_file_id
    r = owner.patch(f"{BASE_URL}/api/workspace/files/{fid}",
                    json={"name": "TEST_renamed.txt"})
    assert r.status_code == 200
    assert r.json()["name"] == "TEST_renamed.txt"

    r = owner.patch(f"{BASE_URL}/api/workspace/files/{fid}",
                    json={"in_context": False})
    assert r.status_code == 200
    assert r.json()["in_context"] is False


def test_file_delete(owner, uploaded_file):
    if uploaded_file["resp"].status_code in (502, 503):
        pytest.skip("Storage unreachable")
    fid = pytest.p2_file_id
    r = owner.delete(f"{BASE_URL}/api/workspace/files/{fid}")
    assert r.status_code == 200
    # second delete → 404
    r = owner.delete(f"{BASE_URL}/api/workspace/files/{fid}")
    assert r.status_code == 404


def test_file_size_cap_constant():
    """Verify the code constant enforces 25MB."""
    from importlib import import_module
    import sys
    sys.path.insert(0, "/app/backend")
    ws = import_module("workspace")
    assert ws.MAX_FILE_BYTES == 25 * 1024 * 1024
    assert ws.MAX_FILES_PER_PROJECT == 50
    assert ws.MAX_EXTRACTED_CHARS == 60_000


# ==================== Global Search ====================
def test_search_empty_query(owner):
    r = owner.get(f"{BASE_URL}/api/workspace/search?q=")
    assert r.status_code == 200
    d = r.json()
    assert d == {"projects": [], "conversations": [], "messages": [], "files": []}
    r = owner.get(f"{BASE_URL}/api/workspace/search?q=x")
    assert r.status_code == 200
    d = r.json()
    assert d["projects"] == [] and d["conversations"] == [] and d["messages"] == [] and d["files"] == []


def test_search_by_project_instructions(owner, owner_project):
    pid = owner_project
    unique = f"ZQXWOMBATMARK{uuid.uuid4().hex[:6]}"
    instr = f"Special marker: {unique}. Whenever user says WOMBAT, reply KANGAROO-ROO."
    r = owner.patch(f"{BASE_URL}/api/workspace/projects/{pid}", json={"instructions": instr})
    assert r.status_code == 200
    s = owner.get(f"{BASE_URL}/api/workspace/search", params={"q": unique}).json()
    assert any(p["_id"] == pid for p in s["projects"]), f"expected project in results, got {s}"


def test_search_by_message(owner, owner_project):
    pid = owner_project
    # Create a conversation and store a message
    cid = "c_" + uuid.uuid4().hex[:9]
    owner.post(f"{BASE_URL}/api/workspace/projects/{pid}/conversations",
               json={"title": "TEST_SearchConv", "id": cid})
    unique = f"NEEDLETOKEN{uuid.uuid4().hex[:6]}"
    mid = "m_" + uuid.uuid4().hex[:9]
    owner.post(f"{BASE_URL}/api/workspace/conversations/{cid}/turn",
               json={"messages": [{"id": mid, "role": "user",
                                   "content": f"Hello please remember the token {unique} for me"}]})
    s = owner.get(f"{BASE_URL}/api/workspace/search", params={"q": unique}).json()
    assert any(m["_id"] == mid for m in s["messages"]), f"expected message hit, got {s}"
    m = next(m for m in s["messages"] if m["_id"] == mid)
    assert "snippet" in m and unique in m["snippet"]


def test_search_by_filename(owner, owner_project):
    """Upload another file and confirm search-by-name works. Skip if storage down."""
    pid = owner_project
    unique = f"ZFNSRCH{uuid.uuid4().hex[:6]}"
    name = f"TEST_{unique}.txt"
    r = owner.post(f"{BASE_URL}/api/workspace/projects/{pid}/files",
                   files={"file": (name, b"hello", "text/plain")}, timeout=60)
    if r.status_code in (502, 503):
        pytest.skip("Storage unreachable")
    assert r.status_code == 200
    s = owner.get(f"{BASE_URL}/api/workspace/search", params={"q": unique}).json()
    assert any(f["name"] == name for f in s["files"]), f"expected file hit, got {s}"


# ==================== Isolation ====================
def test_user_b_cannot_access_owner_notes_files(owner, owner_project, user_b):
    pid = owner_project
    # Create a note as owner
    n = owner.post(f"{BASE_URL}/api/workspace/projects/{pid}/notes",
                   json={"content": "OWNER_PRIVATE_NOTE"}).json()
    nid = n["_id"]

    # user_b cannot patch or delete
    r = user_b.patch(f"{BASE_URL}/api/workspace/notes/{nid}", json={"content": "hack"})
    assert r.status_code == 404
    r = user_b.delete(f"{BASE_URL}/api/workspace/notes/{nid}")
    assert r.status_code == 404

    # user_b listing owner's project → 404 on project itself
    r = user_b.get(f"{BASE_URL}/api/workspace/projects/{pid}/notes")
    assert r.status_code == 404
    r = user_b.get(f"{BASE_URL}/api/workspace/projects/{pid}/files")
    assert r.status_code == 404

    # search from user_b should NOT return owner's private note or project
    s = user_b.get(f"{BASE_URL}/api/workspace/search", params={"q": "OWNER_PRIVATE_NOTE"}).json()
    # notes aren't returned by search endpoint, but ensure no cross-user leaks in projects/messages
    assert all(p["_id"] != pid for p in s["projects"])


# ==================== Regression: Phase 1 still works ====================
def test_phase1_bootstrap_still_works(owner):
    r = owner.post(f"{BASE_URL}/api/workspace/bootstrap")
    assert r.status_code == 200
    assert r.json()["default_project"]["name"] == "General"
