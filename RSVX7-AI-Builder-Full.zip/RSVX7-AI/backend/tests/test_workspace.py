"""Workspace Phase 1 backend tests: projects, conversations, messages, migration, isolation."""
import os, uuid, json
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')
OWNER_USER = "admin-rsvx7"
OWNER_PASS = os.environ.get("TEST_OWNER_PASS", "")


def _login(username, password):
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/auth/login",
               json={"username": username, "password": password, "remember_me": False})
    assert r.status_code == 200, f"login failed: {r.text}"
    tok = r.json().get("token")
    s.headers.update({"Authorization": f"Bearer {tok}"})
    return s


@pytest.fixture(scope="module")
def owner():
    return _login(OWNER_USER, OWNER_PASS)


@pytest.fixture(scope="module")
def user_b():
    # register a fresh second user for isolation tests
    uname = f"testws{uuid.uuid4().hex[:8]}"
    pwd = "TestPass123!"
    r = requests.post(f"{BASE_URL}/api/auth/register",
                      json={"username": uname, "password": pwd})
    assert r.status_code == 200, r.text
    s = _login(uname, pwd)
    s._username = uname
    return s


# ---------- Auth Guard ----------
def test_projects_requires_auth():
    r = requests.get(f"{BASE_URL}/api/workspace/projects")
    assert r.status_code == 401


# ---------- Bootstrap / Default project ----------
def test_bootstrap_idempotent(owner):
    r1 = owner.post(f"{BASE_URL}/api/workspace/bootstrap")
    assert r1.status_code == 200
    d1 = r1.json()
    assert d1["ok"] is True
    p1 = d1["default_project"]
    assert p1["name"] == "General"
    assert p1["_id"].startswith("p_")

    r2 = owner.post(f"{BASE_URL}/api/workspace/bootstrap")
    assert r2.status_code == 200
    assert r2.json()["default_project"]["_id"] == p1["_id"]  # same project, no dupe


# ---------- Projects CRUD ----------
class TestProjects:
    def test_list_active(self, owner):
        r = owner.get(f"{BASE_URL}/api/workspace/projects")
        assert r.status_code == 200
        docs = r.json()
        assert isinstance(docs, list)
        # General present
        assert any(p["name"] == "General" for p in docs)
        # none archived
        assert all(p.get("is_archived") is False for p in docs)

    def test_create_project(self, owner):
        body = {"name": "TEST_ProjA", "description": "d", "icon": "Sparkles",
                "color": "#8B1D3F", "is_favorite": True}
        r = owner.post(f"{BASE_URL}/api/workspace/projects", json=body)
        assert r.status_code == 200
        p = r.json()
        assert p["_id"].startswith("p_")
        assert p["name"] == "TEST_ProjA"
        assert p["is_favorite"] is True
        assert p["is_archived"] is False
        pytest.proj_id = p["_id"]

        # verify via GET single
        g = owner.get(f"{BASE_URL}/api/workspace/projects/{p['_id']}")
        assert g.status_code == 200 and g.json()["name"] == "TEST_ProjA"

    def test_update_project(self, owner):
        pid = pytest.proj_id
        r = owner.patch(f"{BASE_URL}/api/workspace/projects/{pid}",
                        json={"name": "TEST_ProjA_Renamed", "touch_opened": True})
        assert r.status_code == 200
        assert r.json()["name"] == "TEST_ProjA_Renamed"

    def test_archived_filter(self, owner):
        pid = pytest.proj_id
        # archive it
        owner.patch(f"{BASE_URL}/api/workspace/projects/{pid}", json={"is_archived": True})
        act = owner.get(f"{BASE_URL}/api/workspace/projects").json()
        arc = owner.get(f"{BASE_URL}/api/workspace/projects?archived=true").json()
        assert all(p["_id"] != pid for p in act)
        assert any(p["_id"] == pid for p in arc)
        # unarchive
        owner.patch(f"{BASE_URL}/api/workspace/projects/{pid}", json={"is_archived": False})


# ---------- Conversations + Turn ----------
class TestConversations:
    def test_create_and_list(self, owner):
        pid = pytest.proj_id
        cid = "c_" + uuid.uuid4().hex[:9]
        r = owner.post(f"{BASE_URL}/api/workspace/projects/{pid}/conversations",
                       json={"title": "TEST_Chat1", "id": cid, "model_id": "deepseek-chat"})
        assert r.status_code == 200
        d = r.json()
        assert d["_id"] == cid
        assert d["project_id"] == pid
        pytest.conv_id = cid

        lst = owner.get(f"{BASE_URL}/api/workspace/projects/{pid}/conversations")
        assert lst.status_code == 200
        assert any(c["_id"] == cid for c in lst.json())

    def test_turn_persistence_and_idempotency(self, owner):
        cid = pytest.conv_id
        m1_id = "m_" + uuid.uuid4().hex[:9]
        m2_id = "m_" + uuid.uuid4().hex[:9]
        payload = {
            "messages": [
                {"id": m1_id, "role": "user", "content": "hello"},
                {"id": m2_id, "role": "assistant", "content": "hi there"},
            ],
            "title": "TEST_Chat_Renamed",
        }
        r = owner.post(f"{BASE_URL}/api/workspace/conversations/{cid}/turn", json=payload)
        assert r.status_code == 200
        assert r.json()["message_count"] == 2

        # GET conversation should return both messages, sorted by order_index
        g = owner.get(f"{BASE_URL}/api/workspace/conversations/{cid}")
        assert g.status_code == 200
        gd = g.json()
        assert gd["title"] == "TEST_Chat_Renamed"
        msgs = gd["messages"]
        assert len(msgs) == 2
        assert msgs[0]["role"] == "user"
        assert msgs[1]["role"] == "assistant"
        assert msgs[0]["order_index"] < msgs[1]["order_index"]

        # Retry same turn — must NOT duplicate
        r2 = owner.post(f"{BASE_URL}/api/workspace/conversations/{cid}/turn", json=payload)
        assert r2.status_code == 200
        assert r2.json()["message_count"] == 2

    def test_update_conversation(self, owner):
        cid = pytest.conv_id
        r = owner.patch(f"{BASE_URL}/api/workspace/conversations/{cid}",
                        json={"is_pinned": True, "hidden_context": {"a": 1}})
        assert r.status_code == 200
        d = r.json()
        assert d["is_pinned"] is True
        assert d["hidden_context"] == {"a": 1}


# ---------- Migration idempotency ----------
def test_migrate_idempotent(owner):
    chat_id = "c_mig" + uuid.uuid4().hex[:6]
    m_id = "m_mig" + uuid.uuid4().hex[:6]
    payload = {"chats": [{
        "id": chat_id,
        "title": "TEST_MigChat",
        "messages": [{"id": m_id, "role": "user", "content": "old msg"}],
    }]}
    r1 = owner.post(f"{BASE_URL}/api/workspace/migrate", json=payload)
    assert r1.status_code == 200
    assert r1.json()["conversations_imported"] == 1

    # Re-migrate: should NOT dupe
    r2 = owner.post(f"{BASE_URL}/api/workspace/migrate", json=payload)
    assert r2.status_code == 200
    assert r2.json()["conversations_imported"] == 0

    # Verify persisted
    g = owner.get(f"{BASE_URL}/api/workspace/conversations/{chat_id}")
    assert g.status_code == 200
    assert g.json()["title"] == "TEST_MigChat"


# ---------- Isolation ----------
def test_user_isolation(owner, user_b):
    # user_b bootstraps
    b_boot = user_b.post(f"{BASE_URL}/api/workspace/bootstrap").json()
    b_pid = b_boot["default_project"]["_id"]

    # user_b's project list should NOT contain owner's TEST_ProjA_Renamed
    b_list = user_b.get(f"{BASE_URL}/api/workspace/projects").json()
    assert not any("TEST_ProjA" in p["name"] for p in b_list)
    assert any(p["_id"] == b_pid for p in b_list)

    # Owner's conv id is invisible to user_b
    o_cid = pytest.conv_id
    r = user_b.get(f"{BASE_URL}/api/workspace/conversations/{o_cid}")
    assert r.status_code == 404

    r = user_b.patch(f"{BASE_URL}/api/workspace/conversations/{o_cid}", json={"title": "hack"})
    assert r.status_code == 404

    r = user_b.delete(f"{BASE_URL}/api/workspace/conversations/{o_cid}")
    assert r.status_code == 404

    # Owner's project id is invisible to user_b
    o_pid = pytest.proj_id
    r = user_b.get(f"{BASE_URL}/api/workspace/projects/{o_pid}")
    assert r.status_code == 404
    r = user_b.delete(f"{BASE_URL}/api/workspace/projects/{o_pid}")
    assert r.status_code == 404


# ---------- Cascade delete ----------
def test_delete_conversation_and_project(owner):
    pid = pytest.proj_id
    cid = pytest.conv_id

    # delete conversation → messages removed
    r = owner.delete(f"{BASE_URL}/api/workspace/conversations/{cid}")
    assert r.status_code == 200
    r = owner.get(f"{BASE_URL}/api/workspace/conversations/{cid}")
    assert r.status_code == 404

    # create another convo + turn, then delete the project → cascade
    cid2 = "c_" + uuid.uuid4().hex[:9]
    owner.post(f"{BASE_URL}/api/workspace/projects/{pid}/conversations",
               json={"title": "TEST_Cascade", "id": cid2})
    owner.post(f"{BASE_URL}/api/workspace/conversations/{cid2}/turn",
               json={"messages": [{"id": "m_"+uuid.uuid4().hex[:6], "role": "user", "content": "x"}]})

    r = owner.delete(f"{BASE_URL}/api/workspace/projects/{pid}")
    assert r.status_code == 200
    assert r.json().get("ok") is True

    # convo now gone
    r = owner.get(f"{BASE_URL}/api/workspace/conversations/{cid2}")
    assert r.status_code == 404


# ---------- Chat streaming still works ----------
def test_chat_stream_still_works(owner):
    with owner.post(f"{BASE_URL}/api/chat/stream",
                    json={"messages": [{"role": "user", "content": "Say 'ok'"}]},
                    stream=True, timeout=60) as r:
        assert r.status_code == 200
        got_data = False
        for raw in r.iter_lines(decode_unicode=True):
            if raw and raw.startswith("data: "):
                got_data = True
                if "[DONE]" in raw:
                    break
        assert got_data
