"""Verify: 24h trial, 5k initial balance, 1.5x billing multiplier, admin token endpoints."""
import os, secrets, time
from datetime import datetime, timezone, timedelta
import pytest, requests
from dotenv import load_dotenv
from pathlib import Path
load_dotenv(Path("/app/frontend/.env"))

BASE = os.environ["REACT_APP_BACKEND_URL"].rstrip("/")
ADMIN_U = os.environ.get("TEST_OWNER_USER", "admin-rsvx7")
ADMIN_P = os.environ.get("TEST_OWNER_PASS", "")


@pytest.fixture(scope="module")
def admin_sess():
    s = requests.Session()
    r = s.post(f"{BASE}/api/auth/login", json={"username": ADMIN_U, "password": ADMIN_P})
    assert r.status_code == 200, r.text
    return s


@pytest.fixture(scope="module")
def new_user():
    uname = "test_" + secrets.token_hex(4)
    s = requests.Session()
    r = s.post(f"{BASE}/api/auth/register", json={"username": uname, "password": "Passw0rd!"})
    assert r.status_code == 200, r.text
    data = r.json()
    return {"sess": s, "username": uname, "id": data["id"], "trial_expires_at": data["trial_expires_at"]}


def test_register_trial_is_24h(new_user):
    exp = datetime.fromisoformat(new_user["trial_expires_at"])
    delta = exp - datetime.now(timezone.utc)
    # Should be between 23h and 25h from now
    assert timedelta(hours=23) < delta < timedelta(hours=25), f"Expected ~24h, got {delta}"


def test_me_shows_5000_balance(new_user):
    r = new_user["sess"].get(f"{BASE}/api/auth/me")
    assert r.status_code == 200
    data = r.json()
    assert data["token_balance"] == 5000, f"expected 5000, got {data['token_balance']}"
    assert data["plan"] == "trial"


def test_billing_balance_endpoint(new_user):
    r = new_user["sess"].get(f"{BASE}/api/billing/balance")
    assert r.status_code == 200
    data = r.json()
    assert data["token_balance"] == 5000
    assert data["unlimited"] is False


def test_admin_add_tokens(admin_sess, new_user):
    r = admin_sess.post(f"{BASE}/api/admin/tokens/add",
                        json={"user_id": new_user["id"], "amount": 1000, "reason": "test_add"})
    assert r.status_code == 200, r.text
    assert r.json()["balance"] == 6000
    # Verify via GET
    r2 = new_user["sess"].get(f"{BASE}/api/billing/balance")
    assert r2.json()["token_balance"] == 6000


def test_admin_deduct_tokens(admin_sess, new_user):
    r = admin_sess.post(f"{BASE}/api/admin/tokens/deduct",
                        json={"user_id": new_user["id"], "amount": 2000, "reason": "test_deduct"})
    assert r.status_code == 200
    assert r.json()["balance"] == 4000


def test_admin_deduct_clamps_at_zero(admin_sess, new_user):
    r = admin_sess.post(f"{BASE}/api/admin/tokens/deduct",
                        json={"user_id": new_user["id"], "amount": 100000000, "reason": "clamp"})
    assert r.status_code == 200
    assert r.json()["balance"] == 0


def test_admin_set_tokens(admin_sess, new_user):
    r = admin_sess.post(f"{BASE}/api/admin/tokens/set",
                        json={"user_id": new_user["id"], "balance": 12345})
    assert r.status_code == 200
    r2 = new_user["sess"].get(f"{BASE}/api/billing/balance")
    assert r2.json()["token_balance"] == 12345


def test_admin_freeze_unfreeze(admin_sess, new_user):
    r = admin_sess.post(f"{BASE}/api/admin/tokens/freeze", json={"user_id": new_user["id"]})
    assert r.status_code == 200
    r2 = new_user["sess"].get(f"{BASE}/api/billing/balance")
    assert r2.json()["token_balance"] == 0
    r3 = admin_sess.post(f"{BASE}/api/admin/tokens/unfreeze", json={"user_id": new_user["id"]})
    assert r3.status_code == 200
    assert r3.json()["restored"] == 12345
    r4 = new_user["sess"].get(f"{BASE}/api/billing/balance")
    assert r4.json()["token_balance"] == 12345


def test_admin_reset_tokens(admin_sess, new_user):
    r = admin_sess.post(f"{BASE}/api/admin/tokens/reset",
                        json={"user_id": new_user["id"], "balance": 0})
    assert r.status_code == 200
    r2 = new_user["sess"].get(f"{BASE}/api/billing/balance")
    assert r2.json()["token_balance"] == 0


def test_billing_multiplier_15x():
    """Verify charge_user applies BILLING_MULTIPLIER=1.5 directly via the module."""
    import asyncio, sys
    sys.path.insert(0, "/app/backend")
    from tokens import charge_user, db
    import secrets as _s

    async def run():
        uid = "test_mul_" + _s.token_hex(6)
        await db.users.insert_one({
            "_id": uid, "username": uid, "role": "user", "status": "active",
            "token_balance": 10000, "total_used_tokens": 0,
            "total_input_tokens": 0, "total_output_tokens": 0,
        })
        try:
            # raw billable: prompt(100) - cached(0) + completion(200) = 300 → *1.5 = 450
            doc = await charge_user(uid, prompt_tokens=100, completion_tokens=200, cached_tokens=0)
            assert doc["billable_tokens"] == 450, f"expected 450, got {doc['billable_tokens']}"
            u = await db.users.find_one({"_id": uid})
            assert u["token_balance"] == 10000 - 450
            assert u["total_used_tokens"] == 450
        finally:
            await db.users.delete_one({"_id": uid})
            await db.token_usage_history.delete_many({"user_id": uid})

    asyncio.run(run())
