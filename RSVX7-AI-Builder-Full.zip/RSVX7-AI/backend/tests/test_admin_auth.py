"""Backend tests for rebuilt Admin auth (iteration 4)."""
import os
import json
import uuid
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')
OWNER_USER = "admin-rsvx7"
OWNER_PASS = os.environ.get("TEST_OWNER_PASS", "")
LEGACY_USER = "admin"
LEGACY_PASS = os.environ.get("TEST_LEGACY_PASS", "")


def _login(username, password):
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/auth/login",
               json={"username": username, "password": password, "remember_me": False})
    return s, r


@pytest.fixture(scope="module")
def owner_session():
    s, r = _login(OWNER_USER, OWNER_PASS)
    assert r.status_code == 200, f"owner login failed: {r.status_code} {r.text}"
    tok = r.json().get("token")
    s.headers.update({"Authorization": f"Bearer {tok}"})
    s.login_json = r.json()
    return s


@pytest.fixture(scope="module")
def legacy_session():
    s, r = _login(LEGACY_USER, LEGACY_PASS)
    assert r.status_code == 200, f"legacy admin login failed: {r.status_code} {r.text}"
    tok = r.json().get("token")
    s.headers.update({"Authorization": f"Bearer {tok}"})
    s.login_json = r.json()
    return s


class TestOwnerLogin:
    def test_owner_login_returns_super_admin_and_is_owner(self, owner_session):
        s, r = _login(OWNER_USER, OWNER_PASS)
        assert r.status_code == 200
        data = r.json()
        assert "token" in data
        # Login response is flat
        assert data.get("username") == OWNER_USER
        assert data.get("role") == "super_admin"
        # is_owner + permissions confirmed via /api/auth/me
        me = owner_session.get(f"{BASE_URL}/api/auth/me").json()
        assert me.get("is_owner") is True
        perms = me.get("permissions") or []
        assert len(perms) == 12, f"expected 12 perms, got {len(perms)}: {perms}"

    def test_owner_auth_me(self, owner_session):
        r = owner_session.get(f"{BASE_URL}/api/auth/me")
        assert r.status_code == 200
        d = r.json()
        assert d.get("username") == OWNER_USER
        assert d.get("role") == "super_admin"
        assert d.get("is_owner") is True
        assert d.get("status") == "active"

    def test_legacy_admin_still_logs_in_not_owner(self, legacy_session):
        s, r = _login(LEGACY_USER, LEGACY_PASS)
        assert r.status_code == 200
        data = r.json()
        assert data.get("role") == "super_admin"
        # is_owner is flat False (or absent) — verify via /api/auth/me
        me = legacy_session.get(f"{BASE_URL}/api/auth/me").json()
        assert me.get("is_owner") is not True, f"legacy admin must NOT be owner: {me}"


class TestAdminEndpoints:
    def test_stats(self, owner_session):
        r = owner_session.get(f"{BASE_URL}/api/admin/stats")
        assert r.status_code == 200

    def test_users(self, owner_session):
        r = owner_session.get(f"{BASE_URL}/api/admin/users")
        assert r.status_code == 200
        assert isinstance(r.json(), (list, dict))

    def test_permissions_list(self, owner_session):
        r = owner_session.get(f"{BASE_URL}/api/admin/permissions")
        assert r.status_code == 200
        body = r.json()
        perms = body if isinstance(body, list) else body.get("permissions") or body.get("items") or []
        # Extract keys/names
        keys = set()
        for p in perms:
            if isinstance(p, dict):
                k = p.get("key") or p.get("name") or p.get("id")
                if k:
                    keys.add(k)
            else:
                keys.add(str(p))
        expected = {"dashboard", "users", "ai_chat", "ai_models", "payments",
                    "subscriptions", "coupons", "telegram", "website_admins",
                    "settings", "analytics", "logs"}
        assert expected.issubset(keys), f"missing perms. got={keys}"
        assert "telegram_groups" not in keys
        assert "bot_admins" not in keys
        assert len(keys) == 12, f"expected exactly 12 permission keys, got {len(keys)}: {keys}"

    def test_website_admins(self, owner_session):
        r = owner_session.get(f"{BASE_URL}/api/admin/website-admins")
        assert r.status_code == 200
        arr = r.json()
        if isinstance(arr, dict):
            arr = arr.get("items") or arr.get("admins") or []
        usernames = {a.get("username") for a in arr if isinstance(a, dict)}
        assert OWNER_USER in usernames
        assert LEGACY_USER in usernames

    def test_settings(self, owner_session):
        r = owner_session.get(f"{BASE_URL}/api/admin/settings")
        assert r.status_code == 200

    def test_coupons(self, owner_session):
        r = owner_session.get(f"{BASE_URL}/api/admin/coupons")
        assert r.status_code == 200
        body = r.json()
        assert isinstance(body, (list, dict))


class TestRemovedTelegramEndpoints:
    """These must return 404 (removed)."""
    @pytest.mark.parametrize("path,method", [
        ("/api/telegram/membership-status", "GET"),
        ("/api/telegram/refresh-membership", "POST"),
        ("/api/admin/tg-groups", "GET"),
        ("/api/admin/bot-admins", "GET"),
    ])
    def test_endpoint_removed(self, owner_session, path, method):
        r = owner_session.request(method, f"{BASE_URL}{path}")
        assert r.status_code == 404, f"{method} {path} → {r.status_code} (expected 404)"


class TestChatStream:
    def test_owner_can_stream(self, owner_session):
        with owner_session.post(f"{BASE_URL}/api/chat/stream",
                                json={"messages": [{"role": "user", "content": "Say 'ok'."}]},
                                stream=True, timeout=60) as r:
            assert r.status_code == 200
            got_any = False
            for raw in r.iter_lines(decode_unicode=True):
                if not raw:
                    continue
                if raw.startswith("data: "):
                    data = raw[6:]
                    if data == "[DONE]":
                        break
                    got_any = True
            assert got_any, "no stream data received"


class TestOwnerProtection:
    def _find_owner_id(self, sess):
        r = sess.get(f"{BASE_URL}/api/admin/users")
        assert r.status_code == 200
        arr = r.json()
        if isinstance(arr, dict):
            arr = arr.get("items") or arr.get("users") or []
        for u in arr:
            if u.get("username") == OWNER_USER:
                return u.get("id") or u.get("_id") or u.get("user_id")
        # Fallback: from website-admins
        r = sess.get(f"{BASE_URL}/api/admin/website-admins")
        arr = r.json()
        if isinstance(arr, dict):
            arr = arr.get("items") or []
        for u in arr:
            if u.get("username") == OWNER_USER:
                return u.get("id") or u.get("_id")
        return None

    def test_owner_cannot_be_suspended(self, owner_session):
        oid = self._find_owner_id(owner_session)
        assert oid, "owner id not found"
        r = owner_session.post(f"{BASE_URL}/api/admin/users/{oid}/status",
                               json={"status": "suspended"})
        assert r.status_code == 403, f"expected 403, got {r.status_code}: {r.text[:200]}"

    def test_owner_cannot_be_deleted(self, owner_session):
        oid = self._find_owner_id(owner_session)
        assert oid, "owner id not found"
        r = owner_session.delete(f"{BASE_URL}/api/admin/users/{oid}")
        assert r.status_code == 403, f"expected 403, got {r.status_code}: {r.text[:200]}"


class TestRegularUser:
    def test_register_fresh_user(self):
        uname = f"TESTuser_{uuid.uuid4().hex[:8]}"
        r = requests.post(f"{BASE_URL}/api/auth/register",
                          json={"username": uname, "password": "TestPass1!"})
        assert r.status_code in (200, 201), f"register failed: {r.status_code} {r.text[:300]}"
        # try login
        s, lr = _login(uname, "TestPass1!")
        assert lr.status_code == 200
