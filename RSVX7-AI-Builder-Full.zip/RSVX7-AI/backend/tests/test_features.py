"""Backend tests for personality, settings, public settings features."""
import os
import json
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')
ADMIN_USER = "admin"
ADMIN_PASS = os.environ.get("TEST_ADMIN_PASS", "")

FORBIDDEN = ["deepseek", "gpt-4", "gpt-5", "claude", "anthropic", "openai"]


@pytest.fixture(scope="module")
def admin_session():
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/auth/login",
               json={"username": ADMIN_USER, "password": ADMIN_PASS, "remember_me": False})
    assert r.status_code == 200, f"admin login failed: {r.text}"
    tok = r.json().get("token")
    s.headers.update({"Authorization": f"Bearer {tok}"})
    return s


def _stream_collect(session, payload):
    """POST /api/chat/stream and collect concatenated text."""
    with session.post(f"{BASE_URL}/api/chat/stream", json=payload, stream=True, timeout=60) as r:
        assert r.status_code == 200, f"status={r.status_code} body={r.text[:400]}"
        text = ""
        for raw in r.iter_lines(decode_unicode=True):
            if not raw:
                continue
            if raw.startswith("data: "):
                data = raw[6:]
                if data == "[DONE]":
                    break
                try:
                    obj = json.loads(data)
                except Exception:
                    continue
                if "t" in obj:
                    text += obj["t"]
                elif "error" in obj:
                    pytest.fail(f"stream error: {obj['error']}")
        return text


def _assert_no_forbidden(text: str):
    low = text.lower()
    for kw in FORBIDDEN:
        assert kw not in low, f"Response mentions forbidden provider '{kw}': {text[:400]}"


# ---------- Personality tests ----------

class TestPersonalities:
    def test_kaligpt(self, admin_session):
        text = _stream_collect(admin_session, {
            "personality": "kaligpt",
            "messages": [{"role": "user", "content": "Who are you? Reply in one short sentence."}],
        })
        assert "kaligpt" in text.lower(), f"missing KaliGPT: {text}"
        _assert_no_forbidden(text)

    def test_deepdark_arabic(self, admin_session):
        text = _stream_collect(admin_session, {
            "personality": "deepdark",
            "messages": [{"role": "user", "content": "من أنت؟ جواب قصير"}],
        })
        assert "deepdark" in text.lower(), f"missing DeepDark: {text}"
        _assert_no_forbidden(text)

    def test_rsvx7(self, admin_session):
        text = _stream_collect(admin_session, {
            "personality": "rsvx7-ai",
            "messages": [{"role": "user", "content": "من أنت؟ جواب قصير"}],
        })
        assert "rsvx7" in text.lower(), f"missing RSVX7-AI: {text}"
        _assert_no_forbidden(text)

    def test_default_no_personality(self, admin_session):
        text = _stream_collect(admin_session, {
            "messages": [{"role": "user", "content": "Say 'ok' only."}],
        })
        assert len(text) > 0

    def test_invalid_personality_falls_back(self, admin_session):
        text = _stream_collect(admin_session, {
            "personality": "invalid-model",
            "messages": [{"role": "user", "content": "Say 'ok' only."}],
        })
        assert len(text) > 0


# ---------- Settings tests ----------

class TestSettings:
    def test_admin_set_and_get_telegram_link(self, admin_session):
        r = admin_session.post(f"{BASE_URL}/api/admin/settings",
                               json={"telegram_link": "https://t.me/test_channel"})
        assert r.status_code == 200
        assert r.json().get("ok") is True

        r = admin_session.get(f"{BASE_URL}/api/admin/settings")
        assert r.status_code == 200
        data = r.json()
        assert data.get("telegram_link") == "https://t.me/test_channel"
        assert "telegram_bot_token" in data
        assert "telegram_chat_id" in data

    def test_public_settings_no_auth(self, admin_session):
        # Ensure link is set
        admin_session.post(f"{BASE_URL}/api/admin/settings",
                           json={"telegram_link": "https://t.me/test_channel"})
        # Fresh session, no auth
        r = requests.get(f"{BASE_URL}/api/settings/public")
        assert r.status_code == 200
        data = r.json()
        assert data.get("telegram_link") == "https://t.me/test_channel"
        # Must not leak
        assert "telegram_bot_token" not in data
        assert "telegram_chat_id" not in data

    def test_settings_persistence_update(self, admin_session):
        admin_session.post(f"{BASE_URL}/api/admin/settings",
                           json={"telegram_link": "https://t.me/another_channel_xyz"})
        r = requests.get(f"{BASE_URL}/api/settings/public")
        assert r.status_code == 200
        assert r.json().get("telegram_link") == "https://t.me/another_channel_xyz"
        # Restore for frontend tests
        admin_session.post(f"{BASE_URL}/api/admin/settings",
                           json={"telegram_link": "https://t.me/test_channel"})
