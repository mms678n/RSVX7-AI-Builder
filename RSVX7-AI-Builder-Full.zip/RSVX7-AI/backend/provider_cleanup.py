"""Bounded provider shutdown; a stuck socket must not retain a generation lease."""
import anyio


async def close_provider_stream(stream, timeout=5):
    if stream is None:
        return
    with anyio.move_on_after(timeout, shield=True):
        try:
            await stream.close()
        except Exception:
            # Closing is best effort; callers still release their own lease.
            pass
