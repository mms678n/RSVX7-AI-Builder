"""RSVX7 Builder: existing account, administrator's model and existing token wallet.

The private Node service reuses the DarkForge agent engine. It receives no API
key or database credentials. Browser verification never runs generated code in
the application server process.
"""
import asyncio
import hashlib
import hmac
import json
import os
import re
import uuid
from datetime import datetime, timezone, timedelta

import anyio
import httpx
import jwt
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, ConfigDict

from auth import current_user, db, JWT_SECRET
from workspace import _get_project, project_memory_prompt
from ai_settings import current_settings, claim_generation, release_generation, provider_error, MODEL_FIELDS
from tokens import check_can_afford, charge_user, estimate_messages_tokens, max_completion_for_balance
from tg_verify import require_membership

router = APIRouter(prefix='/api/builder', tags=['Builder'])
_tasks: dict[str, asyncio.Task] = {}
CHECKS = ['files', 'dependencies', 'types', 'lint', 'tests', 'build', 'preview']
AGENTS = ['architect', 'designer', 'coder', 'reviewer']
ENGINE_URL = 'http://127.0.0.1:' + os.environ.get('BUILDER_ENGINE_PORT', '3001')

def _now(): return datetime.now(timezone.utc).isoformat()
def engine_secret(): return hmac.new(JWT_SECRET.encode(), b'rsvx7-builder-engine-v1', hashlib.sha256).hexdigest()
def _empty(): return {'revision': 0, 'files': {}, 'messages': [], 'phase': 'planning', 'job': None, 'darkMode': True, 'checks': []}
def _state(project): return {**_empty(), **(project.get('builder') or {})}
def _cas(uid, pid, revision, job=None):
    query = {'_id': pid, 'user_id': uid}
    query['$or'] = [{'builder.revision': revision}] + ([{'builder': {'$exists': False}}] if revision == 0 else [])
    if job is not None: query.update({'builder.job.id': job, 'builder.job.status': 'running'})
    return query

def validate_files(files):
    if not isinstance(files, dict) or len(files) > 1500: raise HTTPException(400, 'ملفات المشروع غير صالحة.')
    result, size = {}, 0
    for raw, file in files.items():
        path = raw.removeprefix('/home/project/')
        if not path or path.startswith('/') or len(path) > 400 or re.search(r'[\\\x00-\x1f"<>:]', path) or any(p in ('', '.', '..', '.git', 'node_modules', '.darkforge', 'dist', 'build') for p in path.split('/')):
            raise HTTPException(400, 'مسار ملف غير صالح.')
        if not isinstance(file, dict) or file.get('type') != 'file' or not isinstance(file.get('content'), str): raise HTTPException(400, 'صيغة ملف غير صالحة.')
        size += len(file['content'].encode('utf-8'))
        if size > 6 * 1024 * 1024: raise HTTPException(413, 'مصدر المشروع أكبر من 6 MB.')
        result['/home/project/' + path] = {'type': 'file', 'content': file['content'], 'isBinary': file.get('isBinary') is True}
    return result

class QuestionAnswer(BaseModel):
    id: str = Field(min_length=1, max_length=80)
    options: list[str] = Field(default_factory=list, max_length=5)
    text: str = Field(default='', max_length=2000)

class RunBody(BaseModel):
    model_config = ConfigDict(extra='ignore')
    requestId: str = Field(min_length=8, max_length=100, pattern=r'^[a-zA-Z0-9_-]+$')
    revision: int = Field(ge=0)
    action: str = Field(default='message', pattern=r'^(message|answers|retry|approve|discuss|repair)$')
    text: str = Field(default='', max_length=20000)
    proposalId: str | None = Field(default=None, max_length=100)
    questionMessageId: str | None = Field(default=None, max_length=100)
    answers: list[QuestionAnswer] = Field(default_factory=list, max_length=3)
    darkMode: bool = True
    personality: str = Field(default='rsvx7-ai', max_length=50)
    deepThink: bool = False
    autoSuffix: str = Field(default='', max_length=5000)

def question_answer_text(state, body):
    plan = state.get('plan') or {}
    if plan.get('kind') != 'questions' or body.questionMessageId != state.get('proposalId'):
        raise HTTPException(409, 'تغيّرت الأسئلة. حدّث المشروع قبل إرسال الإجابات.')
    questions = plan.get('questions') or []
    answers = {answer.id: answer for answer in body.answers}
    if len(answers) != len(body.answers) or set(answers) != {q['id'] for q in questions}:
        raise HTTPException(400, 'أجب عن كل الأسئلة ثم أرسلها معًا.')
    lines = []
    for question in questions:
        answer = answers[question['id']]
        if len(set(answer.options)) != len(answer.options) or any(option not in question['options'] for option in answer.options):
            raise HTTPException(400, 'أحد الخيارات لا يطابق الأسئلة الحالية.')
        if question.get('multiple') is False and len(answer.options) > 1:
            raise HTTPException(400, 'اختر إجابة واحدة لهذا السؤال.')
        parts = answer.options + ([answer.text.strip()] if answer.text.strip() else [])
        if not parts: raise HTTPException(400, 'أجب عن كل الأسئلة ثم أرسلها معًا.')
        lines.append(question['label'] + ': ' + '، '.join(parts))
    return '\n\n'.join(lines)

class SaveBody(BaseModel):
    revision: int = Field(ge=0)
    files: dict

class CheckBody(BaseModel):
    revision: int = Field(ge=0)
    checks: list[dict] = Field(max_length=7)

async def _save_job(uid, pid, job, patch):
    return await db.projects.update_one({'_id': pid, 'user_id': uid, 'builder.job.id': job, 'builder.job.status': 'running'}, {'$set': {**{'builder.' + k: v for k, v in patch.items()}, 'updated_at': _now()}})

@router.get('/projects/{pid}')
async def get_builder(pid: str, filesRevision: int | None = None, user: dict = Depends(current_user)):
    project = await _get_project(pid, user['_id'])
    state = _state(project)
    job = state.get('job') or {}
    if job.get('status') == 'running' and job.get('id') not in _tasks:
        await _save_job(user['_id'], pid, job['id'], {'job.status': 'failed', 'job.error': 'أُعيد تشغيل الخادم. ملفاتك محفوظة؛ أعد المحاولة.'})
        state['job'] = {**job, 'status': 'failed', 'error': 'أُعيد تشغيل الخادم. ملفاتك محفوظة؛ أعد المحاولة.'}
    if filesRevision == state['revision']: state.pop('files', None)
    state['projectId'] = pid
    settings = await current_settings()
    state['model'] = settings['model']
    state['models'] = settings.get('profile_capabilities', {})
    return state

@router.put('/projects/{pid}/files')
async def save_files(pid: str, body: SaveBody, user: dict = Depends(current_user)):
    state = _state(await _get_project(pid, user['_id']))
    if (state.get('job') or {}).get('status') == 'running': raise HTTPException(409, 'انتظر اكتمال العمل قبل حفظ تعديلاتك.')
    files = validate_files(body.files)
    query = _cas(user['_id'], pid, body.revision)
    query['builder.job.status'] = {'$ne': 'running'}
    result = await db.projects.update_one(query, {'$set': {'builder.files': files, 'builder.revision': body.revision + 1, 'builder.checks': [], 'updated_at': _now()}})
    if not result.modified_count: raise HTTPException(409, 'تغيّرت الملفات في نافذة أخرى. حدّث المشروع أولًا.')
    return {'revision': body.revision + 1}

@router.post('/projects/{pid}/checks')
async def save_checks(pid: str, body: CheckBody, user: dict = Depends(current_user)):
    await _get_project(pid, user['_id'])
    if len(body.checks) != 7 or {c.get('id') for c in body.checks} != set(CHECKS): raise HTTPException(400, 'يجب تضمين الفحوص السبعة.')
    checks = []
    for check in body.checks:
        if check.get('status') not in ('pending', 'running', 'passed', 'failed', 'skipped'): raise HTTPException(400, 'حالة فحص غير صالحة.')
        checks.append({'id': check['id'], 'status': check['status'], 'label': str(check.get('label', ''))[:100], 'detail': str(check.get('detail', ''))[:1000]})
    query = _cas(user['_id'], pid, body.revision); query['builder.job.status'] = {'$ne': 'running'}
    result = await db.projects.update_one(query, {'$set': {'builder.checks': checks, 'builder.checkedRevision': body.revision, 'builder.checkedAt': _now()}})
    if not result.modified_count: raise HTTPException(409, 'هذه النتائج تخص نسخة قديمة من المشروع.')
    return {'ok': True, 'passed': all(c['status'] == 'passed' for c in checks)}

@router.post('/projects/{pid}/cancel')
async def cancel(pid: str, user: dict = Depends(current_user)):
    state = _state(await _get_project(pid, user['_id']))
    job = state.get('job') or {}
    if job.get('status') == 'running':
        # Fence writes first. Late Node replies can never replace source after cancellation.
        await _save_job(user['_id'], pid, job['id'], {'job.status': 'cancelled'})
        task = _tasks.get(job['id'])
        if task: task.cancel()
    return {'ok': True}

@router.post('/projects/{pid}/run', status_code=202)
async def start(pid: str, body: RunBody, user: dict = Depends(current_user)):
    await require_membership(user)
    project = await _get_project(pid, user['_id']); state = _state(project)
    if state.get('lastRequestId') == body.requestId: return {'job': state.get('job')}
    if (state.get('job') or {}).get('status') == 'running': raise HTTPException(409, 'يوجد عمل جارٍ لهذا المشروع.')
    if state['revision'] != body.revision: raise HTTPException(409, 'تغيّرت الملفات. حدّث المشروع.')
    retrying = body.action == 'retry'
    if retrying:
        previous = state.get('job') or {}
        if previous.get('status') not in ('failed', 'cancelled') or previous.get('revision', body.revision) != body.revision:
            raise HTTPException(409, 'لا يوجد طلب متوقف لهذه النسخة. أرسل تعديلًا جديدًا.')
        last_user = next((m for m in reversed(state['messages']) if m.get('role') == 'user'), None)
        if not last_user: raise HTTPException(409, 'أرسل طلبك أولًا.')
        saved_request = previous.get('request') or {**body.model_dump(), 'action': 'message', 'text': last_user['content']}
        retry_selection = {key: getattr(body, key) for key in ('personality', 'deepThink') if key in body.model_fields_set}
        body = RunBody(**{**saved_request, **retry_selection, 'requestId': body.requestId, 'revision': body.revision})
    if body.action == 'approve':
        if not state.get('plan') or state['plan'].get('kind') != 'proposal' or body.proposalId != state.get('proposalId'):
            raise HTTPException(409, 'اعتمد التصور المعروض أولًا.')
        approved = state['plan']
    else: approved = state.get('approvedPlan') if body.action != 'discuss' else None
    if body.action == 'repair' and (not approved or not state['files']): raise HTTPException(409, 'لا يوجد مشروع معتمد لإصلاحه.')
    text = body.text.strip()
    if body.action == 'approve': text = 'اعتماد التصور وبدء التنفيذ'
    if body.action == 'answers': text = question_answer_text(state, body)
    if not text: raise HTTPException(400, 'اكتب طلبك أولًا.')
    if body.autoSuffix.strip(): text += '\n\n' + body.autoSuffix.strip()
    settings = await current_settings(body.personality)
    if not settings['key_configured']: raise HTTPException(503, 'خدمة النموذج غير مهيأة؛ اطلب من الإدارة إعداد المفتاح.')
    await check_can_afford(user, 1)
    jid = uuid.uuid4().hex
    history = list(state['messages'])[-28:]
    message = {'id': uuid.uuid4().hex, 'role': 'user', 'content': text}
    if body.action == 'answers':
        message.update(questionMessageId=body.questionMessageId, questionAnswers=[a.model_dump() for a in body.answers])
    if body.action == 'repair': message['annotations'] = [{'type': 'studioRepair', 'attempt': 1}]
    if not retrying: history.append(message)
    job = {'id': jid, 'status': 'running', 'mode': 'build' if approved else 'planning', 'startedAt': _now(), 'agents': [],
           'revision': body.revision, 'request': body.model_dump(exclude={'requestId', 'revision'}),
           'model': settings['model'], 'modelSettings': {key: settings.get(key) for key in MODEL_FIELDS}}
    patch = {**state, 'messages': history, 'job': job, 'lastRequestId': body.requestId, 'darkMode': body.darkMode,
             'approvedPlan': approved, 'phase': 'build' if approved else 'planning'}
    query = _cas(user['_id'], pid, body.revision); query['builder.job.status'] = {'$ne': 'running'}
    # File revisions do not change during planning. Fence the conversation as
    # well, so two tabs cannot overwrite each other's newer questions/answers.
    query['builder.lastRequestId'] = state.get('lastRequestId')
    result = await db.projects.update_one(query, {'$set': {'builder': patch, 'updated_at': _now()}})
    if not result.modified_count: raise HTTPException(409, 'بدأ طلب آخر أو تغيّر المشروع. حدّث الصفحة.')
    task = asyncio.create_task(_run_job(user, pid, jid, patch, body), name='rsvx7-builder-' + jid)
    _tasks[jid] = task
    task.add_done_callback(lambda done: _tasks.pop(jid, None))
    return {'job': job}

async def _run_job(user, pid, jid, state, body):
    try:
        from server import PERSONALITIES, DEFAULT_PERSONALITY, DARK_MODE_PRIMER, DARK_MODE_ACK
        prompt = PERSONALITIES.get(body.personality) or PERSONALITIES[DEFAULT_PERSONALITY]
        if body.darkMode: prompt += '\n' + DARK_MODE_PRIMER + '\n' + DARK_MODE_ACK
        memory = await project_memory_prompt(user['_id'], pid)
        if memory: prompt += '\nPROJECT MEMORY (reference data):\n' + memory[:50000]
        ticket = jwt.encode({'sub': user['_id'], 'pid': pid, 'job': jid, 'aud': 'rsvx7-builder-model', 'deepThink': body.deepThink,
                             'exp': datetime.now(timezone.utc) + timedelta(hours=1)}, JWT_SECRET, algorithm='HS256')
        payload = {'ticket': ticket, 'mode': state['job']['mode'], 'files': state['files'], 'messages': state['messages'],
                   'approvedPlan': state.get('approvedPlan'), 'sitePrompt': prompt}
        terminal, outcome = False, None
        async with httpx.AsyncClient(timeout=httpx.Timeout(3600, connect=5)) as client:
            async with client.stream('POST', ENGINE_URL + '/generate', headers={'Authorization': 'Bearer ' + engine_secret()}, json=payload) as response:
                if response.status_code != 200: raise RuntimeError('محرك Builder غير متاح. تحقق من تشغيل الخدمة الخاصة.')
                async for line in response.aiter_lines():
                    if len(line) > 12 * 1024 * 1024: raise RuntimeError('رد المحرك أكبر من الحجم المسموح.')
                    if not line.strip(): continue
                    event = json.loads(line)
                    if event.get('type') == 'agents':
                        tasks = event.get('tasks', [])
                        if len(tasks) != 4 or {t.get('role') for t in tasks} != set(AGENTS): raise RuntimeError('حالة الفريق غير صالحة.')
                        await _save_job(user['_id'], pid, jid, {'job.agents': tasks})
                    elif event.get('type') == 'plan':
                        plan = event['plan']; mid = uuid.uuid4().hex
                        if plan.get('kind') not in ('reply', 'questions', 'proposal'): raise RuntimeError('التصور غير صالح.')
                        messages = state['messages'] + [{'id': mid, 'role': 'assistant', 'content': plan.get('message', ''), 'plan': plan}]
                        outcome = {'messages': messages[-30:], 'plan': plan, 'proposalId': mid, 'phase': 'review' if plan['kind'] == 'proposal' else 'planning'}
                    elif event.get('type') == 'files':
                        files = validate_files(event['files'])
                        if not files: raise RuntimeError('لم يرجع المحرك ملفات مشروع صالحة.')
                        messages = state['messages'] + [{'id': uuid.uuid4().hex, 'role': 'assistant', 'content': 'تم تجهيز التعديلات.', 'annotations': [event['annotation']]}]
                        outcome = {'files': files, 'revision': state['revision'] + 1, 'messages': messages[-30:], 'phase': 'generated', 'checks': []}
                    elif event.get('type') == 'error': raise RuntimeError(str(event.get('message', 'تعذّر إكمال العمل.'))[:1000])
                    elif event.get('type') == 'done': terminal = True
        if not terminal or outcome is None: raise RuntimeError('انقطع رد المحرك قبل اكتماله.')
        await _save_job(user['_id'], pid, jid, {**outcome, 'job.status': 'completed', 'job.finishedAt': _now()})
    except asyncio.CancelledError: raise
    except Exception as error:
        message = str(error) if isinstance(error, RuntimeError) else 'تعذّر الاتصال بمحرك البناء. ملفاتك السابقة محفوظة.'
        await _save_job(user['_id'], pid, jid, {'job.status': 'failed', 'job.error': message[:1000], 'job.finishedAt': _now()})

class ModelBody(BaseModel):
    callId: str = Field(pattern=r'^[a-zA-Z0-9_-]{8,100}$')
    messages: list[dict] = Field(min_length=1, max_length=65)
    jsonMode: bool = False

@router.post('/internal/model')
async def model_call(body: ModelBody, request: Request):
    token = request.headers.get('Authorization', '').removeprefix('Bearer ')
    try: scope = jwt.decode(token, JWT_SECRET, algorithms=['HS256'], audience='rsvx7-builder-model')
    except jwt.InvalidTokenError: raise HTTPException(401, 'Invalid Builder scope')
    uid, pid, jid = scope.get('sub'), scope.get('pid'), scope.get('job')
    if not all(isinstance(v, str) for v in (uid, pid, jid)): raise HTTPException(401, 'Invalid Builder scope')
    project = await db.projects.find_one({'_id': pid, 'user_id': uid, 'builder.job.id': jid, 'builder.job.status': 'running'})
    user = await db.users.find_one({'_id': uid})
    if not project or not user or user.get('status') == 'suspended': raise HTTPException(403, 'Builder scope ended')
    messages = []
    for message in body.messages:
        if message.get('role') not in ('system', 'user', 'assistant') or not isinstance(message.get('content'), str): raise HTTPException(400, 'Invalid model messages')
        messages.append({'role': message['role'], 'content': message['content']})
    if sum(len(m['content']) for m in messages) > 250000: raise HTTPException(413, 'سياق المشروع كبير؛ قلّل المرفقات أو الطلب.')
    from ai_settings import client, request_client, reasoning_capabilities
    job = project.get('builder', {}).get('job', {})
    settings = await current_settings((job.get('request') or {}).get('personality', 'rsvx7-ai'))
    # Keep every agent on the selected model/capabilities for this accepted job.
    # The credential remains server-only and can rotate independently.
    settings.update({key: value for key, value in (job.get('modelSettings') or {}).items() if key in MODEL_FIELDS})
    client = request_client(client)
    if client is None: raise HTTPException(503, 'خدمة النموذج غير مهيأة.')
    prompt_tokens = estimate_messages_tokens(messages)
    cap = min(8192, int(settings['max_completion_tokens']), int(settings['context_length']) - prompt_tokens - 256)
    exempt = user.get('role') in ('super_admin', 'admin', 'moderator', 'support')
    budget_prompt = prompt_tokens if exempt else int(prompt_tokens * 1.15) + 64
    if not exempt: cap = min(cap, max_completion_for_balance(int(user.get('token_balance') or 0), budget_prompt))
    if cap < 1: await check_can_afford(user, budget_prompt + 1); raise HTTPException(413, 'لا توجد مساحة كافية في سياق النموذج.')
    await check_can_afford(user, budget_prompt + cap)
    lease = await claim_generation(uid)
    stream, text, reasoning, total_chars, finish, usage_p, usage_c, cached, seen = None, [], [], 0, None, 0, 0, 0, False
    from server import _reasoning_delta
    try:
        capability = reasoning_capabilities(settings); extra = {}
        model_options = {}
        if body.jsonMode and 'response_format' in (settings.get('supported_parameters') or []):
            model_options['response_format'] = {'type': 'json_object'}
        if capability['supports_reasoning']: extra = {'reasoning': {'enabled': capability['reasoning_mandatory'] or bool(scope.get('deepThink')), 'exclude': False}}
        disconnected = False
        async def watch_disconnect(group):
            nonlocal disconnected
            while True:
                if await request.is_disconnected():
                    disconnected = True
                    group.cancel_scope.cancel()
                    return
                await anyio.sleep(0.3)
        async with anyio.create_task_group() as group:
            group.start_soon(watch_disconnect, group)
            with anyio.fail_after(180):
                stream = await client.chat.completions.create(model=settings['model'], messages=messages, stream=True,
                    max_tokens=cap, stream_options={'include_usage': True}, extra_body=extra or None, **model_options)
                async for chunk in stream:
                    if getattr(chunk, 'error', None): raise RuntimeError('Provider error')
                    usage = getattr(chunk, 'usage', None)
                    if usage is not None:
                        usage_p = int(getattr(usage, 'prompt_tokens', 0) or 0); usage_c = int(getattr(usage, 'completion_tokens', 0) or 0); seen = True
                        cached = int(getattr(getattr(usage, 'prompt_tokens_details', None), 'cached_tokens', 0) or getattr(usage, 'prompt_cache_hit_tokens', 0) or 0)
                    choices = getattr(chunk, 'choices', None) or []
                    if choices:
                        content = getattr(getattr(choices[0], 'delta', None), 'content', None)
                        if isinstance(content, str): text.append(content); total_chars += len(content)
                        reasoning_part = _reasoning_delta(getattr(choices[0], 'delta', None))
                        if reasoning_part: reasoning.append(reasoning_part); total_chars += len(reasoning_part)
                        finish = getattr(choices[0], 'finish_reason', None) or finish
                    if total_chars > 8 * 1024 * 1024: raise RuntimeError('Provider response too large')
            group.cancel_scope.cancel()
        if disconnected: raise HTTPException(499, 'Builder request cancelled')
        if finish in (None, 'error') or not ''.join(text).strip(): raise RuntimeError('Provider returned an incomplete response')
        if not seen: usage_p, usage_c = prompt_tokens, estimate_messages_tokens([{'role': 'assistant', 'content': ''.join(reasoning) + ''.join(text)}])
        await charge_user(uid, prompt_tokens=usage_p, completion_tokens=usage_c, cached_tokens=cached,
            user_input_tokens=max(1, estimate_messages_tokens([messages[-1]]) - 12), model=settings['model'],
            conversation_id='builder:' + pid, role_exempt=exempt, idempotency_key='builder:' + jid + ':' + body.callId)
        return {'text': ''.join(text), 'finishReason': finish}
    except HTTPException: raise
    except Exception as error:
        while isinstance(error, BaseExceptionGroup) and error.exceptions: error = error.exceptions[0]
        raise HTTPException(502, provider_error(error))
    finally:
        with anyio.CancelScope(shield=True):
            from provider_cleanup import close_provider_stream
            try:
                await close_provider_stream(stream)
            finally:
                await release_generation(uid, lease)
