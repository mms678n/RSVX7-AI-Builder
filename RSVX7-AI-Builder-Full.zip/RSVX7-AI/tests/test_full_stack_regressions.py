"""Opt-in end-to-end test: its own process, private port, temporary Mongo database."""
import os
import secrets
import socket
import subprocess
import tempfile
import time
from pathlib import Path

import pytest
import requests
from pymongo import MongoClient

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.skipif(os.environ.get("RUN_E2E") != "1", reason="Separate temporary runtime is opt-in")
def test_real_runtime_auth_workspace_model_and_upload():
    name = "rsvx7ai_test_e2e_" + secrets.token_hex(6)
    password = secrets.token_urlsafe(20)
    new_password = secrets.token_urlsafe(20)
    env = os.environ.copy()
    env.update(MONGO_URL="mongodb://127.0.0.1:27017", DB_NAME=name,
               JWT_SECRET="short-platform-alias", RSVX7_JWT_SECRET=secrets.token_hex(32),
               RSVX7_RUNTIME_ENV="production", OWNER_USERNAME="e2e_owner",
               OWNER_INITIAL_PASSWORD=password, COOKIE_SECURE="false",
               DEEPSEEK_API_KEY="", EMERGENT_LLM_KEY="",
               FILE_STORAGE_BACKEND="gridfs",
               OPENROUTER_MODEL="nousresearch/hermes-3-llama-3.1-405b")
    live = os.environ.get("RUN_LIVE_AI") == "1"
    if not live:
        env["OPENROUTER_API_KEY"] = ""
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    mongo = MongoClient(env["MONGO_URL"])
    assert name.startswith("rsvx7ai_test_e2e_")
    with tempfile.TemporaryDirectory(prefix="rsvx7ai-e2e-") as temporary:
        env["OWNER_CREDENTIALS_FILE"] = str(Path(temporary) / "credentials.md")
        log_path = Path(temporary) / "server.log"
        with log_path.open("w") as log:
            process = subprocess.Popen([str(ROOT / ".venv/bin/python"), "-m", "uvicorn", "deployment:app", "--host", "127.0.0.1", "--port", str(port)], cwd=ROOT / "backend", env=env, stdout=log, stderr=log)
        try:
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise AssertionError("Temporary server exited before readiness; inspect startup code")
                try:
                    if requests.get(base + "/readyz", timeout=1).status_code == 200:
                        break
                except requests.RequestException:
                    pass
                time.sleep(0.2)
            else:
                raise AssertionError("Temporary test server did not become ready")
            session = requests.Session()
            login = session.post(base + "/api/auth/login", json={"username": "e2e_owner", "password": password}, timeout=10)
            assert login.status_code == 200
            old_token = login.json()["token"]
            session.headers["Authorization"] = "Bearer " + old_token
            assert session.get(base + "/api/auth/me", timeout=5).json()["must_change_password"] is True
            assert session.get(base + "/api/admin/ai-settings", timeout=5).status_code == 403
            rotated = session.post(base + "/api/auth/change-password", json={"old_password": password, "new_password": new_password}, timeout=10)
            assert rotated.status_code == 200
            token = rotated.json().get("token")
            if not token:
                relogin = session.post(base + "/api/auth/login", json={"username": "e2e_owner", "password": new_password}, timeout=10)
                assert relogin.status_code == 200
                token = relogin.json()["token"]
            session.headers["Authorization"] = "Bearer " + token
            assert requests.get(base + "/api/auth/me", headers={"Authorization": "Bearer " + old_token}, timeout=5).status_code == 401
            owner = session.get(base + "/api/auth/me", timeout=5).json()
            assert owner["must_change_password"] is False
            settings = session.get(base + "/api/admin/ai-settings", timeout=5)
            assert settings.status_code == 200
            assert settings.json()["model"] == env["OPENROUTER_MODEL"]
            assert "api_key" not in settings.json()
            saved = session.put(base + "/api/admin/ai-settings", json={"model": env["OPENROUTER_MODEL"]}, timeout=30)
            assert saved.status_code == 200
            assert mongo[name].settings.find_one({"_id": "ai"})["model"] == env["OPENROUTER_MODEL"]
            project = session.post(base + "/api/workspace/projects", json={"name": "Integration project"}, timeout=5)
            assert project.status_code in (200, 201)
            pid = project.json()["_id"]
            note = session.post(base + f"/api/workspace/projects/{pid}/notes", json={"content": "Persistence test"}, timeout=5)
            assert note.status_code in (200, 201)
            assert session.get(base + f"/api/workspace/projects/{pid}/notes", timeout=5).json()
            upload = session.post(base + "/api/files/process", files={"file": ("sample.txt", b"hello file extraction", "text/plain")}, timeout=10)
            assert upload.status_code == 200
            assert upload.json()["text"] == "hello file extraction"
            attachment = session.post(base + f"/api/workspace/projects/{pid}/files", files={"file": ("persistent.txt", b"gridfs attachment", "text/plain")}, timeout=15)
            assert attachment.status_code == 200
            fid = attachment.json()["_id"]
            assert attachment.json()["storage_path"].startswith("gridfs:")
            assert session.get(base + f"/api/workspace/files/{fid}/download", timeout=5).content == b"gridfs attachment"
            assert session.post(base + "/api/chat/stream", json={"messages": [{"role": "system", "content": "client override"}]}, timeout=5).status_code == 422
            guest = requests.Session()
            signup = guest.post(base + "/api/auth/register", json={"username": "e2e_guest", "password": secrets.token_urlsafe(20)}, timeout=10)
            assert signup.status_code == 200
            guest.headers["Authorization"] = "Bearer " + signup.json()["token"]
            assert guest.get(base + "/api/admin/ai-settings", timeout=5).status_code == 403
            assert guest.get(base + f"/api/workspace/projects/{pid}", timeout=5).status_code == 404
            assert guest.get(base + f"/api/workspace/files/{fid}/download", timeout=5).status_code == 404
            # A globally seen Telegram ID alone must never prove ownership.
            mongo[name].tg_seen.insert_one({"_id": 99123456, "username": "another_telegram_user"})
            assert guest.post(base + "/api/auth/telegram/verify-by-id", json={"telegram_id": 99123456}, timeout=5).status_code in (400, 403, 409)
            assert session.get(base + "/api/billing/usage?limit=9999999", timeout=5).status_code == 422
            if live:
                response = session.post(base + "/api/chat/stream", json={"messages": [{"role": "user", "content": "Reply only with OK, no explanation."}], "model": "untrusted/client-override"}, timeout=190)
                assert response.status_code == 200
                assert '"error"' not in response.text
                assert "data: [DONE]" in response.text
                row = mongo[name].token_usage_history.find_one({"model": env["OPENROUTER_MODEL"]})
                assert row and row["assistant_output_tokens"] > 0
                assert mongo[name].ai_request_leases.count_documents({}) == 0
            assert session.delete(base + f"/api/workspace/projects/{pid}", timeout=5).status_code == 200
            assert mongo[name].notes.count_documents({"project_id": pid}) == 0
            assert session.get(base + f"/api/workspace/files/{fid}/download", timeout=5).status_code == 404
        finally:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
            mongo.drop_database(name)
            mongo.close()
