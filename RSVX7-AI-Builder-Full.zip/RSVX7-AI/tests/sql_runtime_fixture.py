"""Isolated subprocess fixture, not an application persistence fallback."""
import os
import sys
from pathlib import Path
from urllib.parse import urlsplit
from fastapi import HTTPException

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
parsed = urlsplit(os.environ.get("DATABASE_URL", ""))
if parsed.hostname not in {"127.0.0.1", "localhost"} or not parsed.path.lstrip("/").startswith("rsvx7_test_"):
    raise RuntimeError("SQL subprocess fixture requires isolated loopback database")
objects = Path(os.environ["SQL_TEST_OBJECT_DIR"]).resolve()
objects.mkdir(exist_ok=True)

from deployment import app
import workspace


async def put(path, data, content_type):
    # All bytes are synthetic test fixtures; workspace encrypts them first.
    name = os.urandom(16).hex()
    (objects / name).write_bytes(data)
    return {"path": "manus:fixture/" + name, "stable_path": "/manus-storage/fixture/" + name}


async def get(path, max_bytes):
    name = path.removeprefix("manus:fixture/")
    if len(name) != 32 or any(char not in "0123456789abcdef" for char in name):
        raise HTTPException(404, "File not found")
    file = objects / name
    if not file.exists():
        raise HTTPException(404, "File not found")
    data = file.read_bytes()
    if len(data) > max_bytes:
        raise HTTPException(413, "Too large")
    return data, "application/octet-stream"


workspace.manus_put_object = put
workspace.manus_get_object = get
