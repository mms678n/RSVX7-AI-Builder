"""Real loopback SSH handshake plus isolated owner, secret and deployment contracts."""
import asyncio
import copy
import io
import json
from pathlib import Path
import sys
import tarfile
from unittest.mock import AsyncMock
from contextlib import AbstractAsyncContextManager
from types import SimpleNamespace
import asyncssh
import httpx
import pytest
from fastapi import HTTPException
from pydantic import ValidationError
from test_builder import MemoryDB
import auth,server,vps
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from init_selfhost import prepare

OWNER={'_id':'owner','role':'super_admin','status':'active','session_version':0}
@pytest.fixture
def db(monkeypatch):
    value=MemoryDB();value.users.rows['owner']=copy.deepcopy(OWNER);value.users.rows['admin']={**OWNER,'_id':'admin','role':'admin','permissions':['settings','servers']}
    for module in (auth,vps):monkeypatch.setattr(module,'db',value)
    vps.TASKS.clear()
    return value

def run(coroutine):return asyncio.run(coroutine)
async def api(path='',method='GET',body=None,uid='owner'):
    headers={'Authorization':'Bearer '+auth.make_token(uid,'super_admin' if uid=='owner' else 'admin')} if uid else {}
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app),base_url='https://fixture.local') as client:return await client.request(method,'/api/admin/vps'+path,json=body,headers=headers)
def config():return {**vps.DEFAULT,'host':'203.0.113.22','fingerprint':'SHA256:'+'A'*43,'siteUrl':'https://builder.example.com','password':'test-only-ssh-secret','providerKey':'test-only-provider-secret'}

def test_only_platform_owner_can_manage_credentials(db):
    assert run(api(uid=None)).status_code==401
    assert run(api(uid='admin')).status_code==403
    assert run(api()).status_code==200

def test_encrypted_write_only_credentials_revision_and_target_changes(db):
    first=run(api(method='PUT',body=config()));assert first.status_code==200,first.text
    stored=db.settings.rows['vps'];assert stored['secrets'] and 'test-only' not in stored['secrets']
    assert 'password' not in first.json() and 'providerKey' not in first.json()
    assert 'test-only-ssh-secret' not in first.text and 'test-only-provider-secret' not in first.text
    assert vps.decrypt(stored)['password']=='test-only-ssh-secret'
    assert run(api(method='PUT',body=config())).status_code==409
    body={**config(),'revision':1,'password':'','providerKey':''}
    assert run(api(method='PUT',body=body)).status_code==200
    assert vps.decrypt(db.settings.rows['vps'])['password']=='test-only-ssh-secret'
    body.update(revision=2,host='198.51.100.12')
    assert run(api(method='PUT',body=body)).status_code==400

def test_no_shell_injection_in_host_path_or_site_origin():
    for patch in ({'host':'host;id'},{'username':'root;id'},{'installPath':'/root/.ssh'},{'siteUrl':'https://name.example/x'},{'siteUrl':'https://user:pw@example.com'},{'siteUrl':'https://127.0.0.1'}):
        with pytest.raises(ValidationError):vps.ConfigBody(**{**config(),**patch})

def test_private_network_and_metadata_addresses_are_rejected(monkeypatch):
    monkeypatch.delenv('RSVX7_VPS_ALLOWED_CIDRS',raising=False)
    for host in ('127.0.0.1','169.254.169.254','10.0.0.1'):
        with pytest.raises(HTTPException):run(vps.address(host,22))

def test_real_ssh_pins_host_key_before_sending_password(monkeypatch):
    monkeypatch.setenv('RSVX7_VPS_ALLOWED_CIDRS','127.0.0.1/32')
    async def scenario():
        key=asyncssh.generate_private_key('ssh-ed25519');auth_attempts=[]
        class SSHServer(asyncssh.SSHServer):
            def begin_auth(self,username):return True
            def password_auth_supported(self):return True
            def validate_password(self,username,password):auth_attempts.append(password);return username=='root' and password=='fixture-password'
        listener=await asyncssh.create_server(SSHServer,'127.0.0.1',0,server_host_keys=[key])
        try:
            scanned=await vps.host_key(vps.HostBody(host='127.0.0.1',port=listener.get_port()),OWNER)
            assert scanned['fingerprint']==key.get_fingerprint('sha256') and not auth_attempts
            body={**config(),'host':'127.0.0.1','port':listener.get_port(),'fingerprint':scanned['fingerprint'],'secrets':vps.encrypt({'password':'fixture-password'})}
            async with await vps.connect(body):pass
            assert auth_attempts==['fixture-password']
            with pytest.raises(asyncssh.HostKeyNotVerifiable):
                async with await vps.connect({**body,'fingerprint':'SHA256:'+'B'*43}):pass
            assert auth_attempts==['fixture-password']
        finally:listener.close();await listener.wait_closed()
    run(scenario())

def test_deployment_requires_current_successful_connection_test(db,monkeypatch):
    run(api(method='PUT',body=config()))
    assert run(api('/deploy','POST',{})).status_code==409
    db.settings.rows['vps']['tested']={'ready':True,'revision':0}
    assert run(api('/deploy','POST',{})).status_code==409
    async def idle(*args):await asyncio.Event().wait()
    monkeypatch.setattr(vps,'deploy_job',idle)
    async def scenario():
        db.settings.rows['vps']['tested']={'ready':True,'revision':1}
        response=await api('/deploy','POST',{});assert response.status_code==202
        assert (await api('/deploy','POST',{})).status_code==409
        task=next(iter(vps.TASKS.values()));task.cancel()
        try:await task
        except asyncio.CancelledError:pass
    run(scenario())

def test_selfhost_environment_preserves_existing_database_credentials(tmp_path):
    target=tmp_path/'private.env'
    assert prepare(target,{'siteUrl':'https://site.example','provider':'local','model':'qwen2.5-coder:7b'})
    original=target.read_bytes();assert b'AI_PROVIDER=local' in original and b'http://ollama:11434/v1' in original
    assert target.stat().st_mode & 0o777==0o600
    assert not prepare(target,{'siteUrl':'http://other.example','provider':'openrouter'})
    assert target.read_bytes()==original
    with pytest.raises(ValueError):prepare(tmp_path/'bad.env',{'siteUrl':'http://x.example','providerKey':'x\nBAD=1'})

def test_deployment_archive_never_contains_env_or_private_files(tmp_path,monkeypatch):
    monkeypatch.setattr(vps,'ROOT',tmp_path)
    for name in ('frontend/build/index.html','builder/dist/service.mjs','deploy/compose.selfhost.yaml','backend/server.py','Dockerfile.selfhost','Dockerfile.selfhost.dockerignore','scripts/init_selfhost.py','scripts/check_selfhost.py','deploy/install-selfhost.sh'):
        p=tmp_path/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('fixture')
    for name in ('backend/.env','backend/private/token.txt','backend/__pycache__/cache.pyc'):
        p=tmp_path/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('secret')
    with tarfile.open(fileobj=io.BytesIO(vps.source_archive()),mode='r:gz') as archive:
        names=archive.getnames();assert 'backend/server.py' in names
        assert not any('.env' in name or 'private' in name or '__pycache__' in name for name in names)

def test_standalone_mode_keeps_username_login_without_telegram(db,monkeypatch):
    monkeypatch.setenv('RSVX7_STANDALONE','true')
    assert run(auth.get_settings_public())['telegram_required'] is False
    monkeypatch.delenv('RSVX7_STANDALONE')
    assert run(auth.get_settings_public())['telegram_required'] is True

def test_local_model_ids_use_the_existing_wallet_provider_contract(monkeypatch):
    import ai_settings
    monkeypatch.setattr(ai_settings,'AI_PROVIDER','local')
    assert ai_settings.ModelSettingsBody(model='qwen2.5-coder:7b').model=='qwen2.5-coder:7b'
    with pytest.raises(ValidationError):ai_settings.ModelSettingsBody(model='model;id')


@pytest.mark.parametrize('public_ready',[True,False])
def test_deploy_checks_public_url_before_success_and_never_puts_keys_in_commands(db,monkeypatch,public_ready):
    run(api(method='PUT',body=config()))
    row=db.settings.rows['vps'];row['job']={'id':'fixture-release','status':'running'}
    commands=[];uploads=[]
    class Context(AbstractAsyncContextManager):
        async def __aexit__(self,*args):pass
    class File(Context):
        async def write(self,data):uploads.append(data)
    class Sftp(Context):
        async def makedirs(self,*args,**kwargs):pass
        async def chmod(self,*args):pass
        def open(self,*args):return File()
    class Process(Context):
        exit_status=0
        @property
        def stdout(self):
            async def lines():
                yield 'private terminal output must not reach UI\n'
                yield 'RSVX7_STAGE:ready\n'
            return lines()
        async def wait_closed(self):pass
    class SSH(Context):
        def start_sftp_client(self):return Sftp()
        def create_process(self,command,**kwargs):commands.append((command,kwargs));return Process()
        async def run(self,command,**kwargs):
            commands.append((command,kwargs))
            if 'urllib.request' in command and not public_ready:raise RuntimeError('fixture public URL failure')
            return SimpleNamespace(stdout='')
    monkeypatch.setattr(vps,'connect',AsyncMock(return_value=SSH()))
    monkeypatch.setattr(vps,'source_archive',lambda:b'trusted-source-fixture')
    run(vps.deploy_job(copy.deepcopy(row),'fixture-release'))
    job=db.settings.rows['vps']['job']
    assert job['status']==('completed' if public_ready else 'failed')
    assert ('url' in job)==public_ready
    assert 'private terminal output' not in json.dumps(job)
    assert uploads==[b'trusted-source-fixture']
    assert all('test-only-provider-secret' not in command and 'test-only-ssh-secret' not in command for command,_ in commands)
    init=next(options for command,options in commands if '--settings-stdin' in command)
    assert json.loads(init['input'])['providerKey']=='test-only-provider-secret'
    assert any('ln -sfn' in command for command,_ in commands)==public_ready


def test_local_launcher_uses_local_profile_preserves_env_and_waits_for_readiness(tmp_path,monkeypatch):
    import start_local
    monkeypatch.setattr(start_local,'ROOT',tmp_path)
    monkeypatch.setattr(start_local.shutil,'which',lambda _: '/fixture/docker')
    commands=[];probes=[]
    def command(args,**kwargs):
        commands.append(args)
        if 'exec' in args and 'app' in args:probes.append(args)
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(start_local.subprocess,'run',command)
    start_local.launch('qwen2.5-coder:7b')
    original=(tmp_path/'private/local.env').read_bytes()
    start_local.launch()
    assert (tmp_path/'private/local.env').read_bytes()==original
    compose=[args for args in commands if '--env-file' in args]
    assert compose and all('--profile' in args and 'local' in args for args in compose)
    assert any(args[-3:]==['ollama','pull','qwen2.5-coder:7b'] for args in compose)
    assert len(probes)==2


def test_changing_deployment_target_discards_old_url_and_health(db):
    run(api(method='PUT',body=config()))
    row=db.settings.rows['vps']
    row['job']={'id':'a'*32,'status':'completed','url':'https://old.example'}
    row['health']={'ready':True}
    response=run(api(method='PUT',body={**config(),'revision':1,'siteUrl':'https://new.example'}))
    assert response.status_code==200
    assert response.json()['job'] is None and response.json()['health'] is None
    assert run(api('/bootstrap-credentials','POST',{})).status_code==409


def test_settings_cannot_change_if_deployment_starts_during_save(db,monkeypatch):
    run(api(method='PUT',body=config()))
    original=db.settings.update_one
    async def racing(query,changes,**kwargs):
        db.settings.rows['vps']['job']={'id':'racing','status':'running'}
        return await original(query,changes,**kwargs)
    monkeypatch.setattr(db.settings,'update_one',racing)
    response=run(api(method='PUT',body={**config(),'revision':1,'siteUrl':'https://new.example'}))
    assert response.status_code==409
    assert db.settings.rows['vps']['siteUrl']==config()['siteUrl']


def test_recheck_runs_in_background_and_retains_the_installed_release(db,monkeypatch):
    run(api(method='PUT',body=config()))
    db.settings.rows['vps']['job']={'id':'a'*32,'status':'failed'}
    db.settings.rows['vps']['tested']={'ready':True,'revision':1}
    captured=[]
    async def inspect(*args):captured.append(args);await asyncio.Event().wait()
    monkeypatch.setattr(vps,'health_job',inspect)
    async def scenario():
        response=await api('/health','POST',{});assert response.status_code==202
        job=response.json()['job'];assert job['releaseId']=='a'*32 and job['id']!='a'*32
        assert (await api('/deploy','POST',{})).status_code==409
        assert (await api('/health','POST',{})).status_code==409
        assert (await api(method='PUT',body={**config(),'revision':1})).status_code==409
        await asyncio.sleep(0)
        assert captured and captured[0][2]=='a'*32
        task=vps.TASKS[job['id']];task.cancel()
        try:await task
        except asyncio.CancelledError:pass
    run(scenario())


@pytest.mark.parametrize('public_ok',[True,False])
def test_recheck_recovers_running_site_without_building_or_exposing_output(db,monkeypatch,public_ok):
    run(api(method='PUT',body=config()))
    row=db.settings.rows['vps'];row['job']={'id':'b'*32,'releaseId':'a'*32,'mode':'health','status':'running'}
    commands=[]
    class SSH(AbstractAsyncContextManager):
        async def __aexit__(self,*args):pass
        async def run(self,command,**kwargs):
            commands.append(command)
            checks=[{'id':name,'code':'configured' if name=='model' else 'ready'} for name in ('release','database','frontend','engine','model','public')]
            if not public_ok:checks[-1]['code']='public_url_unavailable'
            return SimpleNamespace(stdout=json.dumps({'checks':checks,'password':'DO-NOT-RETURN-THIS'}))
    monkeypatch.setattr(vps,'connect',AsyncMock(return_value=SSH()))
    run(vps.health_job(copy.deepcopy(row),'b'*32,'a'*32))
    saved=db.settings.rows['vps']
    assert saved['job']['status']==('completed' if public_ok else 'failed')
    assert saved['health']['ready'] is public_ok
    assert 'DO-NOT-RETURN' not in json.dumps(vps.safe(saved))
    assert not any(' build ' in command or ' up ' in command or 'install-selfhost.sh' in command for command in commands)
    assert any('ln -sfn' in command for command in commands)==public_ok


def test_readonly_probe_checks_actual_http_and_suppresses_private_docker_output(tmp_path,monkeypatch):
    import check_selfhost
    from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
    from threading import Thread
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            self.send_response(200);self.send_header('Content-Type','application/json' if self.path=='/readyz' else 'text/html');self.end_headers()
            self.wfile.write(json.dumps({'status':'ready','release':'a'*32}).encode() if self.path=='/readyz' else b'<html><body>RSVX7</body></html>')
    http=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=Thread(target=http.serve_forever,daemon=True);thread.start()
    env=tmp_path/'private.env';env.write_text('PRIVATE_SECRET=fixture\n')
    manifest=tmp_path/'release/deploy/compose.selfhost.yaml';manifest.parent.mkdir(parents=True);manifest.write_text('fixture')
    def docker(command,**kwargs):
        assert command[:3]==['docker','compose','-p'] and 'exec' in command
        assert 'build' not in command and 'up' not in command and 'restart' not in command
        return SimpleNamespace(returncode=0,stdout=json.dumps({'release':'a'*32,'database':'ready','frontend':'ready','engine':'ready','model':'missing_key','private':'never-expose-me'}))
    monkeypatch.setattr(check_selfhost.subprocess,'run',docker)
    try:
        settings={'envFile':str(env),'release':str(manifest.parents[1]),'siteUrl':f'http://127.0.0.1:{http.server_port}','expectedRelease':'a'*32}
        report=check_selfhost.diagnose(settings)
        assert report['ready'] is True
        assert next(c for c in report['checks'] if c['id']=='public')['status']=='passed'
        assert next(c for c in report['checks'] if c['id']=='model')['code']=='missing_key'
        assert 'never-expose-me' not in json.dumps(report)
        stale=check_selfhost.diagnose({**settings,'expectedRelease':'b'*32})
        assert stale['ready'] is False
        assert next(c for c in stale['checks'] if c['id']=='release')['code']=='release_mismatch'
        assert next(c for c in stale['checks'] if c['id']=='public')['status']=='failed'
    finally:http.shutdown();http.server_close();thread.join(timeout=2)


def test_readiness_identifies_the_running_release_without_disclosing_credentials(monkeypatch):
    import deployment
    monkeypatch.setattr(deployment,'ping_database',AsyncMock())
    monkeypatch.setattr(deployment,'verify_database',AsyncMock())
    monkeypatch.setenv('RSVX7_RELEASE_ID','a'*32)
    monkeypatch.setenv('OPENROUTER_API_KEY','fixture-key-must-stay-private')
    result=run(deployment.ready())
    assert result['release']=='a'*32 and result['status']=='ready'
    assert 'fixture-key' not in json.dumps(result)
    monkeypatch.delenv('RSVX7_RELEASE_ID')
    assert 'release' not in run(deployment.ready())
