"""Small source-contract checks. Behavioral React coverage lives in *.test.jsx."""
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
ADMIN=(ROOT/'frontend/src/pages/Admin.jsx').read_text()
ADMINS=(ROOT/'frontend/src/pages/AdminAdmins.jsx').read_text()
DASHBOARD=(ROOT/'frontend/src/pages/Dashboard.jsx').read_text()
CLIPBOARD=(ROOT/'frontend/src/lib/clipboard.js').read_text()
PRIMITIVES=(ROOT/'frontend/src/components/design/Primitives.jsx').read_text()


def test_admin_keeps_ai_settings_and_gates_all_tabs_by_permission():
    assert 'import AdminAISettings from "@/pages/AdminAISettings"' in ADMIN
    assert 'const can = useCallback' in ADMIN and 'user?.role === "super_admin"' in ADMIN
    for permission in ('users','dashboard','coupons','website_admins','telegram','settings','ai_models'):
        assert f'permission: "{permission}"' in ADMIN
    assert 'can(permission)' in ADMIN
    assert 'value: "ai_models"' in ADMIN and '<AdminAISettings />' in ADMIN
    assert 'data-testid={`tab-${value}`}' in ADMIN
    assert 'const firstAllowedTab = allowedTabs[0] || null' in ADMIN
    for permission in ('users','dashboard','coupons','website_admins','telegram','settings','ai_models'):
        assert f'tab === "{permission}" && can("{permission}")' in ADMIN
    assert 'لا توجد صلاحيات إدارة لهذا الحساب' in ADMIN


def test_admin_loaders_check_http_status_and_always_clear_loading():
    for loader in ('loadUsers','loadStats','loadSettings'):
        body=ADMIN[ADMIN.index(f'const {loader}'):]
        body=body[:body.index('\n  const ',1)] if '\n  const ' in body[1:] else body
        assert 'if (!r.ok)' in body and 'finally' in body and 'setLoadErrors' in body
    for permission in ('users','dashboard','settings'):
        assert f'if (!can("{permission}")) return;' in ADMIN
    assert 'const act = async' in ADMIN
    assert 'catch (e)' in ADMIN[ADMIN.index('const act = async'):ADMIN.index('const onResetPassword')]


def test_admin_token_is_password_only_and_blank_keeps_existing_value():
    offset=ADMIN.index('data-testid="settings-tg-token"')
    assert 'type="password"' in ADMIN[offset-500:offset+150]
    assert 'telegram_bot_token_configured' in ADMIN
    assert 'delete payload.telegram_bot_token' in ADMIN
    assert 'اتركه فارغًا للإبقاء على الحالي' in ADMIN
    assert 'telegram_bot_token: ""' in ADMIN


def test_admin_admins_new_form_starts_with_no_permissions_and_handles_failures():
    assert 'setForm({ ...EMPTY, permissions: [] })' in ADMINS
    assert 'if (!adminsResponse.ok)' in ADMINS and 'if (!permissionsResponse.ok)' in ADMINS
    assert 'const [loading, setLoading] = useState(true)' in ADMINS
    assert 'const [error, setError] = useState("")' in ADMINS
    assert 'finally' in ADMINS and '<StatusNote tone="error"' in ADMINS
    assert '"alert"' in PRIMITIVES and 'role=' in PRIMITIVES


def test_dashboard_password_refreshes_session_and_clears_busy_in_finally():
    body=DASHBOARD[DASHBOARD.index('function ChangePasswordDialog'):DASHBOARD.index('export default function Dashboard')]
    assert 'if (data?.token' in body and 'await activateSession(data.token)' in body
    assert 'try {' in body and 'finally' in body and 'setBusy(false)' in body
    assert 'await copyToClipboard' in DASHBOARD


def test_clipboard_awaits_native_write_and_propagates_rejection():
    assert re.search(r'export async function copyToClipboard',CLIPBOARD)
    assert 'await navigator.clipboard.writeText' in CLIPBOARD
    assert '.then(' not in CLIPBOARD and 'throw new Error' in CLIPBOARD


def test_subscription_submit_clears_busy_after_network_or_http_failure():
    body=ADMIN[ADMIN.index('function AssignSubscriptionDialog'):]
    assert 'try {' in body and 'if (!r.ok)' in body and 'catch (e)' in body
    assert 'finally' in body and 'setBusy(false)' in body
