"""Pure managed-persistence routing; no secrets, database or HTTP access."""
import sys
from pathlib import Path
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from persistence import selected_backend


def test_managed_dsn_wins_over_old_mongo_variables():
    assert selected_backend({"DATABASE_URL": "fixture", "MONGO_URL": "legacy", "DB_NAME": "old"}) == "mysql"


def test_production_never_automatically_uses_mongo():
    assert selected_backend({"RSVX7_RUNTIME_ENV": "production", "MONGO_URL": "legacy"}) == "mysql"


def test_explicit_local_compose_profile_is_preserved():
    assert selected_backend({"RSVX7_RUNTIME_ENV": "production", "RSVX7_DATA_BACKEND": "mongo"}) == "mongo"


def test_unknown_backend_rejected():
    with pytest.raises(RuntimeError):
        selected_backend({"RSVX7_DATA_BACKEND": "atlas-fallback"})
