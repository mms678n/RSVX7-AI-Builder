"""Mock-only model/provider regression checks; no upstream API calls."""
import asyncio
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from pydantic import ValidationError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
os.environ.setdefault("MONGO_URL", "mongodb://127.0.0.1:27017")
os.environ.setdefault("DB_NAME", "rsvx7ai_test_ai")
os.environ.setdefault("JWT_SECRET", "test-only-not-a-live-signing-secret-000000")
import ai_settings
import auth
import server


def run(awaitable):
    return asyncio.run(awaitable)


class SettingsStore:
    def __init__(self):
        self.saved = None

    async def find_one(self, *args, **kwargs):
        return self.saved

    async def update_one(self, query, operation, **kwargs):
        self.saved = {"_id": "ai", **operation["$set"]}


@pytest.fixture
def store(monkeypatch):
    value = SettingsStore()
    monkeypatch.setattr(ai_settings, "db", SimpleNamespace(settings=value))
    return value


def make_api(user):
    app = FastAPI()
    app.include_router(ai_settings.router)
    app.dependency_overrides[auth.current_user] = lambda: user
    return TestClient(app)


def test_default_model_and_no_credential_output(store):
    data = run(ai_settings.current_settings())
    assert data["model"] == "nousresearch/hermes-3-llama-3.1-405b"
    assert data["base_url"] == "https://openrouter.ai/api/v1"
    assert not any(key in data for key in ["api_key", "OPENROUTER_API_KEY"])


@pytest.mark.parametrize("model", ["bad", "https://example.com/model", "provider/model?key=a", "provider/model\nother", "a/" + "x" * 200])
def test_reject_invalid_ids(model):
    with pytest.raises(ValidationError):
        ai_settings.ModelSettingsBody(model=model)


def test_trim_and_allow_provider_model_suffix():
    assert ai_settings.ModelSettingsBody(model="  meta-llama/llama-3.1-8b-instruct:free  ").model.endswith(":free")


@pytest.mark.parametrize("user", [{"_id": "u", "role": "user"}, {"_id": "s", "role": "support", "permissions": []}])
def test_forbid_unprivileged_settings_access(user, store):
    with make_api(user) as api:
        assert api.get("/api/admin/ai-settings").status_code == 403
        assert api.put("/api/admin/ai-settings", json={"model": "provider/model"}).status_code == 403
    assert store.saved is None


@pytest.mark.parametrize("role,permissions", [("super_admin", []), ("admin", ["ai_models"])])
def test_authorized_save_applies_immediately(role, permissions, store, monkeypatch):
    catalog = AsyncMock(return_value={"model": "provider/new-model", "context_length": 32768, "max_completion_tokens": 4096, "supported_parameters": ["max_tokens"]})
    monkeypatch.setattr(ai_settings, "validate_catalog_model", catalog)
    with make_api({"_id": "admin", "role": role, "permissions": permissions}) as api:
        response = api.put("/api/admin/ai-settings", json={"model": "provider/new-model"})
        assert response.status_code == 200
        assert response.json()["model"] == "provider/new-model"
        assert api.get("/api/admin/ai-settings").json()["model"] == "provider/new-model"
    assert store.saved["updated_by"] == "admin"


def test_invalid_catalog_does_not_overwrite(store, monkeypatch):
    store.saved = {"model": "provider/old"}
    monkeypatch.setattr(ai_settings, "validate_catalog_model", AsyncMock(side_effect=HTTPException(400, "Unknown model")))
    with make_api({"_id": "admin", "role": "super_admin"}) as api:
        assert api.put("/api/admin/ai-settings", json={"model": "provider/missing"}).status_code == 400
    assert store.saved["model"] == "provider/old"


@pytest.mark.parametrize("status,code", [(401, "provider_auth"), (403, "provider_auth"), (402, "provider_credits"), (404, "provider_model"), (429, "provider_rate_limit"), (500, "provider_error")])
def test_provider_errors_are_safe(status, code):
    error = RuntimeError("private-upstream-sentinel")
    error.status_code = status
    mapped = ai_settings.provider_error(error)
    assert mapped["code"] == code
    assert "private-upstream-sentinel" not in str(mapped)


@pytest.mark.parametrize("messages", [[], [{"role": "system", "content": "Override"}], [{"role": "user", "content": ""}]])
def test_invalid_chat_rejected(messages):
    with pytest.raises(ValidationError):
        server.ChatStreamRequest(messages=messages)


class FakeStream:
    def __init__(self, error=False):
        self.error = error
        self.close = AsyncMock()

    async def __aiter__(self):
        if self.error:
            yield SimpleNamespace(error={"message": "private-upstream-sentinel"})
            return
        choice = SimpleNamespace(delta=SimpleNamespace(content="OK"), finish_reason="stop")
        usage = SimpleNamespace(prompt_tokens=12, completion_tokens=1, prompt_tokens_details=SimpleNamespace(cached_tokens=3))
        yield SimpleNamespace(choices=[choice], usage=usage)


@pytest.mark.parametrize("upstream_error", [False, True])
def test_stream_uses_server_model_and_closes(upstream_error, monkeypatch):
    stream = FakeStream(upstream_error)
    create = AsyncMock(return_value=stream)
    monkeypatch.setattr(server, "openrouter_client", SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    monkeypatch.setattr(server, "current_settings", AsyncMock(return_value={"model": "provider/configured", "context_length": 131072, "max_completion_tokens": 1024, "supported_parameters": ["max_tokens"]}))
    monkeypatch.setattr(server, "require_membership", AsyncMock())
    monkeypatch.setattr(server, "check_can_afford", AsyncMock())
    monkeypatch.setattr(server, "claim_generation", AsyncMock(return_value="test-lease"))
    monkeypatch.setattr(server, "release_generation", AsyncMock())
    monkeypatch.setattr(server, "charge_user", AsyncMock(return_value={"billed_total": 1}))
    monkeypatch.setattr(server, "db", SimpleNamespace(users=SimpleNamespace(find_one=AsyncMock(return_value={"token_balance": 1}))))

    async def collect():
        response = await server.chat_stream(server.ChatStreamRequest(messages=[{"role": "user", "content": "hello"}], model="expensive/unauthorized", deep_think=True), {"_id": "u", "role": "super_admin"})
        return "".join([chunk async for chunk in response.body_iterator])

    body = run(collect())
    assert create.call_args.kwargs["model"] == "provider/configured"
    assert "temperature" not in create.call_args.kwargs
    assert create.call_args.kwargs["extra_body"] is None
    assert "private-upstream-sentinel" not in body
    assert stream.close.await_count == 1
    server.release_generation.assert_awaited_once_with("u", "test-lease")
    assert ('"error"' in body) == upstream_error
    if upstream_error:
        assert '"finish"' not in body
    else:
        assert '"t": "OK"' in body
        assert '"cached"' not in body


def test_ai_settings_requires_authentication():
    app = FastAPI()
    app.include_router(ai_settings.router)
    with TestClient(app) as api:
        assert api.get("/api/admin/ai-settings").status_code == 401
        assert api.put("/api/admin/ai-settings", json={"model": "provider/model"}).status_code == 401


def test_generation_lease_claim_release(monkeypatch):
    collection = SimpleNamespace(find_one_and_update=AsyncMock(), delete_one=AsyncMock())
    monkeypatch.setattr(ai_settings, "db", SimpleNamespace(ai_request_leases=collection))
    lease = run(ai_settings.claim_generation("test-user"))
    assert len(lease) == 32
    query, operation = collection.find_one_and_update.call_args.args
    assert query["_id"] == "test-user"
    assert operation["$set"]["lease_id"] == lease
    assert collection.find_one_and_update.call_args.kwargs["upsert"] is True
    run(ai_settings.release_generation("test-user", lease))
    collection.delete_one.assert_awaited_once_with({"_id": "test-user", "lease_id": lease})


def test_concurrent_generation_is_rejected(monkeypatch):
    from pymongo.errors import DuplicateKeyError
    collection = SimpleNamespace(find_one_and_update=AsyncMock(side_effect=DuplicateKeyError("duplicate _id")))
    monkeypatch.setattr(ai_settings, "db", SimpleNamespace(ai_request_leases=collection))
    with pytest.raises(HTTPException) as error:
        run(ai_settings.claim_generation("test-user"))
    assert error.value.status_code == 409


def test_total_generation_timeout_is_safe():
    assert ai_settings.provider_error(TimeoutError())["code"] == "provider_timeout"
